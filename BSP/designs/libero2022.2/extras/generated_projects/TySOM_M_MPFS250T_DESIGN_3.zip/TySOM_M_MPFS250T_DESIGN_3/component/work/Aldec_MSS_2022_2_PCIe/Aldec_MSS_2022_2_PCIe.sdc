# Microchip Corp.
# Date: Mon Apr  8 09:30:37 2024
# 
set_component {Aldec_MSS_2022_2_PCIe}
