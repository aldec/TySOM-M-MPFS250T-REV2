# Microchip Corp.
# Date: Mon Jul 17 16:19:47 2023
# 
set_component {Aldec_MSS_2022_2}
