//////////////////////////////////////////////////////////////////////
// Created by SmartDesign Tue Jan 14 12:10:03 2025
// Version: 2022.2 2022.2.0.10
//////////////////////////////////////////////////////////////////////

`timescale 1ns / 100ps

// top
module top(
    // Inputs
    CLK_125,
    LANE0_RXD_N,
    LANE0_RXD_P,
    LANE1_RXD_N,
    LANE1_RXD_P,
    REF_CLK_PAD_N,
    REF_CLK_PAD_P,
    RESET,
    RX,
    start_test,
    // Outputs
    LANE0_TXD_N,
    LANE0_TXD_P,
    LANE0_TX_CLK_STABLE,
    LANE1_TXD_N,
    LANE1_TXD_P,
    LANE1_TX_CLK_STABLE,
    TX,
    error_o_link0,
    error_o_link1,
    lock_o_link0,
    lock_o_link1,
    rx_val_o_link0,
    rx_val_o_link1
);

//--------------------------------------------------------------------
// Input
//--------------------------------------------------------------------
input  CLK_125;
input  LANE0_RXD_N;
input  LANE0_RXD_P;
input  LANE1_RXD_N;
input  LANE1_RXD_P;
input  REF_CLK_PAD_N;
input  REF_CLK_PAD_P;
input  RESET;
input  RX;
input  start_test;
//--------------------------------------------------------------------
// Output
//--------------------------------------------------------------------
output LANE0_TXD_N;
output LANE0_TXD_P;
output LANE0_TX_CLK_STABLE;
output LANE1_TXD_N;
output LANE1_TXD_P;
output LANE1_TX_CLK_STABLE;
output TX;
output error_o_link0;
output error_o_link1;
output lock_o_link0;
output lock_o_link1;
output rx_val_o_link0;
output rx_val_o_link1;
//--------------------------------------------------------------------
// Nets
//--------------------------------------------------------------------
wire           AND2_0_Y;
wire           CLK_125;
wire           error_o_link0_net_0;
wire           error_o_link1_net_0;
wire           LANE0_RXD_N;
wire           LANE0_RXD_P;
wire           LANE0_TX_CLK_STABLE_net_0;
wire           LANE0_TXD_N_net_0;
wire           LANE0_TXD_P_net_0;
wire           LANE1_RXD_N;
wire           LANE1_RXD_P;
wire           LANE1_TX_CLK_STABLE_net_0;
wire           LANE1_TXD_N_net_0;
wire           LANE1_TXD_P_net_0;
wire           LiteFast_receiver_0_crc_error_o;
wire   [15:0]  LiteFast_receiver_0_data_rx_o;
wire   [31:16] LiteFast_receiver_0_data_tx_o;
wire           LiteFast_receiver_0_lane_aligned_rx_o;
wire   [7:0]   LiteFast_receiver_0_Local_Token_o;
wire   [7:0]   LiteFast_receiver_0_Remote_Token_o;
wire           LiteFast_receiver_1_lane_aligned_rx_o;
wire   [7:0]   LiteFast_receiver_1_Local_Token_o;
wire   [7:0]   LiteFast_receiver_1_Remote_Token_o;
wire   [31:0]  LiteFast_transmitter_0_LiteFast_data_tx_o;
wire   [3:0]   LiteFast_transmitter_0_LiteFast_k_tx_o;
wire   [31:0]  LiteFast_transmitter_1_LiteFast_data_tx_o;
wire   [3:0]   LiteFast_transmitter_1_LiteFast_k_tx_o;
wire           lock_o_link0_net_0;
wire           lock_o_link1_net_0;
wire           REF_CLK_PAD_N;
wire           REF_CLK_PAD_P;
wire           RESET;
wire           RX;
wire           rx_val_o_link0_net_0;
wire           rx_val_o_link1_net_0;
wire           start_test;
wire   [3:0]   transceiver_0_LANE0_8B10B_RX_K;
wire           transceiver_0_LANE0_RX_CLK_R;
wire   [31:0]  transceiver_0_LANE0_RX_DATA;
wire           transceiver_0_LANE0_RX_VAL;
wire           transceiver_0_LANE0_TX_CLK_R;
wire   [3:0]   transceiver_0_LANE1_8B10B_RX_K;
wire           transceiver_0_LANE1_RX_CLK_R;
wire   [31:0]  transceiver_0_LANE1_RX_DATA;
wire           transceiver_0_LANE1_RX_VAL;
wire           transceiver_0_LANE1_TX_CLK_R;
wire           TX_net_0;
wire           UART_IF_0_clear_o;
wire           UART_IF_0_crc_err_o;
wire           UART_IF_0_payload_err_o;
wire           UART_IF_0_start_o;
wire           UART_IF_0_UART_IF_CLK;
wire           LANE0_TXD_N_net_1;
wire           LANE0_TXD_P_net_1;
wire           LANE0_TX_CLK_STABLE_net_1;
wire           LANE1_TXD_N_net_1;
wire           LANE1_TXD_P_net_1;
wire           LANE1_TX_CLK_STABLE_net_1;
wire           TX_net_1;
wire           error_o_link0_net_1;
wire           error_o_link1_net_1;
wire           lock_o_link0_net_1;
wire           lock_o_link1_net_1;
wire           rx_val_o_link0_net_1;
wire           rx_val_o_link1_net_1;
//--------------------------------------------------------------------
// Top level output port assignments
//--------------------------------------------------------------------
assign LANE0_TXD_N_net_1         = LANE0_TXD_N_net_0;
assign LANE0_TXD_N               = LANE0_TXD_N_net_1;
assign LANE0_TXD_P_net_1         = LANE0_TXD_P_net_0;
assign LANE0_TXD_P               = LANE0_TXD_P_net_1;
assign LANE0_TX_CLK_STABLE_net_1 = LANE0_TX_CLK_STABLE_net_0;
assign LANE0_TX_CLK_STABLE       = LANE0_TX_CLK_STABLE_net_1;
assign LANE1_TXD_N_net_1         = LANE1_TXD_N_net_0;
assign LANE1_TXD_N               = LANE1_TXD_N_net_1;
assign LANE1_TXD_P_net_1         = LANE1_TXD_P_net_0;
assign LANE1_TXD_P               = LANE1_TXD_P_net_1;
assign LANE1_TX_CLK_STABLE_net_1 = LANE1_TX_CLK_STABLE_net_0;
assign LANE1_TX_CLK_STABLE       = LANE1_TX_CLK_STABLE_net_1;
assign TX_net_1                  = TX_net_0;
assign TX                        = TX_net_1;
assign error_o_link0_net_1       = error_o_link0_net_0;
assign error_o_link0             = error_o_link0_net_1;
assign error_o_link1_net_1       = error_o_link1_net_0;
assign error_o_link1             = error_o_link1_net_1;
assign lock_o_link0_net_1        = lock_o_link0_net_0;
assign lock_o_link0              = lock_o_link0_net_1;
assign lock_o_link1_net_1        = lock_o_link1_net_0;
assign lock_o_link1              = lock_o_link1_net_1;
assign rx_val_o_link0_net_1      = rx_val_o_link0_net_0;
assign rx_val_o_link0            = rx_val_o_link0_net_1;
assign rx_val_o_link1_net_1      = rx_val_o_link1_net_0;
assign rx_val_o_link1            = rx_val_o_link1_net_1;
//--------------------------------------------------------------------
// Component instances
//--------------------------------------------------------------------
//--------AND2
AND2 AND2_0(
        // Inputs
        .A ( transceiver_0_LANE0_RX_VAL ),
        .B ( transceiver_0_LANE1_RX_VAL ),
        // Outputs
        .Y ( AND2_0_Y ) 
        );

//--------LiteFast_receiver
LiteFast_receiver LiteFast_receiver_0(
        // Inputs
        .DATA_0            ( UART_IF_0_clear_o ),
        .DATA              ( UART_IF_0_start_o ),
        .RCLOCK            ( transceiver_0_LANE0_TX_CLK_R ),
        .RESET             ( AND2_0_Y ),
        .WCLOCK_0          ( UART_IF_0_UART_IF_CLK ),
        .WCLOCK            ( transceiver_0_LANE0_RX_CLK_R ),
        .lane_data_rx_i    ( transceiver_0_LANE0_RX_DATA ),
        .lane_k_rx_i       ( transceiver_0_LANE0_8B10B_RX_K ),
        // Outputs
        .crc_error_o       ( LiteFast_receiver_0_crc_error_o ),
        .error_o           ( error_o_link0_net_0 ),
        .lane_aligned_rx_o ( LiteFast_receiver_0_lane_aligned_rx_o ),
        .lock_o            ( lock_o_link0_net_0 ),
        .rx_val_o          ( rx_val_o_link0_net_0 ),
        .Local_Token_o     ( LiteFast_receiver_0_Local_Token_o ),
        .Remote_Token_o    ( LiteFast_receiver_0_Remote_Token_o ),
        .data_rx_o         ( LiteFast_receiver_0_data_rx_o ),
        .data_tx_o         ( LiteFast_receiver_0_data_tx_o ) 
        );

//--------LiteFast_receiver
LiteFast_receiver LiteFast_receiver_1(
        // Inputs
        .DATA_0            ( UART_IF_0_clear_o ),
        .DATA              ( UART_IF_0_start_o ),
        .RCLOCK            ( transceiver_0_LANE1_TX_CLK_R ),
        .RESET             ( AND2_0_Y ),
        .WCLOCK_0          ( UART_IF_0_UART_IF_CLK ),
        .WCLOCK            ( transceiver_0_LANE1_RX_CLK_R ),
        .lane_data_rx_i    ( transceiver_0_LANE1_RX_DATA ),
        .lane_k_rx_i       ( transceiver_0_LANE1_8B10B_RX_K ),
        // Outputs
        .crc_error_o       (  ),
        .error_o           ( error_o_link1_net_0 ),
        .lane_aligned_rx_o ( LiteFast_receiver_1_lane_aligned_rx_o ),
        .lock_o            ( lock_o_link1_net_0 ),
        .rx_val_o          ( rx_val_o_link1_net_0 ),
        .Local_Token_o     ( LiteFast_receiver_1_Local_Token_o ),
        .Remote_Token_o    ( LiteFast_receiver_1_Remote_Token_o ),
        .data_rx_o         (  ),
        .data_tx_o         (  ) 
        );

//--------LiteFast_transmitter
LiteFast_transmitter LiteFast_transmitter_0(
        // Inputs
        .DATA_0              ( UART_IF_0_payload_err_o ),
        .DATA_1              ( UART_IF_0_crc_err_o ),
        .DATA                ( UART_IF_0_start_o ),
        .WCLOCK              ( UART_IF_0_UART_IF_CLK ),
        .clk_i               ( transceiver_0_LANE0_TX_CLK_R ),
        .local_rece_rdy_tx_i ( LiteFast_receiver_0_lane_aligned_rx_o ),
        .start_i             ( AND2_0_Y ),
        .local_token_tx_i    ( LiteFast_receiver_0_Local_Token_o ),
        .remote_token_tx_i   ( LiteFast_receiver_0_Remote_Token_o ),
        // Outputs
        .LiteFast_data_tx_o  ( LiteFast_transmitter_0_LiteFast_data_tx_o ),
        .LiteFast_k_tx_o     ( LiteFast_transmitter_0_LiteFast_k_tx_o ) 
        );

//--------LiteFast_transmitter
LiteFast_transmitter LiteFast_transmitter_1(
        // Inputs
        .DATA_0              ( UART_IF_0_payload_err_o ),
        .DATA_1              ( UART_IF_0_crc_err_o ),
        .DATA                ( UART_IF_0_start_o ),
        .WCLOCK              ( UART_IF_0_UART_IF_CLK ),
        .clk_i               ( transceiver_0_LANE1_TX_CLK_R ),
        .local_rece_rdy_tx_i ( LiteFast_receiver_1_lane_aligned_rx_o ),
        .start_i             ( AND2_0_Y ),
        .local_token_tx_i    ( LiteFast_receiver_1_Local_Token_o ),
        .remote_token_tx_i   ( LiteFast_receiver_1_Remote_Token_o ),
        // Outputs
        .LiteFast_data_tx_o  ( LiteFast_transmitter_1_LiteFast_data_tx_o ),
        .LiteFast_k_tx_o     ( LiteFast_transmitter_1_LiteFast_k_tx_o ) 
        );

//--------transceiver
transceiver transceiver_0(
        // Inputs
        .LANE0_RXD_N         ( LANE0_RXD_N ),
        .LANE0_RXD_P         ( LANE0_RXD_P ),
        .LANE1_RXD_N         ( LANE1_RXD_N ),
        .LANE1_RXD_P         ( LANE1_RXD_P ),
        .REF_CLK_PAD_N       ( REF_CLK_PAD_N ),
        .REF_CLK_PAD_P       ( REF_CLK_PAD_P ),
        .LANE0_8B10B_TX_K    ( LiteFast_transmitter_0_LiteFast_k_tx_o ),
        .LANE0_TX_DATA       ( LiteFast_transmitter_0_LiteFast_data_tx_o ),
        .LANE1_8B10B_TX_K    ( LiteFast_transmitter_1_LiteFast_k_tx_o ),
        .LANE1_TX_DATA       ( LiteFast_transmitter_1_LiteFast_data_tx_o ),
        // Outputs
        .LANE0_RX_CLK_R      ( transceiver_0_LANE0_RX_CLK_R ),
        .LANE0_RX_VAL        ( transceiver_0_LANE0_RX_VAL ),
        .LANE0_TXD_N         ( LANE0_TXD_N_net_0 ),
        .LANE0_TXD_P         ( LANE0_TXD_P_net_0 ),
        .LANE0_TX_CLK_R      ( transceiver_0_LANE0_TX_CLK_R ),
        .LANE0_TX_CLK_STABLE ( LANE0_TX_CLK_STABLE_net_0 ),
        .LANE1_RX_CLK_R      ( transceiver_0_LANE1_RX_CLK_R ),
        .LANE1_RX_VAL        ( transceiver_0_LANE1_RX_VAL ),
        .LANE1_TXD_N         ( LANE1_TXD_N_net_0 ),
        .LANE1_TXD_P         ( LANE1_TXD_P_net_0 ),
        .LANE1_TX_CLK_R      ( transceiver_0_LANE1_TX_CLK_R ),
        .LANE1_TX_CLK_STABLE ( LANE1_TX_CLK_STABLE_net_0 ),
        .LANE0_8B10B_RX_K    ( transceiver_0_LANE0_8B10B_RX_K ),
        .LANE0_RX_DATA       ( transceiver_0_LANE0_RX_DATA ),
        .LANE1_8B10B_RX_K    ( transceiver_0_LANE1_8B10B_RX_K ),
        .LANE1_RX_DATA       ( transceiver_0_LANE1_RX_DATA ) 
        );

//--------UART_IF
UART_IF UART_IF_0(
        // Inputs
        .CLK_125       ( CLK_125 ),
        .RESET         ( RESET ),
        .RX            ( RX ),
        .crc_error_i   ( LiteFast_receiver_0_crc_error_o ),
        .payload_err_i ( error_o_link0_net_0 ),
        .rx_error_i    ( error_o_link0_net_0 ),
        .rx_lock_i     ( lock_o_link0_net_0 ),
        .rx_val_i      ( rx_val_o_link0_net_0 ),
        .start_test    ( start_test ),
        .rx_words_in   ( LiteFast_receiver_0_data_tx_o ),
        .tx_words_in   ( LiteFast_receiver_0_data_rx_o ),
        // Outputs
        .TX            ( TX_net_0 ),
        .UART_IF_CLK   ( UART_IF_0_UART_IF_CLK ),
        .clear_o       ( UART_IF_0_clear_o ),
        .crc_err_o     ( UART_IF_0_crc_err_o ),
        .payload_err_o ( UART_IF_0_payload_err_o ),
        .start_o       ( UART_IF_0_start_o ) 
        );


endmodule
