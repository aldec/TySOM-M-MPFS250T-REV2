//////////////////////////////////////////////////////////////////////
// Created by SmartDesign Tue Jan 14 12:09:55 2025
// Version: 2022.2 2022.2.0.10
//////////////////////////////////////////////////////////////////////

`timescale 1ns / 100ps

// transceiver
module transceiver(
    // Inputs
    LANE0_8B10B_TX_K,
    LANE0_RXD_N,
    LANE0_RXD_P,
    LANE0_TX_DATA,
    LANE1_8B10B_TX_K,
    LANE1_RXD_N,
    LANE1_RXD_P,
    LANE1_TX_DATA,
    REF_CLK_PAD_N,
    REF_CLK_PAD_P,
    // Outputs
    LANE0_8B10B_RX_K,
    LANE0_RX_CLK_R,
    LANE0_RX_DATA,
    LANE0_RX_VAL,
    LANE0_TXD_N,
    LANE0_TXD_P,
    LANE0_TX_CLK_R,
    LANE0_TX_CLK_STABLE,
    LANE1_8B10B_RX_K,
    LANE1_RX_CLK_R,
    LANE1_RX_DATA,
    LANE1_RX_VAL,
    LANE1_TXD_N,
    LANE1_TXD_P,
    LANE1_TX_CLK_R,
    LANE1_TX_CLK_STABLE
);

//--------------------------------------------------------------------
// Input
//--------------------------------------------------------------------
input  [3:0]  LANE0_8B10B_TX_K;
input         LANE0_RXD_N;
input         LANE0_RXD_P;
input  [31:0] LANE0_TX_DATA;
input  [3:0]  LANE1_8B10B_TX_K;
input         LANE1_RXD_N;
input         LANE1_RXD_P;
input  [31:0] LANE1_TX_DATA;
input         REF_CLK_PAD_N;
input         REF_CLK_PAD_P;
//--------------------------------------------------------------------
// Output
//--------------------------------------------------------------------
output [3:0]  LANE0_8B10B_RX_K;
output        LANE0_RX_CLK_R;
output [31:0] LANE0_RX_DATA;
output        LANE0_RX_VAL;
output        LANE0_TXD_N;
output        LANE0_TXD_P;
output        LANE0_TX_CLK_R;
output        LANE0_TX_CLK_STABLE;
output [3:0]  LANE1_8B10B_RX_K;
output        LANE1_RX_CLK_R;
output [31:0] LANE1_RX_DATA;
output        LANE1_RX_VAL;
output        LANE1_TXD_N;
output        LANE1_TXD_P;
output        LANE1_TX_CLK_R;
output        LANE1_TX_CLK_STABLE;
//--------------------------------------------------------------------
// Nets
//--------------------------------------------------------------------
wire   [3:0]  LANE0_8B10B_RX_K_net_0;
wire   [3:0]  LANE0_8B10B_TX_K;
wire          LANE0_RX_CLK_R_net_0;
wire   [31:0] LANE0_RX_DATA_net_0;
wire          LANE0_RX_VAL_net_0;
wire          LANE0_RXD_N;
wire          LANE0_RXD_P;
wire          LANE0_TX_CLK_R_net_0;
wire          LANE0_TX_CLK_STABLE_net_0;
wire   [31:0] LANE0_TX_DATA;
wire          LANE0_TXD_N_net_0;
wire          LANE0_TXD_P_net_0;
wire   [3:0]  LANE1_8B10B_RX_K_net_0;
wire   [3:0]  LANE1_8B10B_TX_K;
wire          LANE1_RX_CLK_R_net_0;
wire   [31:0] LANE1_RX_DATA_net_0;
wire          LANE1_RX_VAL_net_0;
wire          LANE1_RXD_N;
wire          LANE1_RXD_P;
wire          LANE1_TX_CLK_R_net_0;
wire          LANE1_TX_CLK_STABLE_net_0;
wire   [31:0] LANE1_TX_DATA;
wire          LANE1_TXD_N_net_0;
wire          LANE1_TXD_P_net_0;
wire          PF_TX_PLL_C0_0_CLKS_TO_XCVR_BIT_CLK;
wire          PF_TX_PLL_C0_0_CLKS_TO_XCVR_LOCK;
wire          PF_TX_PLL_C0_0_CLKS_TO_XCVR_REF_CLK_TO_LANE;
wire          PF_XCVR_REF_CLK_C0_0_REF_CLK;
wire          REF_CLK_PAD_N;
wire          REF_CLK_PAD_P;
wire          LANE0_RX_CLK_R_net_1;
wire          LANE0_RX_VAL_net_1;
wire          LANE0_TXD_N_net_1;
wire          LANE0_TXD_P_net_1;
wire          LANE0_TX_CLK_R_net_1;
wire          LANE0_TX_CLK_STABLE_net_1;
wire          LANE1_RX_CLK_R_net_1;
wire          LANE1_RX_VAL_net_1;
wire          LANE1_TXD_N_net_1;
wire          LANE1_TXD_P_net_1;
wire          LANE1_TX_CLK_R_net_1;
wire          LANE1_TX_CLK_STABLE_net_1;
wire   [3:0]  LANE0_8B10B_RX_K_net_1;
wire   [31:0] LANE0_RX_DATA_net_1;
wire   [3:0]  LANE1_8B10B_RX_K_net_1;
wire   [31:0] LANE1_RX_DATA_net_1;
//--------------------------------------------------------------------
// TiedOff Nets
//--------------------------------------------------------------------
wire          VCC_net;
wire   [7:0]  LANE0_TX_DISPFNC_const_net_0;
wire   [7:0]  LANE1_TX_DISPFNC_const_net_0;
//--------------------------------------------------------------------
// Constant assignments
//--------------------------------------------------------------------
assign VCC_net                      = 1'b1;
assign LANE0_TX_DISPFNC_const_net_0 = 8'h00;
assign LANE1_TX_DISPFNC_const_net_0 = 8'h00;
//--------------------------------------------------------------------
// Top level output port assignments
//--------------------------------------------------------------------
assign LANE0_RX_CLK_R_net_1      = LANE0_RX_CLK_R_net_0;
assign LANE0_RX_CLK_R            = LANE0_RX_CLK_R_net_1;
assign LANE0_RX_VAL_net_1        = LANE0_RX_VAL_net_0;
assign LANE0_RX_VAL              = LANE0_RX_VAL_net_1;
assign LANE0_TXD_N_net_1         = LANE0_TXD_N_net_0;
assign LANE0_TXD_N               = LANE0_TXD_N_net_1;
assign LANE0_TXD_P_net_1         = LANE0_TXD_P_net_0;
assign LANE0_TXD_P               = LANE0_TXD_P_net_1;
assign LANE0_TX_CLK_R_net_1      = LANE0_TX_CLK_R_net_0;
assign LANE0_TX_CLK_R            = LANE0_TX_CLK_R_net_1;
assign LANE0_TX_CLK_STABLE_net_1 = LANE0_TX_CLK_STABLE_net_0;
assign LANE0_TX_CLK_STABLE       = LANE0_TX_CLK_STABLE_net_1;
assign LANE1_RX_CLK_R_net_1      = LANE1_RX_CLK_R_net_0;
assign LANE1_RX_CLK_R            = LANE1_RX_CLK_R_net_1;
assign LANE1_RX_VAL_net_1        = LANE1_RX_VAL_net_0;
assign LANE1_RX_VAL              = LANE1_RX_VAL_net_1;
assign LANE1_TXD_N_net_1         = LANE1_TXD_N_net_0;
assign LANE1_TXD_N               = LANE1_TXD_N_net_1;
assign LANE1_TXD_P_net_1         = LANE1_TXD_P_net_0;
assign LANE1_TXD_P               = LANE1_TXD_P_net_1;
assign LANE1_TX_CLK_R_net_1      = LANE1_TX_CLK_R_net_0;
assign LANE1_TX_CLK_R            = LANE1_TX_CLK_R_net_1;
assign LANE1_TX_CLK_STABLE_net_1 = LANE1_TX_CLK_STABLE_net_0;
assign LANE1_TX_CLK_STABLE       = LANE1_TX_CLK_STABLE_net_1;
assign LANE0_8B10B_RX_K_net_1    = LANE0_8B10B_RX_K_net_0;
assign LANE0_8B10B_RX_K[3:0]     = LANE0_8B10B_RX_K_net_1;
assign LANE0_RX_DATA_net_1       = LANE0_RX_DATA_net_0;
assign LANE0_RX_DATA[31:0]       = LANE0_RX_DATA_net_1;
assign LANE1_8B10B_RX_K_net_1    = LANE1_8B10B_RX_K_net_0;
assign LANE1_8B10B_RX_K[3:0]     = LANE1_8B10B_RX_K_net_1;
assign LANE1_RX_DATA_net_1       = LANE1_RX_DATA_net_0;
assign LANE1_RX_DATA[31:0]       = LANE1_RX_DATA_net_1;
//--------------------------------------------------------------------
// Component instances
//--------------------------------------------------------------------
//--------PF_TX_PLL_C0
PF_TX_PLL_C0 PF_TX_PLL_C0_0(
        // Inputs
        .REF_CLK         ( PF_XCVR_REF_CLK_C0_0_REF_CLK ),
        // Outputs
        .PLL_LOCK        (  ),
        .LOCK            ( PF_TX_PLL_C0_0_CLKS_TO_XCVR_LOCK ),
        .BIT_CLK         ( PF_TX_PLL_C0_0_CLKS_TO_XCVR_BIT_CLK ),
        .REF_CLK_TO_LANE ( PF_TX_PLL_C0_0_CLKS_TO_XCVR_REF_CLK_TO_LANE ),
        .CLK_125         (  ) 
        );

//--------PF_XCVR_ERM_C0
PF_XCVR_ERM_C0 PF_XCVR_ERM_C0_0(
        // Inputs
        .LANE0_RXD_P              ( LANE0_RXD_P ),
        .LANE0_RXD_N              ( LANE0_RXD_N ),
        .LANE1_RXD_P              ( LANE1_RXD_P ),
        .LANE1_RXD_N              ( LANE1_RXD_N ),
        .LANE0_TX_DATA            ( LANE0_TX_DATA ),
        .LANE0_CDR_REF_CLK_0      ( PF_XCVR_REF_CLK_C0_0_REF_CLK ),
        .LANE0_PCS_ARST_N         ( VCC_net ),
        .LANE0_PMA_ARST_N         ( VCC_net ),
        .LANE0_TX_DISPFNC         ( LANE0_TX_DISPFNC_const_net_0 ),
        .LANE0_8B10B_TX_K         ( LANE0_8B10B_TX_K ),
        .LANE1_TX_DATA            ( LANE1_TX_DATA ),
        .LANE1_CDR_REF_CLK_0      ( PF_XCVR_REF_CLK_C0_0_REF_CLK ),
        .LANE1_PCS_ARST_N         ( VCC_net ),
        .LANE1_PMA_ARST_N         ( VCC_net ),
        .LANE1_TX_DISPFNC         ( LANE1_TX_DISPFNC_const_net_0 ),
        .LANE1_8B10B_TX_K         ( LANE1_8B10B_TX_K ),
        .TX_PLL_LOCK_0            ( PF_TX_PLL_C0_0_CLKS_TO_XCVR_LOCK ),
        .TX_BIT_CLK_0             ( PF_TX_PLL_C0_0_CLKS_TO_XCVR_BIT_CLK ),
        .TX_PLL_REF_CLK_0         ( PF_TX_PLL_C0_0_CLKS_TO_XCVR_REF_CLK_TO_LANE ),
        // Outputs
        .LANE0_TXD_P              ( LANE0_TXD_P_net_0 ),
        .LANE0_TXD_N              ( LANE0_TXD_N_net_0 ),
        .LANE1_TXD_P              ( LANE1_TXD_P_net_0 ),
        .LANE1_TXD_N              ( LANE1_TXD_N_net_0 ),
        .LANE0_RX_DATA            ( LANE0_RX_DATA_net_0 ),
        .LANE0_TX_CLK_R           ( LANE0_TX_CLK_R_net_0 ),
        .LANE0_RX_CLK_R           ( LANE0_RX_CLK_R_net_0 ),
        .LANE0_RX_IDLE            (  ),
        .LANE0_RX_READY           (  ),
        .LANE0_RX_VAL             ( LANE0_RX_VAL_net_0 ),
        .LANE0_TX_CLK_STABLE      ( LANE0_TX_CLK_STABLE_net_0 ),
        .LANE0_RX_CODE_VIOLATION  (  ),
        .LANE0_RX_DISPARITY_ERROR (  ),
        .LANE0_8B10B_RX_K         ( LANE0_8B10B_RX_K_net_0 ),
        .LANE1_RX_DATA            ( LANE1_RX_DATA_net_0 ),
        .LANE1_TX_CLK_R           ( LANE1_TX_CLK_R_net_0 ),
        .LANE1_RX_CLK_R           ( LANE1_RX_CLK_R_net_0 ),
        .LANE1_RX_IDLE            (  ),
        .LANE1_RX_READY           (  ),
        .LANE1_RX_VAL             ( LANE1_RX_VAL_net_0 ),
        .LANE1_TX_CLK_STABLE      ( LANE1_TX_CLK_STABLE_net_0 ),
        .LANE1_RX_CODE_VIOLATION  (  ),
        .LANE1_RX_DISPARITY_ERROR (  ),
        .LANE1_8B10B_RX_K         ( LANE1_8B10B_RX_K_net_0 ) 
        );

//--------PF_XCVR_REF_CLK_C0
PF_XCVR_REF_CLK_C0 PF_XCVR_REF_CLK_C0_0(
        // Inputs
        .REF_CLK_PAD_P ( REF_CLK_PAD_P ),
        .REF_CLK_PAD_N ( REF_CLK_PAD_N ),
        // Outputs
        .REF_CLK       ( PF_XCVR_REF_CLK_C0_0_REF_CLK ) 
        );


endmodule
