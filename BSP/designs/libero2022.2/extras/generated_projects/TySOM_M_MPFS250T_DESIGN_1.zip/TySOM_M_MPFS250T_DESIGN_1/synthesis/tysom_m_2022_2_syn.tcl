project -load "/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/synthesis/tysom_m_2022_2_syn.prj"
project -run
project -save
