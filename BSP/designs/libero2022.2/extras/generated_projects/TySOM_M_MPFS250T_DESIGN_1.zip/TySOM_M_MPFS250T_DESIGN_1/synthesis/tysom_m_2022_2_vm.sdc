# Written by Synplify Pro version map202109actsp1, Build 056R. Synopsys Run ID: sid1736858916 
# Top Level Design Parameters 

# Clocks 
create_clock -period 6.250 -waveform {0.000 3.125} -name {PF_OSC_C0_0/PF_OSC_C0_0/I_OSC_160/CLK} [get_pins {PF_OSC_C0_0/PF_OSC_C0_0/I_OSC_160/CLK}] 

# Virtual Clocks 

# Generated Clocks 
create_generated_clock -name {PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/OUT3} -multiply_by {25} -divide_by {64} -source [get_pins {PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/REF_CLK_0}]  [get_pins {PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/OUT3}] 

# Paths Between Clocks 

# Multicycle Constraints 

# Point-to-point Delay Constraints 

# False Path Constraints 

# Output Load Constraints 

# Driving Cell Constraints 

# Input Delay Constraints 

# Output Delay Constraints 

# Wire Loads 

# Other Constraints 

# syn_hier Attributes 

# set_case Attributes 

# Clock Delay Constraints 

# syn_mode Attributes 

# Cells 

# Port DRC Rules 

# Input Transition Constraints 

# Unused constraints (intentionally commented out) 


# Non-forward-annotatable constraints (intentionally commented out) 

# Block Path constraints 

