run_tcl -fg tysom_m_2022_2_syn.tcl
