# Microsemi Corp.
# Date: 2025-Jan-14 12:16:04
# This file was generated based on the following SDC source files:
#   C:/revision2.2/BSP/designs/libero2022.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/Aldec_MSS_2022_2/Aldec_MSS_2022_2.sdc
#   C:/revision2.2/BSP/designs/libero2022.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/PF_CCC_C0/PF_CCC_C0_0/PF_CCC_C0_PF_CCC_C0_0_PF_CCC.sdc
#   Z:/Microscemi/Libero_SoC_2022_2/Designer/data/aPA5M/cores/constraints/osc_rc160mhz.sdc
# *** Any modifications to this file will be lost if derived constraints is re-run. ***
#

create_clock -name {PF_OSC_C0_0/PF_OSC_C0_0/I_OSC_160/CLK} -period 6.25 [ get_pins { PF_OSC_C0_0/PF_OSC_C0_0/I_OSC_160/CLK } ]
create_generated_clock -name {PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/OUT3} -multiply_by 25 -divide_by 64 -source [ get_pins { PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/REF_CLK_0 } ] -phase 0 [ get_pins { PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/OUT3 } ]
