//////////////////////////////////////////////////////////////////////
// Created by SmartDesign Tue Jan 14 12:15:58 2025
// Version: 2022.2 2022.2.0.10
//////////////////////////////////////////////////////////////////////

`timescale 1ns / 100ps

// tysom_m_2022_2
module tysom_m_2022_2(
    // Inputs
    CAN_0_RXBUS_F2M,
    GPIO_1_20_IN,
    MMUART_0_RXD,
    MMUART_1_RXD_F2M,
    MMUART_2_RXD_F2M,
    MMUART_3_RXD_F2M,
    REFCLK,
    REFCLK_N,
    SD_CD_EMMC_STRB,
    SD_WP_EMMC_RSTN,
    SGMII_RX0_N,
    SGMII_RX0_P,
    SGMII_RX1_N,
    SGMII_RX1_P,
    SPI_1_DI,
    USB_CLK,
    USB_DIR,
    USB_NXT,
    // Outputs
    A,
    ACT_N,
    BA,
    BG,
    CAN_0_STANDBY,
    CAN_0_TXBUS_M2F,
    CAS_N,
    CK0,
    CK0_N,
    CKE0,
    CS0_N,
    GPIO_1_23_OUT,
    MAC_1_MDC,
    MMUART_0_TXD,
    MMUART_1_TXD_M2F,
    MMUART_2_TXD_M2F,
    MMUART_3_TXD_M2F,
    ODT0,
    RAS_N,
    RESET_N,
    SD_CLK_EMMC_CLK,
    SD_POW_EMMC_DATA4,
    SD_SEL,
    SD_VOLT_CMD_DIR_EMMC_DATA7,
    SD_VOLT_DIR_0_EMMC_UNUSED,
    SD_VOLT_DIR_1_3_EMMC_UNUSED,
    SD_VOLT_EN_EMMC_DATA6,
    SD_VOLT_SEL_EMMC_DATA5,
    SGMII_TX0_N,
    SGMII_TX0_P,
    SGMII_TX1_N,
    SGMII_TX1_P,
    SPI_1_DO,
    USB_STP,
    USB_ULPI_RESET,
    VSC_8662_CMODE7,
    VSC_8662_RESETN,
    VSC_8662_SRESET,
    WE_N,
    // Inouts
    DQ,
    DQS,
    DQS_N,
    I2C_0_SCL,
    I2C_0_SDA,
    I2C_1_SCL,
    I2C_1_SDA,
    MAC_1_MDIO,
    SD_CMD_EMMC_CMD,
    SD_DATA0_EMMC_DATA0,
    SD_DATA1_EMMC_DATA1,
    SD_DATA2_EMMC_DATA2,
    SD_DATA3_EMMC_DATA3,
    SPI_1_CLK,
    SPI_1_SS0,
    USB_DATA0,
    USB_DATA1,
    USB_DATA2,
    USB_DATA3,
    USB_DATA4,
    USB_DATA5,
    USB_DATA6,
    USB_DATA7
);

//--------------------------------------------------------------------
// Input
//--------------------------------------------------------------------
input         CAN_0_RXBUS_F2M;
input         GPIO_1_20_IN;
input         MMUART_0_RXD;
input         MMUART_1_RXD_F2M;
input         MMUART_2_RXD_F2M;
input         MMUART_3_RXD_F2M;
input         REFCLK;
input         REFCLK_N;
input         SD_CD_EMMC_STRB;
input         SD_WP_EMMC_RSTN;
input         SGMII_RX0_N;
input         SGMII_RX0_P;
input         SGMII_RX1_N;
input         SGMII_RX1_P;
input         SPI_1_DI;
input         USB_CLK;
input         USB_DIR;
input         USB_NXT;
//--------------------------------------------------------------------
// Output
//--------------------------------------------------------------------
output [13:0] A;
output        ACT_N;
output [1:0]  BA;
output [1:0]  BG;
output        CAN_0_STANDBY;
output        CAN_0_TXBUS_M2F;
output        CAS_N;
output        CK0;
output        CK0_N;
output        CKE0;
output        CS0_N;
output        GPIO_1_23_OUT;
output        MAC_1_MDC;
output        MMUART_0_TXD;
output        MMUART_1_TXD_M2F;
output        MMUART_2_TXD_M2F;
output        MMUART_3_TXD_M2F;
output        ODT0;
output        RAS_N;
output        RESET_N;
output        SD_CLK_EMMC_CLK;
output        SD_POW_EMMC_DATA4;
output        SD_SEL;
output        SD_VOLT_CMD_DIR_EMMC_DATA7;
output        SD_VOLT_DIR_0_EMMC_UNUSED;
output        SD_VOLT_DIR_1_3_EMMC_UNUSED;
output        SD_VOLT_EN_EMMC_DATA6;
output        SD_VOLT_SEL_EMMC_DATA5;
output        SGMII_TX0_N;
output        SGMII_TX0_P;
output        SGMII_TX1_N;
output        SGMII_TX1_P;
output        SPI_1_DO;
output        USB_STP;
output        USB_ULPI_RESET;
output        VSC_8662_CMODE7;
output        VSC_8662_RESETN;
output        VSC_8662_SRESET;
output        WE_N;
//--------------------------------------------------------------------
// Inout
//--------------------------------------------------------------------
inout  [35:0] DQ;
inout  [4:0]  DQS;
inout  [4:0]  DQS_N;
inout         I2C_0_SCL;
inout         I2C_0_SDA;
inout         I2C_1_SCL;
inout         I2C_1_SDA;
inout         MAC_1_MDIO;
inout         SD_CMD_EMMC_CMD;
inout         SD_DATA0_EMMC_DATA0;
inout         SD_DATA1_EMMC_DATA1;
inout         SD_DATA2_EMMC_DATA2;
inout         SD_DATA3_EMMC_DATA3;
inout         SPI_1_CLK;
inout         SPI_1_SS0;
inout         USB_DATA0;
inout         USB_DATA1;
inout         USB_DATA2;
inout         USB_DATA3;
inout         USB_DATA4;
inout         USB_DATA5;
inout         USB_DATA6;
inout         USB_DATA7;
//--------------------------------------------------------------------
// Nets
//--------------------------------------------------------------------
wire   [13:0] A_net_0;
wire          ACT_N_net_0;
wire          Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PENABLE;
wire   [31:0] Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PRDATA;
wire          Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PREADY;
wire          Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PSELx;
wire          Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PSLVERR;
wire   [31:0] Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PWDATA;
wire          Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PWRITE;
wire          Aldec_MSS_2022_2_I2C_0_SCL_OE_M2F;
wire          Aldec_MSS_2022_2_I2C_0_SDA_OE_M2F;
wire          Aldec_MSS_2022_2_MMUART_4_TXD_M2F;
wire   [31:0] APB_ARBITER_0_APB_MASTER_low_PADDR;
wire          APB_ARBITER_0_APB_MASTER_low_PENABLE;
wire   [31:0] APB_ARBITER_0_APB_MASTER_low_PRDATA;
wire          APB_ARBITER_0_APB_MASTER_low_PREADY;
wire          APB_ARBITER_0_APB_MASTER_low_PSELx;
wire          APB_ARBITER_0_APB_MASTER_low_PSLVERR;
wire   [31:0] APB_ARBITER_0_APB_MASTER_low_PWDATA;
wire          APB_ARBITER_0_APB_MASTER_low_PWRITE;
wire   [31:0] APB_PASS_THROUGH_0_APB_INITIATOR_PADDR;
wire          APB_PASS_THROUGH_0_APB_INITIATOR_PENABLE;
wire   [31:0] APB_PASS_THROUGH_0_APB_INITIATOR_PRDATA;
wire          APB_PASS_THROUGH_0_APB_INITIATOR_PREADY;
wire          APB_PASS_THROUGH_0_APB_INITIATOR_PSELx;
wire          APB_PASS_THROUGH_0_APB_INITIATOR_PSLVERR;
wire   [31:0] APB_PASS_THROUGH_0_APB_INITIATOR_PWDATA;
wire          APB_PASS_THROUGH_0_APB_INITIATOR_PWRITE;
wire   [1:0]  BA_net_0;
wire   [1:0]  BG_net_0;
wire          BIBUF_0_Y;
wire          BIBUF_1_Y;
wire          CAN_0_RXBUS_F2M;
wire          CAN_0_TXBUS_M2F_net_0;
wire          CAS_N_net_0;
wire          CK0_net_0;
wire          CK0_N_net_0;
wire          CKE0_net_0;
wire          CORERESET_PF_C0_0_PLL_POWERDOWN_B;
wire          CS0_N_net_0;
wire   [35:0] DQ;
wire   [4:0]  DQS;
wire   [4:0]  DQS_N;
wire   [31:0] FIC_3_0x4FFF_Fxxx_0_APBmslave15_PADDR;
wire          FIC_3_0x4FFF_Fxxx_0_APBmslave15_PENABLE;
wire   [31:0] FIC_3_0x4FFF_Fxxx_0_APBmslave15_PRDATA;
wire          FIC_3_0x4FFF_Fxxx_0_APBmslave15_PREADY;
wire          FIC_3_0x4FFF_Fxxx_0_APBmslave15_PSELx;
wire          FIC_3_0x4FFF_Fxxx_0_APBmslave15_PSLVERR;
wire   [31:0] FIC_3_0x4FFF_Fxxx_0_APBmslave15_PWDATA;
wire          FIC_3_0x4FFF_Fxxx_0_APBmslave15_PWRITE;
wire   [31:0] FIC_3_0x4xxx_xxxx_0_APBmslave15_PADDR;
wire          FIC_3_0x4xxx_xxxx_0_APBmslave15_PENABLE;
wire   [31:0] FIC_3_0x4xxx_xxxx_0_APBmslave15_PRDATA;
wire          FIC_3_0x4xxx_xxxx_0_APBmslave15_PREADY;
wire          FIC_3_0x4xxx_xxxx_0_APBmslave15_PSELx;
wire          FIC_3_0x4xxx_xxxx_0_APBmslave15_PSLVERR;
wire   [31:0] FIC_3_0x4xxx_xxxx_0_APBmslave15_PWDATA;
wire          FIC_3_0x4xxx_xxxx_0_APBmslave15_PWRITE;
wire          GPIO_1_20_IN;
wire          GPIO_1_23_OUT_net_0;
wire          I2C_0_SCL;
wire          I2C_0_SDA;
wire          I2C_1_SCL;
wire          I2C_1_SDA;
wire          MAC_1_MDC_net_0;
wire          MAC_1_MDIO;
wire          MMUART_0_RXD;
wire          MMUART_0_TXD_net_0;
wire          MMUART_1_RXD_F2M;
wire          MMUART_1_TXD_M2F_net_0;
wire          MMUART_2_RXD_F2M;
wire          MMUART_2_TXD_M2F_net_0;
wire          MMUART_3_RXD_F2M;
wire          MMUART_3_TXD_M2F_net_0;
wire          ODT0_net_0;
wire          PF_CCC_C0_0_OUT3_FABCLK_0;
wire          PF_CCC_C0_0_PLL_LOCK_0;
wire          PF_OSC_C0_0_RCOSC_160MHZ_GL;
wire          PFSOC_INIT_MONITOR_C0_0_BANK_0_VDDI_STATUS;
wire          PFSOC_INIT_MONITOR_C0_0_DEVICE_INIT_DONE;
wire          PFSOC_INIT_MONITOR_C0_0_FABRIC_POR_N;
wire          RAS_N_net_0;
wire          REFCLK;
wire          REFCLK_N;
wire          RESET_N_net_0;
wire          SD_CD_EMMC_STRB;
wire          SD_CLK_EMMC_CLK_net_0;
wire          SD_CMD_EMMC_CMD;
wire          SD_DATA0_EMMC_DATA0;
wire          SD_DATA1_EMMC_DATA1;
wire          SD_DATA2_EMMC_DATA2;
wire          SD_DATA3_EMMC_DATA3;
wire          SD_POW_EMMC_DATA4_net_0;
wire          SD_SEL_net_0;
wire          SD_VOLT_CMD_DIR_EMMC_DATA7_net_0;
wire          SD_VOLT_DIR_0_EMMC_UNUSED_net_0;
wire          SD_VOLT_DIR_1_3_EMMC_UNUSED_net_0;
wire          SD_VOLT_EN_EMMC_DATA6_net_0;
wire          SD_VOLT_SEL_EMMC_DATA5_net_0;
wire          SD_WP_EMMC_RSTN;
wire          SGMII_RX0_N;
wire          SGMII_RX0_P;
wire          SGMII_RX1_N;
wire          SGMII_RX1_P;
wire          SGMII_TX0_N_net_0;
wire          SGMII_TX0_P_net_0;
wire          SGMII_TX1_N_net_0;
wire          SGMII_TX1_P_net_0;
wire          SPI_1_CLK;
wire          SPI_1_DI;
wire          SPI_1_DO_net_0;
wire          SPI_1_SS0;
wire          USB_CLK;
wire          USB_DATA0;
wire          USB_DATA1;
wire          USB_DATA2;
wire          USB_DATA3;
wire          USB_DATA4;
wire          USB_DATA5;
wire          USB_DATA6;
wire          USB_DATA7;
wire          USB_DIR;
wire          USB_NXT;
wire          USB_STP_net_0;
wire          USB_ULPI_RESET_net_0;
wire          WE_N_net_0;
wire          ACT_N_net_1;
wire          CAN_0_TXBUS_M2F_net_1;
wire          CAS_N_net_1;
wire          CK0_N_net_1;
wire          CK0_net_1;
wire          CKE0_net_1;
wire          CS0_N_net_1;
wire          GPIO_1_23_OUT_net_1;
wire          MAC_1_MDC_net_1;
wire          MMUART_0_TXD_net_1;
wire          MMUART_1_TXD_M2F_net_1;
wire          MMUART_2_TXD_M2F_net_1;
wire          MMUART_3_TXD_M2F_net_1;
wire          ODT0_net_1;
wire          RAS_N_net_1;
wire          RESET_N_net_1;
wire          SD_CLK_EMMC_CLK_net_1;
wire          SD_POW_EMMC_DATA4_net_1;
wire          SD_SEL_net_1;
wire          SD_VOLT_CMD_DIR_EMMC_DATA7_net_1;
wire          SD_VOLT_DIR_0_EMMC_UNUSED_net_1;
wire          SD_VOLT_DIR_1_3_EMMC_UNUSED_net_1;
wire          SD_VOLT_EN_EMMC_DATA6_net_1;
wire          SD_VOLT_SEL_EMMC_DATA5_net_1;
wire          SGMII_TX0_N_net_1;
wire          SGMII_TX0_P_net_1;
wire          SGMII_TX1_N_net_1;
wire          SGMII_TX1_P_net_1;
wire          SPI_1_DO_net_1;
wire          USB_STP_net_1;
wire          USB_ULPI_RESET_net_2;
wire          WE_N_net_1;
wire   [13:0] A_net_1;
wire   [1:0]  BA_net_1;
wire   [1:0]  BG_net_1;
//--------------------------------------------------------------------
// TiedOff Nets
//--------------------------------------------------------------------
wire          GND_net;
wire          VCC_net;
wire   [3:0]  QSPI_DATA_F2M_const_net_0;
wire   [7:0]  FIC_0_AXI4_M_BID_const_net_0;
wire   [1:0]  FIC_0_AXI4_M_BRESP_const_net_0;
wire   [7:0]  FIC_0_AXI4_M_RID_const_net_0;
wire   [63:0] FIC_0_AXI4_M_RDATA_const_net_0;
wire   [1:0]  FIC_0_AXI4_M_RRESP_const_net_0;
wire   [31:0] out_high_prdata_const_net_0;
wire   [31:0] PRDATAS0_const_net_0;
wire   [31:0] PRDATAS16_const_net_0;
//--------------------------------------------------------------------
// Inverted Nets
//--------------------------------------------------------------------
wire          USB_ULPI_RESET_net_1;
wire          USB_ULPI_RESET_OUT_PRE_INV0_0;
//--------------------------------------------------------------------
// Bus Interface Nets Declarations - Unequal Pin Widths
//--------------------------------------------------------------------
wire   [28:0] Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR;
wire   [31:0] Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0;
wire   [28:0] Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0_28to0;
wire   [31:29]Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0_31to29;
//--------------------------------------------------------------------
// Constant assignments
//--------------------------------------------------------------------
assign GND_net                        = 1'b0;
assign VCC_net                        = 1'b1;
assign QSPI_DATA_F2M_const_net_0      = 4'h0;
assign FIC_0_AXI4_M_BID_const_net_0   = 8'h00;
assign FIC_0_AXI4_M_BRESP_const_net_0 = 2'h0;
assign FIC_0_AXI4_M_RID_const_net_0   = 8'h00;
assign FIC_0_AXI4_M_RDATA_const_net_0 = 64'h0000000000000000;
assign FIC_0_AXI4_M_RRESP_const_net_0 = 2'h0;
assign out_high_prdata_const_net_0    = 32'h00000000;
assign PRDATAS0_const_net_0           = 32'h00000000;
assign PRDATAS16_const_net_0          = 32'h00000000;
//--------------------------------------------------------------------
// Inversions
//--------------------------------------------------------------------
assign USB_ULPI_RESET_net_1 = ~ USB_ULPI_RESET_OUT_PRE_INV0_0;
//--------------------------------------------------------------------
// TieOff assignments
//--------------------------------------------------------------------
assign CAN_0_STANDBY                     = 1'b0;
assign VSC_8662_CMODE7                   = 1'b0;
assign VSC_8662_SRESET                   = 1'b1;
//--------------------------------------------------------------------
// Top level output port assignments
//--------------------------------------------------------------------
assign ACT_N_net_1                       = ACT_N_net_0;
assign ACT_N                             = ACT_N_net_1;
assign CAN_0_TXBUS_M2F_net_1             = CAN_0_TXBUS_M2F_net_0;
assign CAN_0_TXBUS_M2F                   = CAN_0_TXBUS_M2F_net_1;
assign CAS_N_net_1                       = CAS_N_net_0;
assign CAS_N                             = CAS_N_net_1;
assign CK0_N_net_1                       = CK0_N_net_0;
assign CK0_N                             = CK0_N_net_1;
assign CK0_net_1                         = CK0_net_0;
assign CK0                               = CK0_net_1;
assign CKE0_net_1                        = CKE0_net_0;
assign CKE0                              = CKE0_net_1;
assign CS0_N_net_1                       = CS0_N_net_0;
assign CS0_N                             = CS0_N_net_1;
assign GPIO_1_23_OUT_net_1               = GPIO_1_23_OUT_net_0;
assign GPIO_1_23_OUT                     = GPIO_1_23_OUT_net_1;
assign MAC_1_MDC_net_1                   = MAC_1_MDC_net_0;
assign MAC_1_MDC                         = MAC_1_MDC_net_1;
assign MMUART_0_TXD_net_1                = MMUART_0_TXD_net_0;
assign MMUART_0_TXD                      = MMUART_0_TXD_net_1;
assign MMUART_1_TXD_M2F_net_1            = MMUART_1_TXD_M2F_net_0;
assign MMUART_1_TXD_M2F                  = MMUART_1_TXD_M2F_net_1;
assign MMUART_2_TXD_M2F_net_1            = MMUART_2_TXD_M2F_net_0;
assign MMUART_2_TXD_M2F                  = MMUART_2_TXD_M2F_net_1;
assign MMUART_3_TXD_M2F_net_1            = MMUART_3_TXD_M2F_net_0;
assign MMUART_3_TXD_M2F                  = MMUART_3_TXD_M2F_net_1;
assign ODT0_net_1                        = ODT0_net_0;
assign ODT0                              = ODT0_net_1;
assign RAS_N_net_1                       = RAS_N_net_0;
assign RAS_N                             = RAS_N_net_1;
assign RESET_N_net_1                     = RESET_N_net_0;
assign RESET_N                           = RESET_N_net_1;
assign SD_CLK_EMMC_CLK_net_1             = SD_CLK_EMMC_CLK_net_0;
assign SD_CLK_EMMC_CLK                   = SD_CLK_EMMC_CLK_net_1;
assign SD_POW_EMMC_DATA4_net_1           = SD_POW_EMMC_DATA4_net_0;
assign SD_POW_EMMC_DATA4                 = SD_POW_EMMC_DATA4_net_1;
assign SD_SEL_net_1                      = SD_SEL_net_0;
assign SD_SEL                            = SD_SEL_net_1;
assign SD_VOLT_CMD_DIR_EMMC_DATA7_net_1  = SD_VOLT_CMD_DIR_EMMC_DATA7_net_0;
assign SD_VOLT_CMD_DIR_EMMC_DATA7        = SD_VOLT_CMD_DIR_EMMC_DATA7_net_1;
assign SD_VOLT_DIR_0_EMMC_UNUSED_net_1   = SD_VOLT_DIR_0_EMMC_UNUSED_net_0;
assign SD_VOLT_DIR_0_EMMC_UNUSED         = SD_VOLT_DIR_0_EMMC_UNUSED_net_1;
assign SD_VOLT_DIR_1_3_EMMC_UNUSED_net_1 = SD_VOLT_DIR_1_3_EMMC_UNUSED_net_0;
assign SD_VOLT_DIR_1_3_EMMC_UNUSED       = SD_VOLT_DIR_1_3_EMMC_UNUSED_net_1;
assign SD_VOLT_EN_EMMC_DATA6_net_1       = SD_VOLT_EN_EMMC_DATA6_net_0;
assign SD_VOLT_EN_EMMC_DATA6             = SD_VOLT_EN_EMMC_DATA6_net_1;
assign SD_VOLT_SEL_EMMC_DATA5_net_1      = SD_VOLT_SEL_EMMC_DATA5_net_0;
assign SD_VOLT_SEL_EMMC_DATA5            = SD_VOLT_SEL_EMMC_DATA5_net_1;
assign SGMII_TX0_N_net_1                 = SGMII_TX0_N_net_0;
assign SGMII_TX0_N                       = SGMII_TX0_N_net_1;
assign SGMII_TX0_P_net_1                 = SGMII_TX0_P_net_0;
assign SGMII_TX0_P                       = SGMII_TX0_P_net_1;
assign SGMII_TX1_N_net_1                 = SGMII_TX1_N_net_0;
assign SGMII_TX1_N                       = SGMII_TX1_N_net_1;
assign SGMII_TX1_P_net_1                 = SGMII_TX1_P_net_0;
assign SGMII_TX1_P                       = SGMII_TX1_P_net_1;
assign SPI_1_DO_net_1                    = SPI_1_DO_net_0;
assign SPI_1_DO                          = SPI_1_DO_net_1;
assign USB_STP_net_1                     = USB_STP_net_0;
assign USB_STP                           = USB_STP_net_1;
assign USB_ULPI_RESET_OUT_PRE_INV0_0     = USB_ULPI_RESET_net_0;
assign USB_ULPI_RESET                    = USB_ULPI_RESET_net_1;
assign USB_ULPI_RESET_net_2              = USB_ULPI_RESET_net_0;
assign VSC_8662_RESETN                   = USB_ULPI_RESET_net_2;
assign WE_N_net_1                        = WE_N_net_0;
assign WE_N                              = WE_N_net_1;
assign A_net_1                           = A_net_0;
assign A[13:0]                           = A_net_1;
assign BA_net_1                          = BA_net_0;
assign BA[1:0]                           = BA_net_1;
assign BG_net_1                          = BG_net_0;
assign BG[1:0]                           = BG_net_1;
//--------------------------------------------------------------------
// Bus Interface Nets Assignments - Unequal Pin Widths
//--------------------------------------------------------------------
assign Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0 = { Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0_31to29, Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0_28to0 };
assign Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0_28to0 = Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR[28:0];
assign Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0_31to29 = 3'h0;

//--------------------------------------------------------------------
// Component instances
//--------------------------------------------------------------------
//--------Aldec_MSS_2022_2
Aldec_MSS_2022_2 Aldec_MSS_2022_2_inst_0(
        // Inputs
        .FIC_0_ACLK                   ( PF_CCC_C0_0_OUT3_FABCLK_0 ),
        .FIC_0_AXI4_M_AWREADY         ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_M_WREADY          ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_M_BID             ( FIC_0_AXI4_M_BID_const_net_0 ), // tied to 8'h00 from definition
        .FIC_0_AXI4_M_BRESP           ( FIC_0_AXI4_M_BRESP_const_net_0 ), // tied to 2'h0 from definition
        .FIC_0_AXI4_M_BVALID          ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_M_ARREADY         ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_M_RID             ( FIC_0_AXI4_M_RID_const_net_0 ), // tied to 8'h00 from definition
        .FIC_0_AXI4_M_RDATA           ( FIC_0_AXI4_M_RDATA_const_net_0 ), // tied to 64'h0000000000000000 from definition
        .FIC_0_AXI4_M_RRESP           ( FIC_0_AXI4_M_RRESP_const_net_0 ), // tied to 2'h0 from definition
        .FIC_0_AXI4_M_RLAST           ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_M_RVALID          ( GND_net ), // tied to 1'b0 from definition
        .FIC_3_PCLK                   ( PF_CCC_C0_0_OUT3_FABCLK_0 ),
        .FIC_3_APB_M_PRDATA           ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PRDATA ),
        .FIC_3_APB_M_PREADY           ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PREADY ),
        .FIC_3_APB_M_PSLVERR          ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PSLVERR ),
        .MMUART_1_RXD_F2M             ( MMUART_1_RXD_F2M ),
        .MMUART_2_RXD_F2M             ( MMUART_2_RXD_F2M ),
        .MMUART_3_RXD_F2M             ( MMUART_3_RXD_F2M ),
        .MMUART_4_RXD_F2M             ( Aldec_MSS_2022_2_MMUART_4_TXD_M2F ),
        .CAN_0_RXBUS_F2M              ( CAN_0_RXBUS_F2M ),
        .CAN_1_RXBUS_F2M              ( GND_net ),
        .QSPI_DATA_F2M                ( QSPI_DATA_F2M_const_net_0 ),
        .I2C_0_SCL_F2M                ( BIBUF_0_Y ),
        .I2C_0_SDA_F2M                ( BIBUF_1_Y ),
        .MSS_RESET_N_F2M              ( USB_ULPI_RESET_net_0 ),
        .MMUART_0_RXD                 ( MMUART_0_RXD ),
        .GPIO_1_20_IN                 ( GPIO_1_20_IN ),
        .USB_CLK                      ( USB_CLK ),
        .USB_DIR                      ( USB_DIR ),
        .USB_NXT                      ( USB_NXT ),
        .SPI_1_DI                     ( SPI_1_DI ),
        .SD_CD_EMMC_STRB              ( SD_CD_EMMC_STRB ),
        .SD_WP_EMMC_RSTN              ( SD_WP_EMMC_RSTN ),
        .SGMII_RX1_P                  ( SGMII_RX1_P ),
        .SGMII_RX1_N                  ( SGMII_RX1_N ),
        .SGMII_RX0_P                  ( SGMII_RX0_P ),
        .SGMII_RX0_N                  ( SGMII_RX0_N ),
        .REFCLK                       ( REFCLK ),
        .REFCLK_N                     ( REFCLK_N ),
        // Outputs
        .FIC_0_DLL_LOCK_M2F           (  ),
        .FIC_3_DLL_LOCK_M2F           (  ),
        .FIC_0_AXI4_M_AWID            (  ),
        .FIC_0_AXI4_M_AWADDR          (  ),
        .FIC_0_AXI4_M_AWLEN           (  ),
        .FIC_0_AXI4_M_AWSIZE          (  ),
        .FIC_0_AXI4_M_AWBURST         (  ),
        .FIC_0_AXI4_M_AWLOCK          (  ),
        .FIC_0_AXI4_M_AWQOS           (  ),
        .FIC_0_AXI4_M_AWCACHE         (  ),
        .FIC_0_AXI4_M_AWPROT          (  ),
        .FIC_0_AXI4_M_AWVALID         (  ),
        .FIC_0_AXI4_M_WDATA           (  ),
        .FIC_0_AXI4_M_WSTRB           (  ),
        .FIC_0_AXI4_M_WLAST           (  ),
        .FIC_0_AXI4_M_WVALID          (  ),
        .FIC_0_AXI4_M_BREADY          (  ),
        .FIC_0_AXI4_M_ARID            (  ),
        .FIC_0_AXI4_M_ARADDR          (  ),
        .FIC_0_AXI4_M_ARLEN           (  ),
        .FIC_0_AXI4_M_ARSIZE          (  ),
        .FIC_0_AXI4_M_ARBURST         (  ),
        .FIC_0_AXI4_M_ARLOCK          (  ),
        .FIC_0_AXI4_M_ARQOS           (  ),
        .FIC_0_AXI4_M_ARCACHE         (  ),
        .FIC_0_AXI4_M_ARPROT          (  ),
        .FIC_0_AXI4_M_ARVALID         (  ),
        .FIC_0_AXI4_M_RREADY          (  ),
        .FIC_3_APB_M_PSEL             ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PSELx ),
        .FIC_3_APB_M_PADDR            ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR ),
        .FIC_3_APB_M_PWRITE           ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PWRITE ),
        .FIC_3_APB_M_PENABLE          ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PENABLE ),
        .FIC_3_APB_M_PSTRB            (  ),
        .FIC_3_APB_M_PWDATA           ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PWDATA ),
        .MMUART_1_TXD_M2F             ( MMUART_1_TXD_M2F_net_0 ),
        .MMUART_1_TXD_OE_M2F          (  ),
        .MMUART_2_TXD_M2F             ( MMUART_2_TXD_M2F_net_0 ),
        .MMUART_3_TXD_M2F             ( MMUART_3_TXD_M2F_net_0 ),
        .MMUART_4_TXD_M2F             ( Aldec_MSS_2022_2_MMUART_4_TXD_M2F ),
        .CAN_0_TX_EBL_M2F             (  ),
        .CAN_0_TXBUS_M2F              ( CAN_0_TXBUS_M2F_net_0 ),
        .CAN_1_TX_EBL_M2F             (  ),
        .CAN_1_TXBUS_M2F              (  ),
        .QSPI_SEL_M2F                 (  ),
        .QSPI_SEL_OE_M2F              (  ),
        .QSPI_DATA_M2F                (  ),
        .QSPI_DATA_OE_M2F             (  ),
        .I2C_0_SCL_OE_M2F             ( Aldec_MSS_2022_2_I2C_0_SCL_OE_M2F ),
        .I2C_0_SDA_OE_M2F             ( Aldec_MSS_2022_2_I2C_0_SDA_OE_M2F ),
        .PLL_CPU_LOCK_M2F             (  ),
        .PLL_DDR_LOCK_M2F             (  ),
        .PLL_SGMII_LOCK_M2F           (  ),
        .MSS_RESET_N_M2F              (  ),
        .MAC_0_TSU_SOF_TX_M2F         (  ),
        .MAC_0_TSU_SYNC_FRAME_TX_M2F  (  ),
        .MAC_0_TSU_DELAY_REQ_TX_M2F   (  ),
        .MAC_0_TSU_PDELAY_REQ_TX_M2F  (  ),
        .MAC_0_TSU_PDELAY_RESP_TX_M2F (  ),
        .MAC_0_TSU_SOF_RX_M2F         (  ),
        .MAC_0_TSU_SYNC_FRAME_RX_M2F  (  ),
        .MAC_0_TSU_DELAY_REQ_RX_M2F   (  ),
        .MAC_0_TSU_PDELAY_REQ_RX_M2F  (  ),
        .MAC_0_TSU_PDELAY_RESP_RX_M2F (  ),
        .MAC_1_TSU_SOF_TX_M2F         (  ),
        .MAC_1_TSU_SYNC_FRAME_TX_M2F  (  ),
        .MAC_1_TSU_DELAY_REQ_TX_M2F   (  ),
        .MAC_1_TSU_PDELAY_REQ_TX_M2F  (  ),
        .MAC_1_TSU_PDELAY_RESP_TX_M2F (  ),
        .MAC_1_TSU_SOF_RX_M2F         (  ),
        .MAC_1_TSU_SYNC_FRAME_RX_M2F  (  ),
        .MAC_1_TSU_DELAY_REQ_RX_M2F   (  ),
        .MAC_1_TSU_PDELAY_REQ_RX_M2F  (  ),
        .MAC_1_TSU_PDELAY_RESP_RX_M2F (  ),
        .MMUART_0_TXD                 ( MMUART_0_TXD_net_0 ),
        .MAC_1_MDC                    ( MAC_1_MDC_net_0 ),
        .GPIO_1_23_OUT                ( GPIO_1_23_OUT_net_0 ),
        .USB_STP                      ( USB_STP_net_0 ),
        .SPI_1_DO                     ( SPI_1_DO_net_0 ),
        .SD_CLK_EMMC_CLK              ( SD_CLK_EMMC_CLK_net_0 ),
        .SD_POW_EMMC_DATA4            ( SD_POW_EMMC_DATA4_net_0 ),
        .SD_VOLT_SEL_EMMC_DATA5       ( SD_VOLT_SEL_EMMC_DATA5_net_0 ),
        .SD_VOLT_EN_EMMC_DATA6        ( SD_VOLT_EN_EMMC_DATA6_net_0 ),
        .SD_VOLT_CMD_DIR_EMMC_DATA7   ( SD_VOLT_CMD_DIR_EMMC_DATA7_net_0 ),
        .SD_VOLT_DIR_0_EMMC_UNUSED    ( SD_VOLT_DIR_0_EMMC_UNUSED_net_0 ),
        .SD_VOLT_DIR_1_3_EMMC_UNUSED  ( SD_VOLT_DIR_1_3_EMMC_UNUSED_net_0 ),
        .SGMII_TX1_P                  ( SGMII_TX1_P_net_0 ),
        .SGMII_TX1_N                  ( SGMII_TX1_N_net_0 ),
        .SGMII_TX0_P                  ( SGMII_TX0_P_net_0 ),
        .SGMII_TX0_N                  ( SGMII_TX0_N_net_0 ),
        .BA                           ( BA_net_0 ),
        .A                            ( A_net_0 ),
        .RESET_N                      ( RESET_N_net_0 ),
        .CKE0                         ( CKE0_net_0 ),
        .CS0_N                        ( CS0_N_net_0 ),
        .ODT0                         ( ODT0_net_0 ),
        .CK0                          ( CK0_net_0 ),
        .CK0_N                        ( CK0_N_net_0 ),
        .RAS_N                        ( RAS_N_net_0 ),
        .WE_N                         ( WE_N_net_0 ),
        .CAS_N                        ( CAS_N_net_0 ),
        .ACT_N                        ( ACT_N_net_0 ),
        .BG                           ( BG_net_0 ),
        // Inouts
        .I2C_1_SCL                    ( I2C_1_SCL ),
        .I2C_1_SDA                    ( I2C_1_SDA ),
        .MAC_1_MDIO                   ( MAC_1_MDIO ),
        .USB_DATA0                    ( USB_DATA0 ),
        .USB_DATA1                    ( USB_DATA1 ),
        .USB_DATA2                    ( USB_DATA2 ),
        .USB_DATA3                    ( USB_DATA3 ),
        .USB_DATA4                    ( USB_DATA4 ),
        .USB_DATA5                    ( USB_DATA5 ),
        .USB_DATA6                    ( USB_DATA6 ),
        .USB_DATA7                    ( USB_DATA7 ),
        .SPI_1_SS0                    ( SPI_1_SS0 ),
        .SPI_1_CLK                    ( SPI_1_CLK ),
        .SD_CMD_EMMC_CMD              ( SD_CMD_EMMC_CMD ),
        .SD_DATA0_EMMC_DATA0          ( SD_DATA0_EMMC_DATA0 ),
        .SD_DATA1_EMMC_DATA1          ( SD_DATA1_EMMC_DATA1 ),
        .SD_DATA2_EMMC_DATA2          ( SD_DATA2_EMMC_DATA2 ),
        .SD_DATA3_EMMC_DATA3          ( SD_DATA3_EMMC_DATA3 ),
        .DQ                           ( DQ ),
        .DQS                          ( DQS ),
        .DQS_N                        ( DQS_N ) 
        );

//--------APB_ARBITER
APB_ARBITER #( 
        .select_bit ( 28 ) )
APB_ARBITER_0(
        // Inputs
        .in_penable       ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PENABLE ),
        .in_psel          ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PSELx ),
        .in_paddr         ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0 ),
        .in_pwrite        ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PWRITE ),
        .in_pwdata        ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PWDATA ),
        .out_low_prdata   ( APB_ARBITER_0_APB_MASTER_low_PRDATA ),
        .out_low_pready   ( APB_ARBITER_0_APB_MASTER_low_PREADY ),
        .out_low_pslverr  ( APB_ARBITER_0_APB_MASTER_low_PSLVERR ),
        .out_high_prdata  ( out_high_prdata_const_net_0 ), // tied to 32'h00000000 from definition
        .out_high_pready  ( VCC_net ), // tied to 1'b1 from definition
        .out_high_pslverr ( GND_net ), // tied to 1'b0 from definition
        // Outputs
        .in_prdata        ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PRDATA ),
        .in_pready        ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PREADY ),
        .in_pslverr       ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PSLVERR ),
        .out_low_penable  ( APB_ARBITER_0_APB_MASTER_low_PENABLE ),
        .out_low_psel     ( APB_ARBITER_0_APB_MASTER_low_PSELx ),
        .out_low_paddr    ( APB_ARBITER_0_APB_MASTER_low_PADDR ),
        .out_low_pwrite   ( APB_ARBITER_0_APB_MASTER_low_PWRITE ),
        .out_low_pwdata   ( APB_ARBITER_0_APB_MASTER_low_PWDATA ),
        .out_high_penable (  ),
        .out_high_psel    (  ),
        .out_high_paddr   (  ),
        .out_high_pwrite  (  ),
        .out_high_pwdata  (  ) 
        );

//--------APB_PASS_THROUGH
APB_PASS_THROUGH APB_PASS_THROUGH_0(
        // Inputs
        .target_penable    ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PENABLE ),
        .target_psel       ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PSELx ),
        .target_paddr      ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PADDR ),
        .target_pwrite     ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PWRITE ),
        .target_pwdata     ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PWDATA ),
        .initiator_prdata  ( APB_PASS_THROUGH_0_APB_INITIATOR_PRDATA ),
        .initiator_pready  ( APB_PASS_THROUGH_0_APB_INITIATOR_PREADY ),
        .initiator_pslverr ( APB_PASS_THROUGH_0_APB_INITIATOR_PSLVERR ),
        // Outputs
        .target_prdata     ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PRDATA ),
        .target_pready     ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PREADY ),
        .target_pslverr    ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PSLVERR ),
        .initiator_penable ( APB_PASS_THROUGH_0_APB_INITIATOR_PENABLE ),
        .initiator_psel    ( APB_PASS_THROUGH_0_APB_INITIATOR_PSELx ),
        .initiator_paddr   ( APB_PASS_THROUGH_0_APB_INITIATOR_PADDR ),
        .initiator_pwrite  ( APB_PASS_THROUGH_0_APB_INITIATOR_PWRITE ),
        .initiator_pwdata  ( APB_PASS_THROUGH_0_APB_INITIATOR_PWDATA ) 
        );

//--------BIBUF
BIBUF BIBUF_0(
        // Inputs
        .D   ( GND_net ),
        .E   ( Aldec_MSS_2022_2_I2C_0_SCL_OE_M2F ),
        // Outputs
        .Y   ( BIBUF_0_Y ),
        // Inouts
        .PAD ( I2C_0_SCL ) 
        );

//--------BIBUF
BIBUF BIBUF_1(
        // Inputs
        .D   ( GND_net ),
        .E   ( Aldec_MSS_2022_2_I2C_0_SDA_OE_M2F ),
        // Outputs
        .Y   ( BIBUF_1_Y ),
        // Inouts
        .PAD ( I2C_0_SDA ) 
        );

//--------CORERESET_PF_C0
CORERESET_PF_C0 CORERESET_PF_C0_0(
        // Inputs
        .CLK                ( PF_CCC_C0_0_OUT3_FABCLK_0 ),
        .EXT_RST_N          ( VCC_net ),
        .BANK_x_VDDI_STATUS ( PFSOC_INIT_MONITOR_C0_0_BANK_0_VDDI_STATUS ),
        .BANK_y_VDDI_STATUS ( PFSOC_INIT_MONITOR_C0_0_BANK_0_VDDI_STATUS ),
        .PLL_LOCK           ( PF_CCC_C0_0_PLL_LOCK_0 ),
        .SS_BUSY            ( GND_net ),
        .INIT_DONE          ( PFSOC_INIT_MONITOR_C0_0_DEVICE_INIT_DONE ),
        .FF_US_RESTORE      ( GND_net ),
        .FPGA_POR_N         ( PFSOC_INIT_MONITOR_C0_0_FABRIC_POR_N ),
        // Outputs
        .PLL_POWERDOWN_B    ( CORERESET_PF_C0_0_PLL_POWERDOWN_B ),
        .FABRIC_RESET_N     ( USB_ULPI_RESET_net_0 ) 
        );

//--------fabric_sd_emmc_demux_select
fabric_sd_emmc_demux_select fabric_sd_emmc_demux_select_0(
        // Inputs
        .pclk                            ( PF_CCC_C0_0_OUT3_FABCLK_0 ),
        .presetn                         ( USB_ULPI_RESET_net_0 ),
        .penable                         ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PENABLE ),
        .psel                            ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PSELx ),
        .paddr                           ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PADDR ),
        .pwrite                          ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PWRITE ),
        .pwdata                          ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PWDATA ),
        // Outputs
        .prdata                          ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PRDATA ),
        .pready                          ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PREADY ),
        .pslverr                         ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PSLVERR ),
        .fabric_sd_emmc_demux_select_out ( SD_SEL_net_0 ) 
        );

//--------FIC_3_0x4FFF_Fxxx
FIC_3_0x4FFF_Fxxx FIC_3_0x4FFF_Fxxx_0(
        // Inputs
        .PADDR      ( APB_PASS_THROUGH_0_APB_INITIATOR_PADDR ),
        .PSEL       ( APB_PASS_THROUGH_0_APB_INITIATOR_PSELx ),
        .PENABLE    ( APB_PASS_THROUGH_0_APB_INITIATOR_PENABLE ),
        .PWRITE     ( APB_PASS_THROUGH_0_APB_INITIATOR_PWRITE ),
        .PWDATA     ( APB_PASS_THROUGH_0_APB_INITIATOR_PWDATA ),
        .PRDATAS15  ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PRDATA ),
        .PREADYS15  ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PREADY ),
        .PSLVERRS15 ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PSLVERR ),
        // Outputs
        .PRDATA     ( APB_PASS_THROUGH_0_APB_INITIATOR_PRDATA ),
        .PREADY     ( APB_PASS_THROUGH_0_APB_INITIATOR_PREADY ),
        .PSLVERR    ( APB_PASS_THROUGH_0_APB_INITIATOR_PSLVERR ),
        .PADDRS     ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PADDR ),
        .PSELS15    ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PSELx ),
        .PENABLES   ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PENABLE ),
        .PWRITES    ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PWRITE ),
        .PWDATAS    ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PWDATA ) 
        );

//--------FIC_3_0x4xxx_xxxx
FIC_3_0x4xxx_xxxx FIC_3_0x4xxx_xxxx_0(
        // Inputs
        .PADDR      ( APB_ARBITER_0_APB_MASTER_low_PADDR ),
        .PSEL       ( APB_ARBITER_0_APB_MASTER_low_PSELx ),
        .PENABLE    ( APB_ARBITER_0_APB_MASTER_low_PENABLE ),
        .PWRITE     ( APB_ARBITER_0_APB_MASTER_low_PWRITE ),
        .PWDATA     ( APB_ARBITER_0_APB_MASTER_low_PWDATA ),
        .PRDATAS0   ( PRDATAS0_const_net_0 ), // tied to 32'h00000000 from definition
        .PREADYS0   ( VCC_net ), // tied to 1'b1 from definition
        .PSLVERRS0  ( GND_net ), // tied to 1'b0 from definition
        .PRDATAS15  ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PRDATA ),
        .PREADYS15  ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PREADY ),
        .PSLVERRS15 ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PSLVERR ),
        .PRDATAS16  ( PRDATAS16_const_net_0 ), // tied to 32'h00000000 from definition
        .PREADYS16  ( VCC_net ), // tied to 1'b1 from definition
        .PSLVERRS16 ( GND_net ), // tied to 1'b0 from definition
        // Outputs
        .PRDATA     ( APB_ARBITER_0_APB_MASTER_low_PRDATA ),
        .PREADY     ( APB_ARBITER_0_APB_MASTER_low_PREADY ),
        .PSLVERR    ( APB_ARBITER_0_APB_MASTER_low_PSLVERR ),
        .PADDRS     ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PADDR ),
        .PSELS0     (  ),
        .PENABLES   ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PENABLE ),
        .PWRITES    ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PWRITE ),
        .PWDATAS    ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PWDATA ),
        .PSELS15    ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PSELx ),
        .PSELS16    (  ) 
        );

//--------PF_CCC_C0
PF_CCC_C0 PF_CCC_C0_0(
        // Inputs
        .REF_CLK_0         ( PF_OSC_C0_0_RCOSC_160MHZ_GL ),
        .PLL_POWERDOWN_N_0 ( CORERESET_PF_C0_0_PLL_POWERDOWN_B ),
        // Outputs
        .OUT3_FABCLK_0     ( PF_CCC_C0_0_OUT3_FABCLK_0 ),
        .PLL_LOCK_0        ( PF_CCC_C0_0_PLL_LOCK_0 ) 
        );

//--------PF_OSC_C0
PF_OSC_C0 PF_OSC_C0_0(
        // Outputs
        .RCOSC_160MHZ_GL ( PF_OSC_C0_0_RCOSC_160MHZ_GL ) 
        );

//--------PFSOC_INIT_MONITOR_C0
PFSOC_INIT_MONITOR_C0 PFSOC_INIT_MONITOR_C0_0(
        // Outputs
        .FABRIC_POR_N               ( PFSOC_INIT_MONITOR_C0_0_FABRIC_POR_N ),
        .PCIE_INIT_DONE             (  ),
        .USRAM_INIT_DONE            (  ),
        .SRAM_INIT_DONE             (  ),
        .DEVICE_INIT_DONE           ( PFSOC_INIT_MONITOR_C0_0_DEVICE_INIT_DONE ),
        .BANK_0_VDDI_STATUS         ( PFSOC_INIT_MONITOR_C0_0_BANK_0_VDDI_STATUS ),
        .XCVR_INIT_DONE             (  ),
        .USRAM_INIT_FROM_SNVM_DONE  (  ),
        .USRAM_INIT_FROM_UPROM_DONE (  ),
        .USRAM_INIT_FROM_SPI_DONE   (  ),
        .SRAM_INIT_FROM_SNVM_DONE   (  ),
        .SRAM_INIT_FROM_UPROM_DONE  (  ),
        .SRAM_INIT_FROM_SPI_DONE    (  ),
        .AUTOCALIB_DONE             (  ) 
        );


endmodule
