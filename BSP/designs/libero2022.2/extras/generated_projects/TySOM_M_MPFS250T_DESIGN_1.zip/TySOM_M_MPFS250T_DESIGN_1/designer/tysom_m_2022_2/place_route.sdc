# Microsemi Corp.
# Date: 2025-Jan-14 13:48:45
# This file was generated based on the following SDC source files:
#   /home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/constraint/tysom_m_2022_2_derived_constraints.sdc
#

create_clock -name {PF_OSC_C0_0/PF_OSC_C0_0/I_OSC_160/CLK} -period 6.25 [ get_pins { PF_OSC_C0_0/PF_OSC_C0_0/I_OSC_160/CLK } ]
create_generated_clock -name {PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/OUT3} -multiply_by 25 -divide_by 64 -source [ get_pins { PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/REF_CLK_0 } ] -phase 0 [ get_pins { PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/OUT3 } ]
set_clock_uncertainty 0.135 [ get_clocks { PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/OUT3 } ]
set_clock_uncertainty -hold 0 -rise_from [ get_clocks { PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/OUT3 } ] -rise_to [ get_clocks { PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/OUT3 } ]
set_clock_uncertainty -hold 0 -fall_from [ get_clocks { PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/OUT3 } ] -fall_to [ get_clocks { PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/OUT3 } ]
set_clock_uncertainty 0.6 [ get_clocks { PF_OSC_C0_0/PF_OSC_C0_0/I_OSC_160/CLK } ]
set_clock_uncertainty -hold 0 -rise_from [ get_clocks { PF_OSC_C0_0/PF_OSC_C0_0/I_OSC_160/CLK } ] -rise_to [ get_clocks { PF_OSC_C0_0/PF_OSC_C0_0/I_OSC_160/CLK } ]
set_clock_uncertainty -hold 0 -fall_from [ get_clocks { PF_OSC_C0_0/PF_OSC_C0_0/I_OSC_160/CLK } ] -fall_to [ get_clocks { PF_OSC_C0_0/PF_OSC_C0_0/I_OSC_160/CLK } ]
