set_device \
    -family  PolarFireSoC \
    -die     PA5SOC250T_ES \
    -package fcg1152 \
    -speed   -1 \
    -tempr   {EXT} \
    -voltr   {EXT}
set_def {VOLTAGE} {1.0}
set_def {VCCI_1.2_VOLTR} {EXT}
set_def {VCCI_1.5_VOLTR} {EXT}
set_def {VCCI_1.8_VOLTR} {EXT}
set_def {VCCI_2.5_VOLTR} {EXT}
set_def {VCCI_3.3_VOLTR} {EXT}
set_def {RTG4_MITIGATION_ON} {0}
set_def USE_CONSTRAINTS_FLOW 1
set_def NETLIST_TYPE EDIF
set_name tysom_m_2022_2
set_workdir {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/designer/tysom_m_2022_2}
set_log     {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/designer/tysom_m_2022_2/tysom_m_2022_2_sdc.log}
set_design_state pre_layout
