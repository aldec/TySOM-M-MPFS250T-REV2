set_device -family {PolarFireSoC} -die {MPFS250T_ES} -speed {-1}
read_verilog -mode system_verilog {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/hdl/APB_ARBITER.v}
read_verilog -mode system_verilog {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/hdl/APB_PASS_THROUGH.v}
read_verilog -mode system_verilog {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/component/work/Aldec_MSS_2022_2/Aldec_MSS_2022_2.v}
read_verilog -mode system_verilog {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/component/work/CORERESET_PF_C0/CORERESET_PF_C0_0/core/corereset_pf.v}
read_verilog -mode system_verilog {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/component/work/CORERESET_PF_C0/CORERESET_PF_C0.v}
read_verilog -mode system_verilog -lib COREAPB3_LIB {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/component/Actel/DirectCore/CoreAPB3/4.2.100/rtl/vlog/core/coreapb3_muxptob3.v}
read_verilog -mode system_verilog -lib COREAPB3_LIB {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/component/Actel/DirectCore/CoreAPB3/4.2.100/rtl/vlog/core/coreapb3_iaddr_reg.v}
read_verilog -mode system_verilog -lib COREAPB3_LIB {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/component/Actel/DirectCore/CoreAPB3/4.2.100/rtl/vlog/core/coreapb3.v}
read_verilog -mode system_verilog {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/component/work/FIC_3_0x4FFF_Fxxx/FIC_3_0x4FFF_Fxxx.v}
read_verilog -mode system_verilog {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/component/work/FIC_3_0x4xxx_xxxx/FIC_3_0x4xxx_xxxx.v}
read_verilog -mode system_verilog {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/component/work/PFSOC_INIT_MONITOR_C0/PFSOC_INIT_MONITOR_C0_0/PFSOC_INIT_MONITOR_C0_PFSOC_INIT_MONITOR_C0_0_PFSOC_INIT_MONITOR.v}
read_verilog -mode system_verilog {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/component/work/PFSOC_INIT_MONITOR_C0/PFSOC_INIT_MONITOR_C0.v}
read_verilog -mode system_verilog {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/component/work/PF_CCC_C0/PF_CCC_C0_0/PF_CCC_C0_PF_CCC_C0_0_PF_CCC.v}
read_verilog -mode system_verilog {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/component/work/PF_CCC_C0/PF_CCC_C0.v}
read_verilog -mode system_verilog {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/component/work/PF_OSC_C0/PF_OSC_C0_0/PF_OSC_C0_PF_OSC_C0_0_PF_OSC.v}
read_verilog -mode system_verilog {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/component/work/PF_OSC_C0/PF_OSC_C0.v}
read_verilog -mode system_verilog {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/hdl/fabric_sd_emmc_demux_select.v}
read_verilog -mode system_verilog {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/component/work/tysom_m_2022_2/tysom_m_2022_2.v}
set_top_level {tysom_m_2022_2}
map_netlist
read_sdc {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/constraint/tysom_m_2022_2_derived_constraints.sdc}
check_constraints {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/constraint/synthesis_sdc_errors.log}
write_fdc {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/designer/tysom_m_2022_2/synthesis.fdc}
