read_sdc -scenario "place_and_route" -netlist "optimized" -pin_separator "/" -ignore_errors {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/designer/tysom_m_2022_2/place_route.sdc}
set_options -tdpr_scenario "place_and_route" 
save
set_options -analysis_scenario "place_and_route"
report -type combinational_loops -format xml {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/designer/tysom_m_2022_2/tysom_m_2022_2_layout_combinational_loops.xml}
report -type slack {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/designer/tysom_m_2022_2/pinslacks.txt}
set coverage [report \
    -type     constraints_coverage \
    -format   xml \
    -slacks   no \
    {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/designer/tysom_m_2022_2/tysom_m_2022_2_place_and_route_constraint_coverage.xml}]
set reportfile {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/designer/tysom_m_2022_2/coverage_placeandroute}
set fp [open $reportfile w]
puts $fp $coverage
close $fp