set_device -family {PolarFireSoC} -die {MPFS250T_ES} -speed {-1}
read_adl {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/designer/tysom_m_2022_2/tysom_m_2022_2.adl}
read_afl {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/designer/tysom_m_2022_2/tysom_m_2022_2.afl}
map_netlist
read_sdc {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/constraint/tysom_m_2022_2_derived_constraints.sdc}
check_constraints {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/constraint/placer_sdc_errors.log}
estimate_jitter -report {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/designer/tysom_m_2022_2/place_and_route_jitter_report.txt}
write_sdc -mode layout {/home/makro/Downloads/generated_projects/TySOM_M_MPFS250T_DESIGN_1/designer/tysom_m_2022_2/place_route.sdc}
