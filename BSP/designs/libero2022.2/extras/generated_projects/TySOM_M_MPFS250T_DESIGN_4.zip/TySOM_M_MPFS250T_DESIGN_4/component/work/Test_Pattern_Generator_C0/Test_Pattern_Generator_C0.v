//////////////////////////////////////////////////////////////////////
// Created by SmartDesign Tue Jan 14 12:23:43 2025
// Version: 2022.2 2022.2.0.10
//////////////////////////////////////////////////////////////////////

`timescale 1ns / 100ps

//////////////////////////////////////////////////////////////////////
// Component Description (Tcl) 
//////////////////////////////////////////////////////////////////////
/*
# Exporting Component Description of Test_Pattern_Generator_C0 to TCL
# Family: PolarFireSoC
# Part Number: MPFS250T_ES-1FCG1152E
# Create and Configure the core component Test_Pattern_Generator_C0
create_and_configure_core -core_vlnv {Microchip:SolutionCore:Test_Pattern_Generator:3.5.2} -component_name {Test_Pattern_Generator_C0} -params {\
"g_PIXEL_WIDTH:8"  \
"g_PIXELS_PER_CLK:1"  \
"H_RESOLUTION:1920"  \
"V_RESOLUTION:1080"   }
# Exporting Component Description of Test_Pattern_Generator_C0 to TCL done
*/

// Test_Pattern_Generator_C0
module Test_Pattern_Generator_C0(
    // Inputs
    BAYER_PATTERN_I,
    DATA_EN_I,
    FRAME_END_I,
    PATTERN_SEL_I,
    RESET_N_I,
    SYS_CLK_I,
    // Outputs
    BAYER_O,
    BLUE_O,
    DATA_VALID_O,
    FRAME_END_O,
    GREEN_O,
    LINE_END_O,
    RED_O
);

//--------------------------------------------------------------------
// Input
//--------------------------------------------------------------------
input  [1:0] BAYER_PATTERN_I;
input        DATA_EN_I;
input        FRAME_END_I;
input  [2:0] PATTERN_SEL_I;
input        RESET_N_I;
input        SYS_CLK_I;
//--------------------------------------------------------------------
// Output
//--------------------------------------------------------------------
output [7:0] BAYER_O;
output [7:0] BLUE_O;
output       DATA_VALID_O;
output       FRAME_END_O;
output [7:0] GREEN_O;
output       LINE_END_O;
output [7:0] RED_O;
//--------------------------------------------------------------------
// Nets
//--------------------------------------------------------------------
wire   [7:0] BAYER_O_net_0;
wire   [1:0] BAYER_PATTERN_I;
wire   [7:0] BLUE_O_net_0;
wire         DATA_EN_I;
wire         DATA_VALID_O_net_0;
wire         FRAME_END_I;
wire         FRAME_END_O_net_0;
wire   [7:0] GREEN_O_net_0;
wire         LINE_END_O_net_0;
wire   [2:0] PATTERN_SEL_I;
wire   [7:0] RED_O_net_0;
wire         RESET_N_I;
wire         SYS_CLK_I;
wire         DATA_VALID_O_net_1;
wire         FRAME_END_O_net_1;
wire         LINE_END_O_net_1;
wire   [7:0] RED_O_net_1;
wire   [7:0] GREEN_O_net_1;
wire   [7:0] BLUE_O_net_1;
wire   [7:0] BAYER_O_net_1;
//--------------------------------------------------------------------
// Top level output port assignments
//--------------------------------------------------------------------
assign DATA_VALID_O_net_1 = DATA_VALID_O_net_0;
assign DATA_VALID_O       = DATA_VALID_O_net_1;
assign FRAME_END_O_net_1  = FRAME_END_O_net_0;
assign FRAME_END_O        = FRAME_END_O_net_1;
assign LINE_END_O_net_1   = LINE_END_O_net_0;
assign LINE_END_O         = LINE_END_O_net_1;
assign RED_O_net_1        = RED_O_net_0;
assign RED_O[7:0]         = RED_O_net_1;
assign GREEN_O_net_1      = GREEN_O_net_0;
assign GREEN_O[7:0]       = GREEN_O_net_1;
assign BLUE_O_net_1       = BLUE_O_net_0;
assign BLUE_O[7:0]        = BLUE_O_net_1;
assign BAYER_O_net_1      = BAYER_O_net_0;
assign BAYER_O[7:0]       = BAYER_O_net_1;
//--------------------------------------------------------------------
// Component instances
//--------------------------------------------------------------------
//--------Test_Pattern_Generator   -   Microchip:SolutionCore:Test_Pattern_Generator:3.5.2
Test_Pattern_Generator #( 
        .g_PIXEL_WIDTH    ( 8 ),
        .g_PIXELS_PER_CLK ( 1 ),
        .H_RESOLUTION     ( 1920 ),
        .V_RESOLUTION     ( 1080 ) )
Test_Pattern_Generator_C0_0(
        // Inputs
        .SYS_CLK_I       ( SYS_CLK_I ),
        .RESET_N_I       ( RESET_N_I ),
        .DATA_EN_I       ( DATA_EN_I ),
        .FRAME_END_I     ( FRAME_END_I ),
        .PATTERN_SEL_I   ( PATTERN_SEL_I ),
        .BAYER_PATTERN_I ( BAYER_PATTERN_I ),
        // Outputs
        .DATA_VALID_O    ( DATA_VALID_O_net_0 ),
        .FRAME_END_O     ( FRAME_END_O_net_0 ),
        .LINE_END_O      ( LINE_END_O_net_0 ),
        .RED_O           ( RED_O_net_0 ),
        .GREEN_O         ( GREEN_O_net_0 ),
        .BLUE_O          ( BLUE_O_net_0 ),
        .BAYER_O         ( BAYER_O_net_0 ) 
        );


endmodule
