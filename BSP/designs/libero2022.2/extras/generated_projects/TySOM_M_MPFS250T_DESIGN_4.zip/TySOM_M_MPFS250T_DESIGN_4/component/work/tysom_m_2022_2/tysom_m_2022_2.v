//////////////////////////////////////////////////////////////////////
// Created by SmartDesign Tue Jan 14 12:24:11 2025
// Version: 2022.2 2022.2.0.10
//////////////////////////////////////////////////////////////////////

`timescale 1ns / 100ps

// tysom_m_2022_2
module tysom_m_2022_2(
    // Inputs
    CAN_0_RXBUS_F2M,
    GPIO_1_20_IN,
    MMUART_0_RXD,
    MMUART_1_RXD_F2M,
    MMUART_2_RXD_F2M,
    MMUART_3_RXD_F2M,
    REFCLK,
    REFCLK_N,
    SD_CD,
    SD_WP,
    SGMII_RX0_N,
    SGMII_RX0_P,
    SGMII_RX1_N,
    SGMII_RX1_P,
    SPI_1_DI,
    USB_CLK,
    USB_DIR,
    USB_NXT,
    // Outputs
    A,
    ACT_N,
    ACT_N_0,
    A_0,
    BA,
    BA_0,
    BG,
    BG_0,
    CAN_0_STANDBY,
    CAN_0_TXBUS_M2F,
    CAS_N,
    CAS_N_0,
    CK0,
    CK0_0,
    CK0_N,
    CK0_N_0,
    CKE,
    CKE0,
    CS0_N,
    CS_N,
    DM_N,
    GPIO_1_23_OUT,
    HDMI_CLK,
    HDMI_DE,
    HDMI_HSYNC,
    HDMI_I2S0,
    HDMI_I2S1,
    HDMI_I2S2,
    HDMI_I2S3,
    HDMI_LRCLK,
    HDMI_MCLK,
    HDMI_PD_AD,
    HDMI_SCLK,
    HDMI_SPDIF,
    HDMI_VSYNC,
    MAC_1_MDC,
    MMUART_0_TXD,
    MMUART_1_TXD_M2F,
    MMUART_2_TXD_M2F,
    MMUART_3_TXD_M2F,
    ODT,
    ODT0,
    RAS_N,
    RAS_N_0,
    RESET_N,
    RESET_N_0,
    SD_CLK,
    SD_POW_EMMC_DATA4,
    SD_SEL,
    SD_VOLT_CMD_DIR_EMMC_DATA7,
    SD_VOLT_DIR_0,
    SD_VOLT_DIR_1_3,
    SD_VOLT_EN_EMMC_DATA6,
    SD_VOLT_SEL_EMMC_DATA5,
    SGMII_TX0_N,
    SGMII_TX0_P,
    SGMII_TX1_N,
    SGMII_TX1_P,
    SHIELD0,
    SHIELD1,
    SHIELD2,
    SHIELD3,
    SPI_1_DO,
    USB_STP,
    USB_ULPI_RESET,
    VSC_8662_CMODE7,
    VSC_8662_RESETN,
    VSC_8662_SRESET,
    WE_N,
    WE_N_0,
    data_b,
    data_g,
    data_r,
    // Inouts
    DQ,
    DQS,
    DQS_0,
    DQS_N,
    DQS_N_0,
    DQ_0,
    HDMI_SCL,
    HDMI_SDA,
    I2C_1_SCL,
    I2C_1_SDA,
    MAC_1_MDIO,
    SD_CMD,
    SD_DATA0,
    SD_DATA1,
    SD_DATA2,
    SD_DATA3,
    SPI_1_CLK,
    SPI_1_SS0,
    USB_DATA0,
    USB_DATA1,
    USB_DATA2,
    USB_DATA3,
    USB_DATA4,
    USB_DATA5,
    USB_DATA6,
    USB_DATA7
);

//--------------------------------------------------------------------
// Input
//--------------------------------------------------------------------
input         CAN_0_RXBUS_F2M;
input         GPIO_1_20_IN;
input         MMUART_0_RXD;
input         MMUART_1_RXD_F2M;
input         MMUART_2_RXD_F2M;
input         MMUART_3_RXD_F2M;
input         REFCLK;
input         REFCLK_N;
input         SD_CD;
input         SD_WP;
input         SGMII_RX0_N;
input         SGMII_RX0_P;
input         SGMII_RX1_N;
input         SGMII_RX1_P;
input         SPI_1_DI;
input         USB_CLK;
input         USB_DIR;
input         USB_NXT;
//--------------------------------------------------------------------
// Output
//--------------------------------------------------------------------
output [13:0] A;
output        ACT_N;
output        ACT_N_0;
output [13:0] A_0;
output [1:0]  BA;
output [1:0]  BA_0;
output [1:0]  BG;
output [1:0]  BG_0;
output        CAN_0_STANDBY;
output        CAN_0_TXBUS_M2F;
output        CAS_N;
output        CAS_N_0;
output        CK0;
output        CK0_0;
output        CK0_N;
output        CK0_N_0;
output        CKE;
output        CKE0;
output        CS0_N;
output        CS_N;
output [3:0]  DM_N;
output        GPIO_1_23_OUT;
output        HDMI_CLK;
output        HDMI_DE;
output        HDMI_HSYNC;
output        HDMI_I2S0;
output        HDMI_I2S1;
output        HDMI_I2S2;
output        HDMI_I2S3;
output        HDMI_LRCLK;
output        HDMI_MCLK;
output        HDMI_PD_AD;
output        HDMI_SCLK;
output        HDMI_SPDIF;
output        HDMI_VSYNC;
output        MAC_1_MDC;
output        MMUART_0_TXD;
output        MMUART_1_TXD_M2F;
output        MMUART_2_TXD_M2F;
output        MMUART_3_TXD_M2F;
output        ODT;
output        ODT0;
output        RAS_N;
output        RAS_N_0;
output        RESET_N;
output        RESET_N_0;
output        SD_CLK;
output        SD_POW_EMMC_DATA4;
output        SD_SEL;
output        SD_VOLT_CMD_DIR_EMMC_DATA7;
output        SD_VOLT_DIR_0;
output        SD_VOLT_DIR_1_3;
output        SD_VOLT_EN_EMMC_DATA6;
output        SD_VOLT_SEL_EMMC_DATA5;
output        SGMII_TX0_N;
output        SGMII_TX0_P;
output        SGMII_TX1_N;
output        SGMII_TX1_P;
output        SHIELD0;
output        SHIELD1;
output        SHIELD2;
output        SHIELD3;
output        SPI_1_DO;
output        USB_STP;
output        USB_ULPI_RESET;
output        VSC_8662_CMODE7;
output        VSC_8662_RESETN;
output        VSC_8662_SRESET;
output        WE_N;
output        WE_N_0;
output [7:0]  data_b;
output [7:0]  data_g;
output [7:0]  data_r;
//--------------------------------------------------------------------
// Inout
//--------------------------------------------------------------------
inout  [35:0] DQ;
inout  [4:0]  DQS;
inout  [3:0]  DQS_0;
inout  [4:0]  DQS_N;
inout  [3:0]  DQS_N_0;
inout  [31:0] DQ_0;
inout         HDMI_SCL;
inout         HDMI_SDA;
inout         I2C_1_SCL;
inout         I2C_1_SDA;
inout         MAC_1_MDIO;
inout         SD_CMD;
inout         SD_DATA0;
inout         SD_DATA1;
inout         SD_DATA2;
inout         SD_DATA3;
inout         SPI_1_CLK;
inout         SPI_1_SS0;
inout         USB_DATA0;
inout         USB_DATA1;
inout         USB_DATA2;
inout         USB_DATA3;
inout         USB_DATA4;
inout         USB_DATA5;
inout         USB_DATA6;
inout         USB_DATA7;
//--------------------------------------------------------------------
// Nets
//--------------------------------------------------------------------
wire   [13:0]  A_net_0;
wire   [13:0]  A_0_net_0;
wire           ACT_N_net_0;
wire           ACT_N_0_net_0;
wire   [1:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARBURST;
wire   [3:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARCACHE;
wire   [7:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARID;
wire   [7:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARLEN;
wire   [2:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARPROT;
wire   [3:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARQOS;
wire           Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARREADY;
wire   [2:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARSIZE;
wire           Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARVALID;
wire   [1:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWBURST;
wire   [3:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWCACHE;
wire   [7:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWID;
wire   [7:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWLEN;
wire   [2:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWPROT;
wire   [3:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWQOS;
wire           Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWREADY;
wire   [2:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWSIZE;
wire           Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWVALID;
wire   [7:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_BID;
wire           Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_BREADY;
wire   [1:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_BRESP;
wire   [0:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_BUSER;
wire           Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_BVALID;
wire   [63:0]  Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RDATA;
wire   [7:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RID;
wire           Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RLAST;
wire           Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RREADY;
wire   [1:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RRESP;
wire   [0:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RUSER;
wire           Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RVALID;
wire   [63:0]  Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_WDATA;
wire           Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_WLAST;
wire           Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_WREADY;
wire   [7:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_WSTRB;
wire           Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_WVALID;
wire           Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PENABLE;
wire   [31:0]  Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PRDATA;
wire           Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PREADY;
wire           Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PSELx;
wire           Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PSLVERR;
wire   [31:0]  Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PWDATA;
wire           Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PWRITE;
wire           Aldec_MSS_2022_2_I2C_0_SCL_OE_M2F;
wire           Aldec_MSS_2022_2_I2C_0_SDA_OE_M2F;
wire           Aldec_MSS_2022_2_MMUART_4_TXD_M2F;
wire   [31:0]  APB_PASS_THROUGH_0_APB_INITIATOR_PADDR;
wire           APB_PASS_THROUGH_0_APB_INITIATOR_PENABLE;
wire   [31:0]  APB_PASS_THROUGH_0_APB_INITIATOR_PRDATA;
wire           APB_PASS_THROUGH_0_APB_INITIATOR_PREADY;
wire           APB_PASS_THROUGH_0_APB_INITIATOR_PSELx;
wire           APB_PASS_THROUGH_0_APB_INITIATOR_PSLVERR;
wire   [31:0]  APB_PASS_THROUGH_0_APB_INITIATOR_PWDATA;
wire           APB_PASS_THROUGH_0_APB_INITIATOR_PWRITE;
wire   [1:0]   BA_net_0;
wire   [1:0]   BA_0_net_0;
wire   [1:0]   BG_net_0;
wire   [1:0]   BG_0_net_0;
wire           BIBUF_0_Y;
wire           BIBUF_1_Y;
wire           CAN_0_RXBUS_F2M;
wire           CAN_0_TXBUS_M2F_net_0;
wire           CAS_N_net_0;
wire           CAS_N_0_net_0;
wire           CK0_net_0;
wire           CK0_0_net_0;
wire           CK0_N_net_0;
wire           CK0_N_0_net_0;
wire           CKE_net_0;
wire           CKE0_net_0;
wire           CoreAPB3_C0_0_APBmslave0_PENABLE;
wire   [31:0]  CoreAPB3_C0_0_APBmslave0_PRDATA;
wire           CoreAPB3_C0_0_APBmslave0_PREADY;
wire           CoreAPB3_C0_0_APBmslave0_PSELx;
wire           CoreAPB3_C0_0_APBmslave0_PSLVERR;
wire   [31:0]  CoreAPB3_C0_0_APBmslave0_PWDATA;
wire           CoreAPB3_C0_0_APBmslave0_PWRITE;
wire   [31:0]  CoreAPB3_C0_0_APBmslave15_PRDATA;
wire           CoreAPB3_C0_0_APBmslave15_PREADY;
wire           CoreAPB3_C0_0_APBmslave15_PSELx;
wire           CoreAPB3_C0_0_APBmslave15_PSLVERR;
wire   [31:0]  COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARADDR;
wire   [1:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARBURST;
wire   [3:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARCACHE;
wire   [7:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARLEN;
wire   [1:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARLOCK;
wire   [2:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARPROT;
wire   [3:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARQOS;
wire           COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARREADY;
wire   [3:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARREGION;
wire   [2:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARSIZE;
wire   [0:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARUSER;
wire           COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARVALID;
wire   [31:0]  COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWADDR;
wire   [1:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWBURST;
wire   [3:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWCACHE;
wire   [7:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWLEN;
wire   [1:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWLOCK;
wire   [2:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWPROT;
wire   [3:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWQOS;
wire           COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWREADY;
wire   [3:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWREGION;
wire   [2:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWSIZE;
wire   [0:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWUSER;
wire           COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWVALID;
wire           COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BREADY;
wire   [1:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BRESP;
wire           COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BVALID;
wire   [63:0]  COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RDATA;
wire           COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RLAST;
wire           COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RREADY;
wire   [1:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RRESP;
wire           COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RVALID;
wire   [63:0]  COREAXI4INTERCONNECT_C0_0_AXI4mslave0_WDATA;
wire           COREAXI4INTERCONNECT_C0_0_AXI4mslave0_WLAST;
wire           COREAXI4INTERCONNECT_C0_0_AXI4mslave0_WREADY;
wire   [7:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_WSTRB;
wire   [0:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_WUSER;
wire           COREAXI4INTERCONNECT_C0_0_AXI4mslave0_WVALID;
wire   [2:0]   CoreGPIO_C0_0_GPIO_OUT;
wire           CORERESET_PF_C0_0_PLL_POWERDOWN_B;
wire           CORERESET_PF_C0_1_FABRIC_RESET_N;
wire           CORERESET_PF_C0_1_PLL_POWERDOWN_B;
wire           CS0_N_net_0;
wire           CS_N_net_0;
wire   [7:0]   data_b_net_0;
wire   [15:8]  data_g_net_0;
wire   [23:16] data_r_net_0;
wire           Display_Controller_C0_0_DATA_TRIGGER_O;
wire           Display_Controller_C0_0_FRAME_END_O;
wire   [3:0]   DM_N_net_0;
wire   [35:0]  DQ;
wire   [31:0]  DQ_0;
wire   [4:0]   DQS;
wire   [3:0]   DQS_0;
wire   [4:0]   DQS_N;
wire   [3:0]   DQS_N_0;
wire   [31:0]  FIC_3_0x4FFF_Fxxx_0_APBmslave15_PADDR;
wire           FIC_3_0x4FFF_Fxxx_0_APBmslave15_PENABLE;
wire   [31:0]  FIC_3_0x4FFF_Fxxx_0_APBmslave15_PRDATA;
wire           FIC_3_0x4FFF_Fxxx_0_APBmslave15_PREADY;
wire           FIC_3_0x4FFF_Fxxx_0_APBmslave15_PSELx;
wire           FIC_3_0x4FFF_Fxxx_0_APBmslave15_PSLVERR;
wire   [31:0]  FIC_3_0x4FFF_Fxxx_0_APBmslave15_PWDATA;
wire           FIC_3_0x4FFF_Fxxx_0_APBmslave15_PWRITE;
wire           GPIO_1_20_IN;
wire           GPIO_1_23_OUT_net_0;
wire           HDMI_CLK_net_0;
wire           HDMI_DE_net_0;
wire           HDMI_HSYNC_net_0;
wire           HDMI_SCL;
wire           HDMI_SDA;
wire           HDMI_VSYNC_net_0;
wire           I2C_1_SCL;
wire           I2C_1_SDA;
wire           MAC_1_MDC_net_0;
wire           MAC_1_MDIO;
wire           MMUART_0_RXD;
wire           MMUART_0_TXD_net_0;
wire           MMUART_1_RXD_F2M;
wire           MMUART_1_TXD_M2F_net_0;
wire           MMUART_2_RXD_F2M;
wire           MMUART_2_TXD_M2F_net_0;
wire           MMUART_3_RXD_F2M;
wire           MMUART_3_TXD_M2F_net_0;
wire           ODT_net_0;
wire           ODT0_net_0;
wire           PF_CCC_C0_0_OUT0_FABCLK_0;
wire           PF_CCC_C0_0_OUT1_FABCLK_0;
wire           PF_CCC_C0_0_PLL_LOCK_0;
wire           PF_CCC_C1_0_PLL_LOCK_0;
wire           PF_DDR4_C0_0_SYS_CLK;
wire           PF_OSC_C0_0_RCOSC_160MHZ_GL;
wire           PFSOC_INIT_MONITOR_C0_0_BANK_0_VDDI_STATUS;
wire           PFSOC_INIT_MONITOR_C0_0_DEVICE_INIT_DONE;
wire           PFSOC_INIT_MONITOR_C0_0_FABRIC_POR_N;
wire           RAS_N_net_0;
wire           RAS_N_0_net_0;
wire           REFCLK;
wire           REFCLK_N;
wire           RESET_N_net_0;
wire           RESET_N_0_net_0;
wire           SD_CD;
wire           SD_CLK_net_0;
wire           SD_CMD;
wire           SD_DATA0;
wire           SD_DATA1;
wire           SD_DATA2;
wire           SD_DATA3;
wire           SD_POW_EMMC_DATA4_net_0;
wire           SD_SEL_net_0;
wire           SD_VOLT_CMD_DIR_EMMC_DATA7_net_0;
wire           SD_VOLT_DIR_0_net_0;
wire           SD_VOLT_DIR_1_3_net_0;
wire           SD_VOLT_EN_EMMC_DATA6_net_0;
wire           SD_VOLT_SEL_EMMC_DATA5_net_0;
wire           SD_WP;
wire           SGMII_RX0_N;
wire           SGMII_RX0_P;
wire           SGMII_RX1_N;
wire           SGMII_RX1_P;
wire           SGMII_TX0_N_net_0;
wire           SGMII_TX0_P_net_0;
wire           SGMII_TX1_N_net_0;
wire           SGMII_TX1_P_net_0;
wire           SHIELD0_net_0;
wire           SHIELD1_net_0;
wire           SHIELD2_net_0;
wire           SHIELD3_net_0;
wire           SPI_1_CLK;
wire           SPI_1_DI;
wire           SPI_1_DO_net_0;
wire           SPI_1_SS0;
wire   [7:0]   Test_Pattern_Generator_C0_0_BLUE_O;
wire           Test_Pattern_Generator_C0_0_DATA_VALID_O;
wire   [7:0]   Test_Pattern_Generator_C0_0_GREEN_O;
wire   [7:0]   Test_Pattern_Generator_C0_0_RED_O;
wire           USB_CLK;
wire           USB_DATA0;
wire           USB_DATA1;
wire           USB_DATA2;
wire           USB_DATA3;
wire           USB_DATA4;
wire           USB_DATA5;
wire           USB_DATA6;
wire           USB_DATA7;
wire           USB_DIR;
wire           USB_NXT;
wire           USB_STP_net_0;
wire           USB_ULPI_RESET_net_0;
wire           WE_N_net_0;
wire           WE_N_0_net_0;
wire           ACT_N_0_net_1;
wire           ACT_N_net_1;
wire           CAN_0_TXBUS_M2F_net_1;
wire           CAS_N_0_net_1;
wire           CAS_N_net_1;
wire           CK0_0_net_1;
wire           CK0_N_0_net_1;
wire           CK0_N_net_1;
wire           CK0_net_1;
wire           CKE0_net_1;
wire           CKE_net_1;
wire           CS0_N_net_1;
wire           CS_N_net_1;
wire           GPIO_1_23_OUT_net_1;
wire           HDMI_CLK_net_1;
wire           HDMI_DE_net_1;
wire           HDMI_HSYNC_net_1;
wire           HDMI_VSYNC_net_1;
wire           MAC_1_MDC_net_1;
wire           MMUART_0_TXD_net_1;
wire           MMUART_1_TXD_M2F_net_1;
wire           MMUART_2_TXD_M2F_net_1;
wire           MMUART_3_TXD_M2F_net_1;
wire           ODT0_net_1;
wire           ODT_net_1;
wire           RAS_N_0_net_1;
wire           RAS_N_net_1;
wire           RESET_N_0_net_1;
wire           RESET_N_net_1;
wire           SD_CLK_net_1;
wire           SD_POW_EMMC_DATA4_net_1;
wire           SD_SEL_net_1;
wire           SD_VOLT_CMD_DIR_EMMC_DATA7_net_1;
wire           SD_VOLT_DIR_0_net_1;
wire           SD_VOLT_DIR_1_3_net_1;
wire           SD_VOLT_EN_EMMC_DATA6_net_1;
wire           SD_VOLT_SEL_EMMC_DATA5_net_1;
wire           SGMII_TX0_N_net_1;
wire           SGMII_TX0_P_net_1;
wire           SGMII_TX1_N_net_1;
wire           SGMII_TX1_P_net_1;
wire           SHIELD0_net_1;
wire           SHIELD1_net_1;
wire           SHIELD2_net_1;
wire           SHIELD3_net_1;
wire           SPI_1_DO_net_1;
wire           USB_STP_net_1;
wire           USB_ULPI_RESET_net_2;
wire           WE_N_0_net_1;
wire           WE_N_net_1;
wire   [13:0]  A_0_net_1;
wire   [13:0]  A_net_1;
wire   [1:0]   BA_0_net_1;
wire   [1:0]   BA_net_1;
wire   [1:0]   BG_0_net_1;
wire   [1:0]   BG_net_1;
wire   [3:0]   DM_N_net_1;
wire   [7:0]   data_b_net_1;
wire   [7:0]   data_g_net_1;
wire   [7:0]   data_r_net_1;
wire   [0:0]   GPIO_OUT_slice_0;
wire   [1:1]   GPIO_OUT_slice_1;
wire   [2:2]   GPIO_OUT_slice_2;
wire   [23:0]  DATA_I_net_0;
wire   [23:0]  DATA_O_net_0;
//--------------------------------------------------------------------
// TiedOff Nets
//--------------------------------------------------------------------
wire           GND_net;
wire           VCC_net;
wire   [3:0]   QSPI_DATA_F2M_const_net_0;
wire   [2:0]   GPIO_IN_const_net_0;
wire   [1:0]   BAYER_PATTERN_I_const_net_0;
wire   [31:0]  PRDATAS16_const_net_0;
wire   [3:0]   MASTER0_AWREGION_const_net_0;
wire   [3:0]   MASTER0_ARREGION_const_net_0;
//--------------------------------------------------------------------
// Inverted Nets
//--------------------------------------------------------------------
wire           USB_ULPI_RESET_net_1;
wire           USB_ULPI_RESET_OUT_PRE_INV0_0;
//--------------------------------------------------------------------
// Bus Interface Nets Declarations - Unequal Pin Widths
//--------------------------------------------------------------------
wire   [37:0]  Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARADDR;
wire   [31:0]  Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARADDR_0;
wire   [31:0]  Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARADDR_0_31to0;
wire           Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARLOCK;
wire   [1:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARLOCK_0;
wire   [0:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARLOCK_0_0to0;
wire   [1:1]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARLOCK_0_1to1;
wire   [37:0]  Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWADDR;
wire   [31:0]  Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWADDR_0;
wire   [31:0]  Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWADDR_0_31to0;
wire           Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWLOCK;
wire   [1:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWLOCK_0;
wire   [0:0]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWLOCK_0_0to0;
wire   [1:1]   Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWLOCK_0_1to1;
wire   [28:0]  Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR;
wire   [31:0]  Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0;
wire   [28:0]  Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0_28to0;
wire   [31:29] Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0_31to29;
wire   [31:0]  CoreAPB3_C0_0_APBmslave0_PADDR;
wire   [7:0]   CoreAPB3_C0_0_APBmslave0_PADDR_0;
wire   [7:0]   CoreAPB3_C0_0_APBmslave0_PADDR_0_7to0;
wire   [8:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARID;
wire   [7:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARID_0;
wire   [7:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARID_0_7to0;
wire   [8:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWID;
wire   [7:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWID_0;
wire   [7:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWID_0_7to0;
wire   [7:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BID;
wire   [8:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BID_0;
wire   [7:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BID_0_7to0;
wire   [8:8]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BID_0_8to8;
wire   [7:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RID;
wire   [8:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RID_0;
wire   [7:0]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RID_0_7to0;
wire   [8:8]   COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RID_0_8to8;
//--------------------------------------------------------------------
// Constant assignments
//--------------------------------------------------------------------
assign GND_net                      = 1'b0;
assign VCC_net                      = 1'b1;
assign QSPI_DATA_F2M_const_net_0    = 4'h0;
assign GPIO_IN_const_net_0          = 3'h0;
assign BAYER_PATTERN_I_const_net_0  = 2'h0;
assign PRDATAS16_const_net_0        = 32'h00000000;
assign MASTER0_AWREGION_const_net_0 = 4'h0;
assign MASTER0_ARREGION_const_net_0 = 4'h0;
//--------------------------------------------------------------------
// Inversions
//--------------------------------------------------------------------
assign USB_ULPI_RESET_net_1 = ~ USB_ULPI_RESET_OUT_PRE_INV0_0;
//--------------------------------------------------------------------
// TieOff assignments
//--------------------------------------------------------------------
assign CAN_0_STANDBY                    = 1'b0;
assign HDMI_I2S0                        = 1'b0;
assign HDMI_I2S1                        = 1'b0;
assign HDMI_I2S2                        = 1'b0;
assign HDMI_I2S3                        = 1'b0;
assign HDMI_LRCLK                       = 1'b0;
assign HDMI_MCLK                        = 1'b0;
assign HDMI_PD_AD                       = 1'b0;
assign HDMI_SCLK                        = 1'b0;
assign HDMI_SPDIF                       = 1'b0;
assign VSC_8662_CMODE7                  = 1'b0;
assign VSC_8662_SRESET                  = 1'b1;
//--------------------------------------------------------------------
// Top level output port assignments
//--------------------------------------------------------------------
assign ACT_N_0_net_1                    = ACT_N_0_net_0;
assign ACT_N_0                          = ACT_N_0_net_1;
assign ACT_N_net_1                      = ACT_N_net_0;
assign ACT_N                            = ACT_N_net_1;
assign CAN_0_TXBUS_M2F_net_1            = CAN_0_TXBUS_M2F_net_0;
assign CAN_0_TXBUS_M2F                  = CAN_0_TXBUS_M2F_net_1;
assign CAS_N_0_net_1                    = CAS_N_0_net_0;
assign CAS_N_0                          = CAS_N_0_net_1;
assign CAS_N_net_1                      = CAS_N_net_0;
assign CAS_N                            = CAS_N_net_1;
assign CK0_0_net_1                      = CK0_0_net_0;
assign CK0_0                            = CK0_0_net_1;
assign CK0_N_0_net_1                    = CK0_N_0_net_0;
assign CK0_N_0                          = CK0_N_0_net_1;
assign CK0_N_net_1                      = CK0_N_net_0;
assign CK0_N                            = CK0_N_net_1;
assign CK0_net_1                        = CK0_net_0;
assign CK0                              = CK0_net_1;
assign CKE0_net_1                       = CKE0_net_0;
assign CKE0                             = CKE0_net_1;
assign CKE_net_1                        = CKE_net_0;
assign CKE                              = CKE_net_1;
assign CS0_N_net_1                      = CS0_N_net_0;
assign CS0_N                            = CS0_N_net_1;
assign CS_N_net_1                       = CS_N_net_0;
assign CS_N                             = CS_N_net_1;
assign GPIO_1_23_OUT_net_1              = GPIO_1_23_OUT_net_0;
assign GPIO_1_23_OUT                    = GPIO_1_23_OUT_net_1;
assign HDMI_CLK_net_1                   = HDMI_CLK_net_0;
assign HDMI_CLK                         = HDMI_CLK_net_1;
assign HDMI_DE_net_1                    = HDMI_DE_net_0;
assign HDMI_DE                          = HDMI_DE_net_1;
assign HDMI_HSYNC_net_1                 = HDMI_HSYNC_net_0;
assign HDMI_HSYNC                       = HDMI_HSYNC_net_1;
assign HDMI_VSYNC_net_1                 = HDMI_VSYNC_net_0;
assign HDMI_VSYNC                       = HDMI_VSYNC_net_1;
assign MAC_1_MDC_net_1                  = MAC_1_MDC_net_0;
assign MAC_1_MDC                        = MAC_1_MDC_net_1;
assign MMUART_0_TXD_net_1               = MMUART_0_TXD_net_0;
assign MMUART_0_TXD                     = MMUART_0_TXD_net_1;
assign MMUART_1_TXD_M2F_net_1           = MMUART_1_TXD_M2F_net_0;
assign MMUART_1_TXD_M2F                 = MMUART_1_TXD_M2F_net_1;
assign MMUART_2_TXD_M2F_net_1           = MMUART_2_TXD_M2F_net_0;
assign MMUART_2_TXD_M2F                 = MMUART_2_TXD_M2F_net_1;
assign MMUART_3_TXD_M2F_net_1           = MMUART_3_TXD_M2F_net_0;
assign MMUART_3_TXD_M2F                 = MMUART_3_TXD_M2F_net_1;
assign ODT0_net_1                       = ODT0_net_0;
assign ODT0                             = ODT0_net_1;
assign ODT_net_1                        = ODT_net_0;
assign ODT                              = ODT_net_1;
assign RAS_N_0_net_1                    = RAS_N_0_net_0;
assign RAS_N_0                          = RAS_N_0_net_1;
assign RAS_N_net_1                      = RAS_N_net_0;
assign RAS_N                            = RAS_N_net_1;
assign RESET_N_0_net_1                  = RESET_N_0_net_0;
assign RESET_N_0                        = RESET_N_0_net_1;
assign RESET_N_net_1                    = RESET_N_net_0;
assign RESET_N                          = RESET_N_net_1;
assign SD_CLK_net_1                     = SD_CLK_net_0;
assign SD_CLK                           = SD_CLK_net_1;
assign SD_POW_EMMC_DATA4_net_1          = SD_POW_EMMC_DATA4_net_0;
assign SD_POW_EMMC_DATA4                = SD_POW_EMMC_DATA4_net_1;
assign SD_SEL_net_1                     = SD_SEL_net_0;
assign SD_SEL                           = SD_SEL_net_1;
assign SD_VOLT_CMD_DIR_EMMC_DATA7_net_1 = SD_VOLT_CMD_DIR_EMMC_DATA7_net_0;
assign SD_VOLT_CMD_DIR_EMMC_DATA7       = SD_VOLT_CMD_DIR_EMMC_DATA7_net_1;
assign SD_VOLT_DIR_0_net_1              = SD_VOLT_DIR_0_net_0;
assign SD_VOLT_DIR_0                    = SD_VOLT_DIR_0_net_1;
assign SD_VOLT_DIR_1_3_net_1            = SD_VOLT_DIR_1_3_net_0;
assign SD_VOLT_DIR_1_3                  = SD_VOLT_DIR_1_3_net_1;
assign SD_VOLT_EN_EMMC_DATA6_net_1      = SD_VOLT_EN_EMMC_DATA6_net_0;
assign SD_VOLT_EN_EMMC_DATA6            = SD_VOLT_EN_EMMC_DATA6_net_1;
assign SD_VOLT_SEL_EMMC_DATA5_net_1     = SD_VOLT_SEL_EMMC_DATA5_net_0;
assign SD_VOLT_SEL_EMMC_DATA5           = SD_VOLT_SEL_EMMC_DATA5_net_1;
assign SGMII_TX0_N_net_1                = SGMII_TX0_N_net_0;
assign SGMII_TX0_N                      = SGMII_TX0_N_net_1;
assign SGMII_TX0_P_net_1                = SGMII_TX0_P_net_0;
assign SGMII_TX0_P                      = SGMII_TX0_P_net_1;
assign SGMII_TX1_N_net_1                = SGMII_TX1_N_net_0;
assign SGMII_TX1_N                      = SGMII_TX1_N_net_1;
assign SGMII_TX1_P_net_1                = SGMII_TX1_P_net_0;
assign SGMII_TX1_P                      = SGMII_TX1_P_net_1;
assign SHIELD0_net_1                    = SHIELD0_net_0;
assign SHIELD0                          = SHIELD0_net_1;
assign SHIELD1_net_1                    = SHIELD1_net_0;
assign SHIELD1                          = SHIELD1_net_1;
assign SHIELD2_net_1                    = SHIELD2_net_0;
assign SHIELD2                          = SHIELD2_net_1;
assign SHIELD3_net_1                    = SHIELD3_net_0;
assign SHIELD3                          = SHIELD3_net_1;
assign SPI_1_DO_net_1                   = SPI_1_DO_net_0;
assign SPI_1_DO                         = SPI_1_DO_net_1;
assign USB_STP_net_1                    = USB_STP_net_0;
assign USB_STP                          = USB_STP_net_1;
assign USB_ULPI_RESET_OUT_PRE_INV0_0    = USB_ULPI_RESET_net_0;
assign USB_ULPI_RESET                   = USB_ULPI_RESET_net_1;
assign USB_ULPI_RESET_net_2             = USB_ULPI_RESET_net_0;
assign VSC_8662_RESETN                  = USB_ULPI_RESET_net_2;
assign WE_N_0_net_1                     = WE_N_0_net_0;
assign WE_N_0                           = WE_N_0_net_1;
assign WE_N_net_1                       = WE_N_net_0;
assign WE_N                             = WE_N_net_1;
assign A_0_net_1                        = A_0_net_0;
assign A_0[13:0]                        = A_0_net_1;
assign A_net_1                          = A_net_0;
assign A[13:0]                          = A_net_1;
assign BA_0_net_1                       = BA_0_net_0;
assign BA_0[1:0]                        = BA_0_net_1;
assign BA_net_1                         = BA_net_0;
assign BA[1:0]                          = BA_net_1;
assign BG_0_net_1                       = BG_0_net_0;
assign BG_0[1:0]                        = BG_0_net_1;
assign BG_net_1                         = BG_net_0;
assign BG[1:0]                          = BG_net_1;
assign DM_N_net_1                       = DM_N_net_0;
assign DM_N[3:0]                        = DM_N_net_1;
assign data_b_net_1                     = data_b_net_0;
assign data_b[7:0]                      = data_b_net_1;
assign data_g_net_1                     = data_g_net_0;
assign data_g[7:0]                      = data_g_net_1;
assign data_r_net_1                     = data_r_net_0;
assign data_r[7:0]                      = data_r_net_1;
//--------------------------------------------------------------------
// Slices assignments
//--------------------------------------------------------------------
assign data_b_net_0        = DATA_O_net_0[7:0];
assign data_g_net_0        = DATA_O_net_0[15:8];
assign data_r_net_0        = DATA_O_net_0[23:16];
assign GPIO_OUT_slice_0[0] = CoreGPIO_C0_0_GPIO_OUT[0:0];
assign GPIO_OUT_slice_1[1] = CoreGPIO_C0_0_GPIO_OUT[1:1];
assign GPIO_OUT_slice_2[2] = CoreGPIO_C0_0_GPIO_OUT[2:2];
//--------------------------------------------------------------------
// Concatenation assignments
//--------------------------------------------------------------------
assign DATA_I_net_0 = { Test_Pattern_Generator_C0_0_RED_O , Test_Pattern_Generator_C0_0_GREEN_O , Test_Pattern_Generator_C0_0_BLUE_O };
//--------------------------------------------------------------------
// Bus Interface Nets Assignments - Unequal Pin Widths
//--------------------------------------------------------------------
assign Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARADDR_0 = { Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARADDR_0_31to0 };
assign Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARADDR_0_31to0 = Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARADDR[31:0];

assign Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARLOCK_0 = { Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARLOCK_0_1to1, Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARLOCK_0_0to0 };
assign Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARLOCK_0_0to0 = Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARLOCK;
assign Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARLOCK_0_1to1 = 1'b0;

assign Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWADDR_0 = { Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWADDR_0_31to0 };
assign Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWADDR_0_31to0 = Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWADDR[31:0];

assign Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWLOCK_0 = { Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWLOCK_0_1to1, Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWLOCK_0_0to0 };
assign Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWLOCK_0_0to0 = Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWLOCK;
assign Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWLOCK_0_1to1 = 1'b0;

assign Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0 = { Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0_31to29, Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0_28to0 };
assign Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0_28to0 = Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR[28:0];
assign Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0_31to29 = 3'h0;

assign CoreAPB3_C0_0_APBmslave0_PADDR_0 = { CoreAPB3_C0_0_APBmslave0_PADDR_0_7to0 };
assign CoreAPB3_C0_0_APBmslave0_PADDR_0_7to0 = CoreAPB3_C0_0_APBmslave0_PADDR[7:0];

assign COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARID_0 = { COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARID_0_7to0 };
assign COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARID_0_7to0 = COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARID[7:0];

assign COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWID_0 = { COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWID_0_7to0 };
assign COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWID_0_7to0 = COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWID[7:0];

assign COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BID_0 = { COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BID_0_8to8, COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BID_0_7to0 };
assign COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BID_0_7to0 = COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BID[7:0];
assign COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BID_0_8to8 = 1'b0;

assign COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RID_0 = { COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RID_0_8to8, COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RID_0_7to0 };
assign COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RID_0_7to0 = COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RID[7:0];
assign COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RID_0_8to8 = 1'b0;

//--------------------------------------------------------------------
// Component instances
//--------------------------------------------------------------------
//--------Aldec_MSS_2022_2
Aldec_MSS_2022_2 Aldec_MSS_2022_2_inst_0(
        // Inputs
        .FIC_0_ACLK                   ( PF_CCC_C0_0_OUT0_FABCLK_0 ),
        .FIC_0_AXI4_M_AWREADY         ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWREADY ),
        .FIC_0_AXI4_M_WREADY          ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_WREADY ),
        .FIC_0_AXI4_M_BID             ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_BID ),
        .FIC_0_AXI4_M_BRESP           ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_BRESP ),
        .FIC_0_AXI4_M_BVALID          ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_BVALID ),
        .FIC_0_AXI4_M_ARREADY         ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARREADY ),
        .FIC_0_AXI4_M_RID             ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RID ),
        .FIC_0_AXI4_M_RDATA           ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RDATA ),
        .FIC_0_AXI4_M_RRESP           ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RRESP ),
        .FIC_0_AXI4_M_RLAST           ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RLAST ),
        .FIC_0_AXI4_M_RVALID          ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RVALID ),
        .FIC_3_PCLK                   ( PF_CCC_C0_0_OUT0_FABCLK_0 ),
        .FIC_3_APB_M_PRDATA           ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PRDATA ),
        .FIC_3_APB_M_PREADY           ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PREADY ),
        .FIC_3_APB_M_PSLVERR          ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PSLVERR ),
        .MMUART_1_RXD_F2M             ( MMUART_1_RXD_F2M ),
        .MMUART_2_RXD_F2M             ( MMUART_2_RXD_F2M ),
        .MMUART_3_RXD_F2M             ( MMUART_3_RXD_F2M ),
        .MMUART_4_RXD_F2M             ( Aldec_MSS_2022_2_MMUART_4_TXD_M2F ),
        .CAN_0_RXBUS_F2M              ( CAN_0_RXBUS_F2M ),
        .CAN_1_RXBUS_F2M              ( GND_net ),
        .QSPI_DATA_F2M                ( QSPI_DATA_F2M_const_net_0 ),
        .I2C_0_SCL_F2M                ( BIBUF_0_Y ),
        .I2C_0_SDA_F2M                ( BIBUF_1_Y ),
        .MSS_RESET_N_F2M              ( USB_ULPI_RESET_net_0 ),
        .MMUART_0_RXD                 ( MMUART_0_RXD ),
        .GPIO_1_20_IN                 ( GPIO_1_20_IN ),
        .USB_CLK                      ( USB_CLK ),
        .USB_DIR                      ( USB_DIR ),
        .USB_NXT                      ( USB_NXT ),
        .SPI_1_DI                     ( SPI_1_DI ),
        .SD_CD_EMMC_STRB              ( SD_CD ),
        .SD_WP_EMMC_RSTN              ( SD_WP ),
        .SGMII_RX1_P                  ( SGMII_RX1_P ),
        .SGMII_RX1_N                  ( SGMII_RX1_N ),
        .SGMII_RX0_P                  ( SGMII_RX0_P ),
        .SGMII_RX0_N                  ( SGMII_RX0_N ),
        .REFCLK                       ( REFCLK ),
        .REFCLK_N                     ( REFCLK_N ),
        // Outputs
        .FIC_0_DLL_LOCK_M2F           (  ),
        .FIC_3_DLL_LOCK_M2F           (  ),
        .FIC_0_AXI4_M_AWID            ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWID ),
        .FIC_0_AXI4_M_AWADDR          ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWADDR ),
        .FIC_0_AXI4_M_AWLEN           ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWLEN ),
        .FIC_0_AXI4_M_AWSIZE          ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWSIZE ),
        .FIC_0_AXI4_M_AWBURST         ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWBURST ),
        .FIC_0_AXI4_M_AWLOCK          ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWLOCK ),
        .FIC_0_AXI4_M_AWQOS           ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWQOS ),
        .FIC_0_AXI4_M_AWCACHE         ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWCACHE ),
        .FIC_0_AXI4_M_AWPROT          ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWPROT ),
        .FIC_0_AXI4_M_AWVALID         ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWVALID ),
        .FIC_0_AXI4_M_WDATA           ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_WDATA ),
        .FIC_0_AXI4_M_WSTRB           ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_WSTRB ),
        .FIC_0_AXI4_M_WLAST           ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_WLAST ),
        .FIC_0_AXI4_M_WVALID          ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_WVALID ),
        .FIC_0_AXI4_M_BREADY          ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_BREADY ),
        .FIC_0_AXI4_M_ARID            ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARID ),
        .FIC_0_AXI4_M_ARADDR          ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARADDR ),
        .FIC_0_AXI4_M_ARLEN           ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARLEN ),
        .FIC_0_AXI4_M_ARSIZE          ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARSIZE ),
        .FIC_0_AXI4_M_ARBURST         ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARBURST ),
        .FIC_0_AXI4_M_ARLOCK          ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARLOCK ),
        .FIC_0_AXI4_M_ARQOS           ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARQOS ),
        .FIC_0_AXI4_M_ARCACHE         ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARCACHE ),
        .FIC_0_AXI4_M_ARPROT          ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARPROT ),
        .FIC_0_AXI4_M_ARVALID         ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARVALID ),
        .FIC_0_AXI4_M_RREADY          ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RREADY ),
        .FIC_3_APB_M_PSEL             ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PSELx ),
        .FIC_3_APB_M_PADDR            ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR ),
        .FIC_3_APB_M_PWRITE           ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PWRITE ),
        .FIC_3_APB_M_PENABLE          ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PENABLE ),
        .FIC_3_APB_M_PSTRB            (  ),
        .FIC_3_APB_M_PWDATA           ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PWDATA ),
        .MMUART_1_TXD_M2F             ( MMUART_1_TXD_M2F_net_0 ),
        .MMUART_1_TXD_OE_M2F          (  ),
        .MMUART_2_TXD_M2F             ( MMUART_2_TXD_M2F_net_0 ),
        .MMUART_3_TXD_M2F             ( MMUART_3_TXD_M2F_net_0 ),
        .MMUART_4_TXD_M2F             ( Aldec_MSS_2022_2_MMUART_4_TXD_M2F ),
        .CAN_0_TX_EBL_M2F             (  ),
        .CAN_0_TXBUS_M2F              ( CAN_0_TXBUS_M2F_net_0 ),
        .CAN_1_TX_EBL_M2F             (  ),
        .CAN_1_TXBUS_M2F              (  ),
        .QSPI_SEL_M2F                 (  ),
        .QSPI_SEL_OE_M2F              (  ),
        .QSPI_DATA_M2F                (  ),
        .QSPI_DATA_OE_M2F             (  ),
        .I2C_0_SCL_OE_M2F             ( Aldec_MSS_2022_2_I2C_0_SCL_OE_M2F ),
        .I2C_0_SDA_OE_M2F             ( Aldec_MSS_2022_2_I2C_0_SDA_OE_M2F ),
        .PLL_CPU_LOCK_M2F             (  ),
        .PLL_DDR_LOCK_M2F             (  ),
        .PLL_SGMII_LOCK_M2F           (  ),
        .MSS_RESET_N_M2F              (  ),
        .MAC_0_TSU_SOF_TX_M2F         (  ),
        .MAC_0_TSU_SYNC_FRAME_TX_M2F  (  ),
        .MAC_0_TSU_DELAY_REQ_TX_M2F   (  ),
        .MAC_0_TSU_PDELAY_REQ_TX_M2F  (  ),
        .MAC_0_TSU_PDELAY_RESP_TX_M2F (  ),
        .MAC_0_TSU_SOF_RX_M2F         (  ),
        .MAC_0_TSU_SYNC_FRAME_RX_M2F  (  ),
        .MAC_0_TSU_DELAY_REQ_RX_M2F   (  ),
        .MAC_0_TSU_PDELAY_REQ_RX_M2F  (  ),
        .MAC_0_TSU_PDELAY_RESP_RX_M2F (  ),
        .MAC_1_TSU_SOF_TX_M2F         (  ),
        .MAC_1_TSU_SYNC_FRAME_TX_M2F  (  ),
        .MAC_1_TSU_DELAY_REQ_TX_M2F   (  ),
        .MAC_1_TSU_PDELAY_REQ_TX_M2F  (  ),
        .MAC_1_TSU_PDELAY_RESP_TX_M2F (  ),
        .MAC_1_TSU_SOF_RX_M2F         (  ),
        .MAC_1_TSU_SYNC_FRAME_RX_M2F  (  ),
        .MAC_1_TSU_DELAY_REQ_RX_M2F   (  ),
        .MAC_1_TSU_PDELAY_REQ_RX_M2F  (  ),
        .MAC_1_TSU_PDELAY_RESP_RX_M2F (  ),
        .MMUART_0_TXD                 ( MMUART_0_TXD_net_0 ),
        .MAC_1_MDC                    ( MAC_1_MDC_net_0 ),
        .GPIO_1_23_OUT                ( GPIO_1_23_OUT_net_0 ),
        .USB_STP                      ( USB_STP_net_0 ),
        .SPI_1_DO                     ( SPI_1_DO_net_0 ),
        .SD_CLK_EMMC_CLK              ( SD_CLK_net_0 ),
        .SD_POW_EMMC_DATA4            ( SD_POW_EMMC_DATA4_net_0 ),
        .SD_VOLT_SEL_EMMC_DATA5       ( SD_VOLT_SEL_EMMC_DATA5_net_0 ),
        .SD_VOLT_EN_EMMC_DATA6        ( SD_VOLT_EN_EMMC_DATA6_net_0 ),
        .SD_VOLT_CMD_DIR_EMMC_DATA7   ( SD_VOLT_CMD_DIR_EMMC_DATA7_net_0 ),
        .SD_VOLT_DIR_0_EMMC_UNUSED    ( SD_VOLT_DIR_0_net_0 ),
        .SD_VOLT_DIR_1_3_EMMC_UNUSED  ( SD_VOLT_DIR_1_3_net_0 ),
        .SGMII_TX1_P                  ( SGMII_TX1_P_net_0 ),
        .SGMII_TX1_N                  ( SGMII_TX1_N_net_0 ),
        .SGMII_TX0_P                  ( SGMII_TX0_P_net_0 ),
        .SGMII_TX0_N                  ( SGMII_TX0_N_net_0 ),
        .BA                           ( BA_net_0 ),
        .A                            ( A_net_0 ),
        .RESET_N                      ( RESET_N_net_0 ),
        .CKE0                         ( CKE0_net_0 ),
        .CS0_N                        ( CS0_N_net_0 ),
        .ODT0                         ( ODT0_net_0 ),
        .CK0                          ( CK0_net_0 ),
        .CK0_N                        ( CK0_N_net_0 ),
        .RAS_N                        ( RAS_N_net_0 ),
        .WE_N                         ( WE_N_net_0 ),
        .CAS_N                        ( CAS_N_net_0 ),
        .ACT_N                        ( ACT_N_net_0 ),
        .BG                           ( BG_net_0 ),
        // Inouts
        .I2C_1_SCL                    ( I2C_1_SCL ),
        .I2C_1_SDA                    ( I2C_1_SDA ),
        .MAC_1_MDIO                   ( MAC_1_MDIO ),
        .USB_DATA0                    ( USB_DATA0 ),
        .USB_DATA1                    ( USB_DATA1 ),
        .USB_DATA2                    ( USB_DATA2 ),
        .USB_DATA3                    ( USB_DATA3 ),
        .USB_DATA4                    ( USB_DATA4 ),
        .USB_DATA5                    ( USB_DATA5 ),
        .USB_DATA6                    ( USB_DATA6 ),
        .USB_DATA7                    ( USB_DATA7 ),
        .SPI_1_SS0                    ( SPI_1_SS0 ),
        .SPI_1_CLK                    ( SPI_1_CLK ),
        .SD_CMD_EMMC_CMD              ( SD_CMD ),
        .SD_DATA0_EMMC_DATA0          ( SD_DATA0 ),
        .SD_DATA1_EMMC_DATA1          ( SD_DATA1 ),
        .SD_DATA2_EMMC_DATA2          ( SD_DATA2 ),
        .SD_DATA3_EMMC_DATA3          ( SD_DATA3 ),
        .DQ                           ( DQ ),
        .DQS                          ( DQS ),
        .DQS_N                        ( DQS_N ) 
        );

//--------APB_PASS_THROUGH
APB_PASS_THROUGH APB_PASS_THROUGH_0(
        // Inputs
        .target_penable    ( CoreAPB3_C0_0_APBmslave0_PENABLE ),
        .target_psel       ( CoreAPB3_C0_0_APBmslave15_PSELx ),
        .target_paddr      ( CoreAPB3_C0_0_APBmslave0_PADDR ),
        .target_pwrite     ( CoreAPB3_C0_0_APBmslave0_PWRITE ),
        .target_pwdata     ( CoreAPB3_C0_0_APBmslave0_PWDATA ),
        .initiator_prdata  ( APB_PASS_THROUGH_0_APB_INITIATOR_PRDATA ),
        .initiator_pready  ( APB_PASS_THROUGH_0_APB_INITIATOR_PREADY ),
        .initiator_pslverr ( APB_PASS_THROUGH_0_APB_INITIATOR_PSLVERR ),
        // Outputs
        .target_prdata     ( CoreAPB3_C0_0_APBmslave15_PRDATA ),
        .target_pready     ( CoreAPB3_C0_0_APBmslave15_PREADY ),
        .target_pslverr    ( CoreAPB3_C0_0_APBmslave15_PSLVERR ),
        .initiator_penable ( APB_PASS_THROUGH_0_APB_INITIATOR_PENABLE ),
        .initiator_psel    ( APB_PASS_THROUGH_0_APB_INITIATOR_PSELx ),
        .initiator_paddr   ( APB_PASS_THROUGH_0_APB_INITIATOR_PADDR ),
        .initiator_pwrite  ( APB_PASS_THROUGH_0_APB_INITIATOR_PWRITE ),
        .initiator_pwdata  ( APB_PASS_THROUGH_0_APB_INITIATOR_PWDATA ) 
        );

//--------BIBUF
BIBUF BIBUF_0(
        // Inputs
        .D   ( GND_net ),
        .E   ( Aldec_MSS_2022_2_I2C_0_SCL_OE_M2F ),
        // Outputs
        .Y   ( BIBUF_0_Y ),
        // Inouts
        .PAD ( HDMI_SCL ) 
        );

//--------BIBUF
BIBUF BIBUF_1(
        // Inputs
        .D   ( GND_net ),
        .E   ( Aldec_MSS_2022_2_I2C_0_SDA_OE_M2F ),
        // Outputs
        .Y   ( BIBUF_1_Y ),
        // Inouts
        .PAD ( HDMI_SDA ) 
        );

//--------CoreAPB3_C0
CoreAPB3_C0 CoreAPB3_C0_0(
        // Inputs
        .PADDR      ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PADDR_0 ),
        .PSEL       ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PSELx ),
        .PENABLE    ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PENABLE ),
        .PWRITE     ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PWRITE ),
        .PWDATA     ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PWDATA ),
        .PRDATAS0   ( CoreAPB3_C0_0_APBmslave0_PRDATA ),
        .PREADYS0   ( CoreAPB3_C0_0_APBmslave0_PREADY ),
        .PSLVERRS0  ( CoreAPB3_C0_0_APBmslave0_PSLVERR ),
        .PRDATAS15  ( CoreAPB3_C0_0_APBmslave15_PRDATA ),
        .PREADYS15  ( CoreAPB3_C0_0_APBmslave15_PREADY ),
        .PSLVERRS15 ( CoreAPB3_C0_0_APBmslave15_PSLVERR ),
        .PRDATAS16  ( PRDATAS16_const_net_0 ), // tied to 32'h00000000 from definition
        .PREADYS16  ( VCC_net ), // tied to 1'b1 from definition
        .PSLVERRS16 ( GND_net ), // tied to 1'b0 from definition
        // Outputs
        .PRDATA     ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PRDATA ),
        .PREADY     ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PREADY ),
        .PSLVERR    ( Aldec_MSS_2022_2_FIC_3_APB_INITIATOR_PSLVERR ),
        .PADDRS     ( CoreAPB3_C0_0_APBmslave0_PADDR ),
        .PSELS0     ( CoreAPB3_C0_0_APBmslave0_PSELx ),
        .PENABLES   ( CoreAPB3_C0_0_APBmslave0_PENABLE ),
        .PWRITES    ( CoreAPB3_C0_0_APBmslave0_PWRITE ),
        .PWDATAS    ( CoreAPB3_C0_0_APBmslave0_PWDATA ),
        .PSELS15    ( CoreAPB3_C0_0_APBmslave15_PSELx ),
        .PSELS16    (  ) 
        );

//--------COREAXI4INTERCONNECT_C0
COREAXI4INTERCONNECT_C0 COREAXI4INTERCONNECT_C0_0(
        // Inputs
        .ACLK             ( PF_CCC_C0_0_OUT0_FABCLK_0 ),
        .ARESETN          ( USB_ULPI_RESET_net_0 ),
        .S_CLK0           ( PF_DDR4_C0_0_SYS_CLK ),
        .SLAVE0_AWREADY   ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWREADY ),
        .SLAVE0_WREADY    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_WREADY ),
        .SLAVE0_BID       ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BID_0 ),
        .SLAVE0_BRESP     ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BRESP ),
        .SLAVE0_BVALID    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BVALID ),
        .SLAVE0_ARREADY   ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARREADY ),
        .SLAVE0_RID       ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RID_0 ),
        .SLAVE0_RDATA     ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RDATA ),
        .SLAVE0_RRESP     ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RRESP ),
        .SLAVE0_RLAST     ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RLAST ),
        .SLAVE0_RVALID    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RVALID ),
        .SLAVE0_BUSER     ( GND_net ), // tied to 1'b0 from definition
        .SLAVE0_RUSER     ( GND_net ), // tied to 1'b0 from definition
        .MASTER0_AWID     ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWID ),
        .MASTER0_AWADDR   ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWADDR_0 ),
        .MASTER0_AWLEN    ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWLEN ),
        .MASTER0_AWSIZE   ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWSIZE ),
        .MASTER0_AWBURST  ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWBURST ),
        .MASTER0_AWLOCK   ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWLOCK_0 ),
        .MASTER0_AWCACHE  ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWCACHE ),
        .MASTER0_AWPROT   ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWPROT ),
        .MASTER0_AWQOS    ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWQOS ),
        .MASTER0_AWREGION ( MASTER0_AWREGION_const_net_0 ), // tied to 4'h0 from definition
        .MASTER0_AWVALID  ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWVALID ),
        .MASTER0_WDATA    ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_WDATA ),
        .MASTER0_WSTRB    ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_WSTRB ),
        .MASTER0_WLAST    ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_WLAST ),
        .MASTER0_WVALID   ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_WVALID ),
        .MASTER0_BREADY   ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_BREADY ),
        .MASTER0_ARID     ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARID ),
        .MASTER0_ARADDR   ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARADDR_0 ),
        .MASTER0_ARLEN    ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARLEN ),
        .MASTER0_ARSIZE   ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARSIZE ),
        .MASTER0_ARBURST  ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARBURST ),
        .MASTER0_ARLOCK   ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARLOCK_0 ),
        .MASTER0_ARCACHE  ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARCACHE ),
        .MASTER0_ARPROT   ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARPROT ),
        .MASTER0_ARQOS    ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARQOS ),
        .MASTER0_ARREGION ( MASTER0_ARREGION_const_net_0 ), // tied to 4'h0 from definition
        .MASTER0_ARVALID  ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARVALID ),
        .MASTER0_RREADY   ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RREADY ),
        .MASTER0_AWUSER   ( GND_net ), // tied to 1'b0 from definition
        .MASTER0_WUSER    ( GND_net ), // tied to 1'b0 from definition
        .MASTER0_ARUSER   ( GND_net ), // tied to 1'b0 from definition
        // Outputs
        .SLAVE0_AWID      ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWID ),
        .SLAVE0_AWADDR    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWADDR ),
        .SLAVE0_AWLEN     ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWLEN ),
        .SLAVE0_AWSIZE    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWSIZE ),
        .SLAVE0_AWBURST   ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWBURST ),
        .SLAVE0_AWLOCK    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWLOCK ),
        .SLAVE0_AWCACHE   ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWCACHE ),
        .SLAVE0_AWPROT    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWPROT ),
        .SLAVE0_AWQOS     ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWQOS ),
        .SLAVE0_AWREGION  ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWREGION ),
        .SLAVE0_AWVALID   ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWVALID ),
        .SLAVE0_WDATA     ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_WDATA ),
        .SLAVE0_WSTRB     ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_WSTRB ),
        .SLAVE0_WLAST     ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_WLAST ),
        .SLAVE0_WVALID    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_WVALID ),
        .SLAVE0_BREADY    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BREADY ),
        .SLAVE0_ARID      ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARID ),
        .SLAVE0_ARADDR    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARADDR ),
        .SLAVE0_ARLEN     ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARLEN ),
        .SLAVE0_ARSIZE    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARSIZE ),
        .SLAVE0_ARBURST   ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARBURST ),
        .SLAVE0_ARLOCK    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARLOCK ),
        .SLAVE0_ARCACHE   ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARCACHE ),
        .SLAVE0_ARPROT    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARPROT ),
        .SLAVE0_ARQOS     ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARQOS ),
        .SLAVE0_ARREGION  ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARREGION ),
        .SLAVE0_ARVALID   ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARVALID ),
        .SLAVE0_RREADY    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RREADY ),
        .SLAVE0_AWUSER    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWUSER ),
        .SLAVE0_WUSER     ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_WUSER ),
        .SLAVE0_ARUSER    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARUSER ),
        .MASTER0_AWREADY  ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_AWREADY ),
        .MASTER0_WREADY   ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_WREADY ),
        .MASTER0_BID      ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_BID ),
        .MASTER0_BRESP    ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_BRESP ),
        .MASTER0_BVALID   ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_BVALID ),
        .MASTER0_ARREADY  ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_ARREADY ),
        .MASTER0_RID      ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RID ),
        .MASTER0_RDATA    ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RDATA ),
        .MASTER0_RRESP    ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RRESP ),
        .MASTER0_RLAST    ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RLAST ),
        .MASTER0_RVALID   ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RVALID ),
        .MASTER0_BUSER    ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_BUSER ),
        .MASTER0_RUSER    ( Aldec_MSS_2022_2_FIC_0_AXI4_INITIATOR_RUSER ) 
        );

//--------CoreGPIO_C0
CoreGPIO_C0 CoreGPIO_C0_0(
        // Inputs
        .PRESETN  ( USB_ULPI_RESET_net_0 ),
        .PCLK     ( PF_CCC_C0_0_OUT0_FABCLK_0 ),
        .GPIO_IN  ( GPIO_IN_const_net_0 ),
        .PADDR    ( CoreAPB3_C0_0_APBmslave0_PADDR_0 ),
        .PSEL     ( CoreAPB3_C0_0_APBmslave0_PSELx ),
        .PENABLE  ( CoreAPB3_C0_0_APBmslave0_PENABLE ),
        .PWRITE   ( CoreAPB3_C0_0_APBmslave0_PWRITE ),
        .PWDATA   ( CoreAPB3_C0_0_APBmslave0_PWDATA ),
        // Outputs
        .INT      (  ),
        .GPIO_OUT ( CoreGPIO_C0_0_GPIO_OUT ),
        .GPIO_OE  (  ),
        .PRDATA   ( CoreAPB3_C0_0_APBmslave0_PRDATA ),
        .PREADY   ( CoreAPB3_C0_0_APBmslave0_PREADY ),
        .PSLVERR  ( CoreAPB3_C0_0_APBmslave0_PSLVERR ) 
        );

//--------CORERESET_PF_C0
CORERESET_PF_C0 CORERESET_PF_C0_0(
        // Inputs
        .CLK                ( PF_CCC_C0_0_OUT0_FABCLK_0 ),
        .EXT_RST_N          ( VCC_net ),
        .BANK_x_VDDI_STATUS ( PFSOC_INIT_MONITOR_C0_0_BANK_0_VDDI_STATUS ),
        .BANK_y_VDDI_STATUS ( PFSOC_INIT_MONITOR_C0_0_BANK_0_VDDI_STATUS ),
        .PLL_LOCK           ( PF_CCC_C0_0_PLL_LOCK_0 ),
        .SS_BUSY            ( GND_net ),
        .INIT_DONE          ( PFSOC_INIT_MONITOR_C0_0_DEVICE_INIT_DONE ),
        .FF_US_RESTORE      ( GND_net ),
        .FPGA_POR_N         ( PFSOC_INIT_MONITOR_C0_0_FABRIC_POR_N ),
        // Outputs
        .PLL_POWERDOWN_B    ( CORERESET_PF_C0_0_PLL_POWERDOWN_B ),
        .FABRIC_RESET_N     ( USB_ULPI_RESET_net_0 ) 
        );

//--------CORERESET_PF_C0
CORERESET_PF_C0 CORERESET_PF_C0_1(
        // Inputs
        .CLK                ( HDMI_CLK_net_0 ),
        .EXT_RST_N          ( VCC_net ),
        .BANK_x_VDDI_STATUS ( PFSOC_INIT_MONITOR_C0_0_BANK_0_VDDI_STATUS ),
        .BANK_y_VDDI_STATUS ( PFSOC_INIT_MONITOR_C0_0_BANK_0_VDDI_STATUS ),
        .PLL_LOCK           ( PF_CCC_C1_0_PLL_LOCK_0 ),
        .SS_BUSY            ( GND_net ),
        .INIT_DONE          ( PFSOC_INIT_MONITOR_C0_0_DEVICE_INIT_DONE ),
        .FF_US_RESTORE      ( GND_net ),
        .FPGA_POR_N         ( PFSOC_INIT_MONITOR_C0_0_FABRIC_POR_N ),
        // Outputs
        .PLL_POWERDOWN_B    ( CORERESET_PF_C0_1_PLL_POWERDOWN_B ),
        .FABRIC_RESET_N     ( CORERESET_PF_C0_1_FABRIC_RESET_N ) 
        );

//--------Display_Controller_C1
Display_Controller_C1 Display_Controller_C0_0(
        // Inputs
        .RESETN_I          ( CORERESET_PF_C0_1_FABRIC_RESET_N ),
        .SYS_CLK_I         ( HDMI_CLK_net_0 ),
        .ENABLE_I          ( VCC_net ),
        .EXT_SYNC_SIGNAL_I ( Test_Pattern_Generator_C0_0_DATA_VALID_O ),
        .DATA_I            ( DATA_I_net_0 ),
        // Outputs
        .FRAME_END_O       ( Display_Controller_C0_0_FRAME_END_O ),
        .H_SYNC_O          ( HDMI_HSYNC_net_0 ),
        .V_SYNC_O          ( HDMI_VSYNC_net_0 ),
        .V_ACTIVE_O        (  ),
        .DATA_TRIGGER_O    ( Display_Controller_C0_0_DATA_TRIGGER_O ),
        .DATA_VALID_O      ( HDMI_DE_net_0 ),
        .H_RES_O           (  ),
        .V_RES_O           (  ),
        .DATA_O            ( DATA_O_net_0 ) 
        );

//--------fabric_sd_emmc_demux_select
fabric_sd_emmc_demux_select fabric_sd_emmc_demux_select_0(
        // Inputs
        .pclk                            ( PF_CCC_C0_0_OUT0_FABCLK_0 ),
        .presetn                         ( USB_ULPI_RESET_net_0 ),
        .penable                         ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PENABLE ),
        .psel                            ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PSELx ),
        .paddr                           ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PADDR ),
        .pwrite                          ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PWRITE ),
        .pwdata                          ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PWDATA ),
        // Outputs
        .prdata                          ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PRDATA ),
        .pready                          ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PREADY ),
        .pslverr                         ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PSLVERR ),
        .fabric_sd_emmc_demux_select_out ( SD_SEL_net_0 ) 
        );

//--------FIC_3_0x4FFF_Fxxx
FIC_3_0x4FFF_Fxxx FIC_3_0x4FFF_Fxxx_0(
        // Inputs
        .PADDR      ( APB_PASS_THROUGH_0_APB_INITIATOR_PADDR ),
        .PSEL       ( APB_PASS_THROUGH_0_APB_INITIATOR_PSELx ),
        .PENABLE    ( APB_PASS_THROUGH_0_APB_INITIATOR_PENABLE ),
        .PWRITE     ( APB_PASS_THROUGH_0_APB_INITIATOR_PWRITE ),
        .PWDATA     ( APB_PASS_THROUGH_0_APB_INITIATOR_PWDATA ),
        .PRDATAS15  ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PRDATA ),
        .PREADYS15  ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PREADY ),
        .PSLVERRS15 ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PSLVERR ),
        // Outputs
        .PRDATA     ( APB_PASS_THROUGH_0_APB_INITIATOR_PRDATA ),
        .PREADY     ( APB_PASS_THROUGH_0_APB_INITIATOR_PREADY ),
        .PSLVERR    ( APB_PASS_THROUGH_0_APB_INITIATOR_PSLVERR ),
        .PADDRS     ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PADDR ),
        .PSELS15    ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PSELx ),
        .PENABLES   ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PENABLE ),
        .PWRITES    ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PWRITE ),
        .PWDATAS    ( FIC_3_0x4FFF_Fxxx_0_APBmslave15_PWDATA ) 
        );

//--------PF_CCC_C0
PF_CCC_C0 PF_CCC_C0_0(
        // Inputs
        .REF_CLK_0         ( PF_OSC_C0_0_RCOSC_160MHZ_GL ),
        .PLL_POWERDOWN_N_0 ( CORERESET_PF_C0_0_PLL_POWERDOWN_B ),
        // Outputs
        .OUT0_FABCLK_0     ( PF_CCC_C0_0_OUT0_FABCLK_0 ),
        .OUT1_FABCLK_0     ( PF_CCC_C0_0_OUT1_FABCLK_0 ),
        .PLL_LOCK_0        ( PF_CCC_C0_0_PLL_LOCK_0 ) 
        );

//--------PF_CCC_C1
PF_CCC_C1 PF_CCC_C1_0(
        // Inputs
        .REF_CLK_0         ( PF_OSC_C0_0_RCOSC_160MHZ_GL ),
        .PLL_POWERDOWN_N_0 ( CORERESET_PF_C0_1_PLL_POWERDOWN_B ),
        // Outputs
        .OUT0_FABCLK_0     ( HDMI_CLK_net_0 ),
        .PLL_LOCK_0        ( PF_CCC_C1_0_PLL_LOCK_0 ) 
        );

//--------PF_DDR4_C0
PF_DDR4_C0 PF_DDR4_C0_0(
        // Inputs
        .PLL_REF_CLK  ( PF_CCC_C0_0_OUT1_FABCLK_0 ),
        .SYS_RESET_N  ( USB_ULPI_RESET_net_0 ),
        .axi0_awid    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWID_0 ),
        .axi0_awaddr  ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWADDR ),
        .axi0_awlen   ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWLEN ),
        .axi0_awsize  ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWSIZE ),
        .axi0_awburst ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWBURST ),
        .axi0_awlock  ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWLOCK ),
        .axi0_awcache ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWCACHE ),
        .axi0_awprot  ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWPROT ),
        .axi0_awvalid ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWVALID ),
        .axi0_wdata   ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_WDATA ),
        .axi0_wstrb   ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_WSTRB ),
        .axi0_wlast   ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_WLAST ),
        .axi0_wvalid  ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_WVALID ),
        .axi0_bready  ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BREADY ),
        .axi0_arid    ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARID_0 ),
        .axi0_araddr  ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARADDR ),
        .axi0_arlen   ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARLEN ),
        .axi0_arsize  ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARSIZE ),
        .axi0_arburst ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARBURST ),
        .axi0_arlock  ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARLOCK ),
        .axi0_arcache ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARCACHE ),
        .axi0_arprot  ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARPROT ),
        .axi0_arvalid ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARVALID ),
        .axi0_rready  ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RREADY ),
        // Outputs
        .DM_N         ( DM_N_net_0 ),
        .CKE          ( CKE_net_0 ),
        .CS_N         ( CS_N_net_0 ),
        .ODT          ( ODT_net_0 ),
        .RAS_N        ( RAS_N_0_net_0 ),
        .CAS_N        ( CAS_N_0_net_0 ),
        .WE_N         ( WE_N_0_net_0 ),
        .ACT_N        ( ACT_N_0_net_0 ),
        .BG           ( BG_0_net_0 ),
        .BA           ( BA_0_net_0 ),
        .RESET_N      ( RESET_N_0_net_0 ),
        .A            ( A_0_net_0 ),
        .CK0          ( CK0_0_net_0 ),
        .CK0_N        ( CK0_N_0_net_0 ),
        .SHIELD0      ( SHIELD0_net_0 ),
        .SHIELD1      ( SHIELD1_net_0 ),
        .SHIELD2      ( SHIELD2_net_0 ),
        .SHIELD3      ( SHIELD3_net_0 ),
        .SYS_CLK      ( PF_DDR4_C0_0_SYS_CLK ),
        .PLL_LOCK     (  ),
        .axi0_awready ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_AWREADY ),
        .axi0_wready  ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_WREADY ),
        .axi0_bid     ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BID ),
        .axi0_bresp   ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BRESP ),
        .axi0_bvalid  ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_BVALID ),
        .axi0_arready ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_ARREADY ),
        .axi0_rid     ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RID ),
        .axi0_rdata   ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RDATA ),
        .axi0_rresp   ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RRESP ),
        .axi0_rlast   ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RLAST ),
        .axi0_rvalid  ( COREAXI4INTERCONNECT_C0_0_AXI4mslave0_RVALID ),
        .CTRLR_READY  (  ),
        // Inouts
        .DQ           ( DQ_0 ),
        .DQS          ( DQS_0 ),
        .DQS_N        ( DQS_N_0 ) 
        );

//--------PF_OSC_C0
PF_OSC_C0 PF_OSC_C0_0(
        // Outputs
        .RCOSC_160MHZ_GL ( PF_OSC_C0_0_RCOSC_160MHZ_GL ) 
        );

//--------PFSOC_INIT_MONITOR_C0
PFSOC_INIT_MONITOR_C0 PFSOC_INIT_MONITOR_C0_0(
        // Outputs
        .FABRIC_POR_N               ( PFSOC_INIT_MONITOR_C0_0_FABRIC_POR_N ),
        .PCIE_INIT_DONE             (  ),
        .USRAM_INIT_DONE            (  ),
        .SRAM_INIT_DONE             (  ),
        .DEVICE_INIT_DONE           ( PFSOC_INIT_MONITOR_C0_0_DEVICE_INIT_DONE ),
        .BANK_0_VDDI_STATUS         ( PFSOC_INIT_MONITOR_C0_0_BANK_0_VDDI_STATUS ),
        .XCVR_INIT_DONE             (  ),
        .USRAM_INIT_FROM_SNVM_DONE  (  ),
        .USRAM_INIT_FROM_UPROM_DONE (  ),
        .USRAM_INIT_FROM_SPI_DONE   (  ),
        .SRAM_INIT_FROM_SNVM_DONE   (  ),
        .SRAM_INIT_FROM_UPROM_DONE  (  ),
        .SRAM_INIT_FROM_SPI_DONE    (  ),
        .AUTOCALIB_DONE             (  ) 
        );

//--------Test_Pattern_Generator_C0
Test_Pattern_Generator_C0 Test_Pattern_Generator_C0_0(
        // Inputs
        .SYS_CLK_I       ( HDMI_CLK_net_0 ),
        .RESET_N_I       ( CORERESET_PF_C0_1_FABRIC_RESET_N ),
        .DATA_EN_I       ( Display_Controller_C0_0_DATA_TRIGGER_O ),
        .FRAME_END_I     ( Display_Controller_C0_0_FRAME_END_O ),
        .PATTERN_SEL_I   ( CoreGPIO_C0_0_GPIO_OUT ),
        .BAYER_PATTERN_I ( BAYER_PATTERN_I_const_net_0 ),
        // Outputs
        .DATA_VALID_O    ( Test_Pattern_Generator_C0_0_DATA_VALID_O ),
        .FRAME_END_O     (  ),
        .LINE_END_O      (  ),
        .RED_O           ( Test_Pattern_Generator_C0_0_RED_O ),
        .GREEN_O         ( Test_Pattern_Generator_C0_0_GREEN_O ),
        .BLUE_O          ( Test_Pattern_Generator_C0_0_BLUE_O ),
        .BAYER_O         (  ) 
        );


endmodule
