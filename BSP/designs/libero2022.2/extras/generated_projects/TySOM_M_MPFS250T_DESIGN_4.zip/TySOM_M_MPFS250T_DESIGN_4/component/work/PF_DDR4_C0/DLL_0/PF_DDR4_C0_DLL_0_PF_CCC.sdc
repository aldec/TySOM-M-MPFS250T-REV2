set_component PF_DDR4_C0_DLL_0_PF_CCC
# Microsemi Corp.
# Date: 2025-Jan-14 12:23:41
#

create_clock -period 7.5188 [ get_pins { dll_inst_0/REF_CLK } ]
