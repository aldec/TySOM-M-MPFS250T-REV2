set_component PF_CCC_C1_PF_CCC_C1_0_PF_CCC
# Microsemi Corp.
# Date: 2025-Jan-14 12:22:57
#

# Base clock for PLL #0
create_clock -period 6.25 [ get_pins { pll_inst_0/REF_CLK_0 } ]
create_generated_clock -multiply_by 297 -divide_by 320 -source [ get_pins { pll_inst_0/REF_CLK_0 } ] -phase 0 [ get_pins { pll_inst_0/OUT0 } ]
