set_device -family {PolarFireSoC} -die {MPFS250T_ES} -speed {-1} -range {EXT}
read_verilog -mode system_verilog {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/hdl/APB_ARBITER.v}
read_verilog -mode system_verilog {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/hdl/APB_PASS_THROUGH.v}
read_verilog -mode system_verilog {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/CORERESET_PF_C0/CORERESET_PF_C0_0/core/corereset_pf.v}
read_verilog -mode system_verilog {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/CORERESET_PF_C0/CORERESET_PF_C0.v}
read_verilog -mode system_verilog -lib COREAPB3_LIB {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/Actel/DirectCore/CoreAPB3/4.2.100/rtl/vlog/core/coreapb3_muxptob3.v}
read_verilog -mode system_verilog -lib COREAPB3_LIB {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/Actel/DirectCore/CoreAPB3/4.2.100/rtl/vlog/core/coreapb3_iaddr_reg.v}
read_verilog -mode system_verilog -lib COREAPB3_LIB {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/Actel/DirectCore/CoreAPB3/4.2.100/rtl/vlog/core/coreapb3.v}
read_verilog -mode system_verilog {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/FIC_3_0x4FFF_Fxxx/FIC_3_0x4FFF_Fxxx.v}
read_verilog -mode system_verilog {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/FIC_3_0x4xxx_xxxx/FIC_3_0x4xxx_xxxx.v}
read_verilog -mode system_verilog {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/PFSOC_INIT_MONITOR_C0/PFSOC_INIT_MONITOR_C0_0/PFSOC_INIT_MONITOR_C0_PFSOC_INIT_MONITOR_C0_0_PFSOC_INIT_MONITOR.v}
read_verilog -mode system_verilog {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/PFSOC_INIT_MONITOR_C0/PFSOC_INIT_MONITOR_C0.v}
read_verilog -mode system_verilog {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/PF_CCC_C0/PF_CCC_C0_0/PF_CCC_C0_PF_CCC_C0_0_PF_CCC.v}
read_verilog -mode system_verilog {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/PF_CCC_C0/PF_CCC_C0.v}
read_verilog -mode system_verilog {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/PF_OSC_C0/PF_OSC_C0_0/PF_OSC_C0_PF_OSC_C0_0_PF_OSC.v}
read_verilog -mode system_verilog {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/PF_OSC_C0/PF_OSC_C0.v}
read_verilog -mode system_verilog {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/TySOM_M_2024_9/TySOM_M_2024_9.v}
read_verilog -mode system_verilog {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/hdl/fabric_sd_emmc_demux_select.v}
read_verilog -mode system_verilog {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/TySOM_M_SYSTEM/TySOM_M_SYSTEM.v}
set_top_level {TySOM_M_SYSTEM}
read_sdc -component {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/TySOM_M_2024_9/TySOM_M_2024_9.sdc}
read_sdc -component {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/PF_CCC_C0/PF_CCC_C0_0/PF_CCC_C0_PF_CCC_C0_0_PF_CCC.sdc}
derive_constraints
write_sdc {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/constraint/TySOM_M_SYSTEM_derived_constraints.sdc}
write_ndc {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/constraint/TySOM_M_SYSTEM_derived_constraints.ndc}
write_pdc {/home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/constraint/fp/TySOM_M_SYSTEM_derived_constraints.pdc}
