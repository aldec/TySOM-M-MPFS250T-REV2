# Microchip Technology Inc.
# Date: 2025-Apr-18 09:23:42
# This file was generated based on the following SDC source files:
#   /home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/TySOM_M_2024_9/TySOM_M_2024_9.sdc
#   /home/makro/Desktop/Git/tysom_m_base/BSP/designs/libero2024.2/tysom_m_mpfs250t_ref_design_1/TySOM_M_MPFS250T/component/work/PF_CCC_C0/PF_CCC_C0_0/PF_CCC_C0_PF_CCC_C0_0_PF_CCC.sdc
#   /edatools/microsemi/Libero_SoC_v2024.2/Libero/data/aPA5M/cores/constraints/EXT/osc_rc160mhz.sdc
# *** Any modifications to this file will be lost if derived constraints is re-run. ***
#

create_clock -name {osc_rc160mhz} -period 5.86854 [ get_pins { PF_OSC_C0_0/PF_OSC_C0_0/I_OSC_160/CLK } ]
create_generated_clock -name {PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/OUT3} -multiply_by 25 -divide_by 64 -source [ get_pins { PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/REF_CLK_0 } ] -phase 0 [ get_pins { PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/OUT3 } ]
