//--------------------------------------------------------------------
// Created by Microsemi SmartDesign Fri Apr 18 09:23:24 2025
// Parameters for CoreAPB3
//--------------------------------------------------------------------


parameter APB_DWIDTH = 32;
parameter APBSLOT0ENABLE = 1;
parameter APBSLOT1ENABLE = 0;
parameter APBSLOT2ENABLE = 0;
parameter APBSLOT3ENABLE = 0;
parameter APBSLOT4ENABLE = 0;
parameter APBSLOT5ENABLE = 0;
parameter APBSLOT6ENABLE = 0;
parameter APBSLOT7ENABLE = 0;
parameter APBSLOT8ENABLE = 0;
parameter APBSLOT9ENABLE = 0;
parameter APBSLOT10ENABLE = 0;
parameter APBSLOT11ENABLE = 0;
parameter APBSLOT12ENABLE = 0;
parameter APBSLOT13ENABLE = 0;
parameter APBSLOT14ENABLE = 0;
parameter APBSLOT15ENABLE = 1;
parameter FAMILY = 27;
parameter HDL_license = "U";
parameter IADDR_OPTION = 0;
parameter MADDR_BITS = 28;
parameter SC_0 = 0;
parameter SC_1 = 0;
parameter SC_2 = 0;
parameter SC_3 = 1;
parameter SC_4 = 0;
parameter SC_5 = 0;
parameter SC_6 = 0;
parameter SC_7 = 0;
parameter SC_8 = 1;
parameter SC_9 = 0;
parameter SC_10 = 0;
parameter SC_11 = 0;
parameter SC_12 = 0;
parameter SC_13 = 0;
parameter SC_14 = 0;
parameter SC_15 = 0;
parameter testbench = "User";
parameter UPR_NIBBLE_POSN = 6;
