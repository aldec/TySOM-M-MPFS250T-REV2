set_component PF_DDR4_C0_DLL_0_PF_CCC
# Microchip Technology Inc.
# Date: 2025-Apr-18 09:31:14
#

create_clock -period 7.5188 [ get_pins { dll_inst_0/REF_CLK } ]
