//--------------------------------------------------------------------
// Created by Microsemi SmartDesign Tue Jan 14 12:09:28 2025
// Parameters for LiteFast
//--------------------------------------------------------------------


parameter g_DATA_WID = 32;
parameter g_LANE_NUM = 1;
parameter HDL_license = "O";
parameter LiteFast_Mode = 2;
