//////////////////////////////////////////////////////////////////////
// Created by SmartDesign Tue Jan 14 12:09:15 2025
// Version: 2022.2 2022.2.0.10
//////////////////////////////////////////////////////////////////////

`timescale 1ns / 100ps

//////////////////////////////////////////////////////////////////////
// Component Description (Tcl) 
//////////////////////////////////////////////////////////////////////
/*
# Exporting Component Description of LiteFast_C3 to TCL
# Family: PolarFireSoC
# Part Number: MPFS250T_ES-1FCG1152E
# Create and Configure the core component LiteFast_C3
create_and_configure_core -core_vlnv {Microsemi:SolutionCore:LiteFast:1.0.5} -component_name {LiteFast_C3} -params {\
"g_DATA_WID:32"  \
"g_LANE_NUM:1"  \
"LiteFast_Mode:1"   }
# Exporting Component Description of LiteFast_C3 to TCL done
*/

// LiteFast_C3
module LiteFast_C3(
    // Inputs
    clk_rx_i,
    lane_data_rx_i,
    lane_k_rx_i,
    rst_n_rx_i,
    serdes_rx_val_i,
    word_aligned_rx_i,
    // Outputs
    block_aligned_rx_o,
    crc_err_rx_o,
    lane_aligned_rx_o,
    remote_token_rx_o,
    usr_data_rx_o,
    usr_data_val_rx_o
);

//--------------------------------------------------------------------
// Input
//--------------------------------------------------------------------
input         clk_rx_i;
input  [31:0] lane_data_rx_i;
input  [3:0]  lane_k_rx_i;
input         rst_n_rx_i;
input  [0:0]  serdes_rx_val_i;
input  [0:0]  word_aligned_rx_i;
//--------------------------------------------------------------------
// Output
//--------------------------------------------------------------------
output [0:0]  block_aligned_rx_o;
output        crc_err_rx_o;
output        lane_aligned_rx_o;
output [7:0]  remote_token_rx_o;
output [31:0] usr_data_rx_o;
output        usr_data_val_rx_o;
//--------------------------------------------------------------------
// Nets
//--------------------------------------------------------------------
wire   [0:0]  block_aligned_rx_o_net_0;
wire          clk_rx_i;
wire          crc_err_rx_o_net_0;
wire          lane_aligned_rx_o_net_0;
wire   [31:0] lane_data_rx_i;
wire   [3:0]  lane_k_rx_i;
wire   [7:0]  remote_token_rx_o_net_0;
wire          rst_n_rx_i;
wire   [0:0]  serdes_rx_val_i;
wire   [31:0] usr_data_rx_o_net_0;
wire          usr_data_val_rx_o_net_0;
wire   [0:0]  word_aligned_rx_i;
wire   [0:0]  block_aligned_rx_o_net_1;
wire          lane_aligned_rx_o_net_1;
wire   [7:0]  remote_token_rx_o_net_1;
wire          crc_err_rx_o_net_1;
wire          usr_data_val_rx_o_net_1;
wire   [31:0] usr_data_rx_o_net_1;
//--------------------------------------------------------------------
// TiedOff Nets
//--------------------------------------------------------------------
wire          GND_net;
wire   [7:0]  min_remote_token_tx_i_const_net_0;
wire   [31:0] usr_data_tx_i_const_net_0;
wire   [7:0]  local_token_tx_i_const_net_0;
wire   [7:0]  remote_token_tx_i_const_net_0;
//--------------------------------------------------------------------
// Constant assignments
//--------------------------------------------------------------------
assign GND_net                           = 1'b0;
assign min_remote_token_tx_i_const_net_0 = 8'h00;
assign usr_data_tx_i_const_net_0         = 32'h00000000;
assign local_token_tx_i_const_net_0      = 8'h00;
assign remote_token_tx_i_const_net_0     = 8'h00;
//--------------------------------------------------------------------
// Top level output port assignments
//--------------------------------------------------------------------
assign block_aligned_rx_o_net_1[0] = block_aligned_rx_o_net_0[0];
assign block_aligned_rx_o[0:0]     = block_aligned_rx_o_net_1[0];
assign lane_aligned_rx_o_net_1     = lane_aligned_rx_o_net_0;
assign lane_aligned_rx_o           = lane_aligned_rx_o_net_1;
assign remote_token_rx_o_net_1     = remote_token_rx_o_net_0;
assign remote_token_rx_o[7:0]      = remote_token_rx_o_net_1;
assign crc_err_rx_o_net_1          = crc_err_rx_o_net_0;
assign crc_err_rx_o                = crc_err_rx_o_net_1;
assign usr_data_val_rx_o_net_1     = usr_data_val_rx_o_net_0;
assign usr_data_val_rx_o           = usr_data_val_rx_o_net_1;
assign usr_data_rx_o_net_1         = usr_data_rx_o_net_0;
assign usr_data_rx_o[31:0]         = usr_data_rx_o_net_1;
//--------------------------------------------------------------------
// Component instances
//--------------------------------------------------------------------
//--------LiteFast   -   Microsemi:SolutionCore:LiteFast:1.0.5
LiteFast #( 
        .g_DATA_WID    ( 32 ),
        .g_LANE_NUM    ( 1 ),
        .LiteFast_Mode ( 1 ) )
LiteFast_C3_0(
        // Inputs
        .clk_tx_i              ( GND_net ), // tied to 1'b0 from definition
        .rst_n_tx_i            ( GND_net ), // tied to 1'b0 from definition
        .min_remote_token_tx_i ( min_remote_token_tx_i_const_net_0 ), // tied to 8'h00 from definition
        .simplex_en_i          ( GND_net ), // tied to 1'b0 from definition
        .local_rece_rdy_tx_i   ( GND_net ), // tied to 1'b0 from definition
        .usr_data_rdy_tx_i     ( GND_net ), // tied to 1'b0 from definition
        .usr_data_tx_i         ( usr_data_tx_i_const_net_0 ), // tied to 32'h00000000 from definition
        .usr_data_val_tx_i     ( GND_net ), // tied to 1'b0 from definition
        .local_token_tx_i      ( local_token_tx_i_const_net_0 ), // tied to 8'h00 from definition
        .remote_token_tx_i     ( remote_token_tx_i_const_net_0 ), // tied to 8'h00 from definition
        .crc_err_en_tx_i       ( GND_net ), // tied to 1'b0 from definition
        .clk_rx_i              ( clk_rx_i ),
        .rst_n_rx_i            ( rst_n_rx_i ),
        .serdes_rx_val_i       ( serdes_rx_val_i ),
        .word_aligned_rx_i     ( word_aligned_rx_i ),
        .lane_k_rx_i           ( lane_k_rx_i ),
        .lane_data_rx_i        ( lane_data_rx_i ),
        // Outputs
        .req_usr_data_tx_o     (  ),
        .LiteFast_k_tx_o       (  ),
        .LiteFast_data_tx_o    (  ),
        .block_aligned_rx_o    ( block_aligned_rx_o_net_0 ),
        .lane_aligned_rx_o     ( lane_aligned_rx_o_net_0 ),
        .remote_token_rx_o     ( remote_token_rx_o_net_0 ),
        .crc_err_rx_o          ( crc_err_rx_o_net_0 ),
        .usr_data_val_rx_o     ( usr_data_val_rx_o_net_0 ),
        .usr_data_rx_o         ( usr_data_rx_o_net_0 ) 
        );


endmodule
