set_component PF_XCVR_ERM_C0_I_XCVR_PF_XCVR
# Microchip Technology Inc.
# Date: 2025-Apr-17 10:49:13
#

create_clock -period 8 [ get_pins { LANE0/REF_CLK_P } ]
create_clock -period 16 [ get_pins { LANE0/TX_CLK_R } ]
create_clock -period 16 [ get_pins { LANE0/RX_CLK_R } ]
create_clock -period 8 [ get_pins { LANE1/REF_CLK_P } ]
create_clock -period 16 [ get_pins { LANE1/TX_CLK_R } ]
create_clock -period 16 [ get_pins { LANE1/RX_CLK_R } ]
