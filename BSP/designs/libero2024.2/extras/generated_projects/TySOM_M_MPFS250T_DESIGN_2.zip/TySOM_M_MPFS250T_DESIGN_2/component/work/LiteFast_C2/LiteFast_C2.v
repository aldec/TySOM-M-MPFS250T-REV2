//////////////////////////////////////////////////////////////////////
// Created by SmartDesign Tue Jan 14 12:09:28 2025
// Version: 2022.2 2022.2.0.10
//////////////////////////////////////////////////////////////////////

`timescale 1ns / 100ps

//////////////////////////////////////////////////////////////////////
// Component Description (Tcl) 
//////////////////////////////////////////////////////////////////////
/*
# Exporting Component Description of LiteFast_C2 to TCL
# Family: PolarFireSoC
# Part Number: MPFS250T_ES-1FCG1152E
# Create and Configure the core component LiteFast_C2
create_and_configure_core -core_vlnv {Microsemi:SolutionCore:LiteFast:1.0.5} -component_name {LiteFast_C2} -params {\
"g_DATA_WID:32"  \
"g_LANE_NUM:1"  \
"LiteFast_Mode:2"   }
# Exporting Component Description of LiteFast_C2 to TCL done
*/

// LiteFast_C2
module LiteFast_C2(
    // Inputs
    clk_tx_i,
    crc_err_en_tx_i,
    local_rece_rdy_tx_i,
    local_token_tx_i,
    min_remote_token_tx_i,
    remote_token_tx_i,
    rst_n_tx_i,
    simplex_en_i,
    usr_data_rdy_tx_i,
    usr_data_tx_i,
    usr_data_val_tx_i,
    // Outputs
    LiteFast_data_tx_o,
    LiteFast_k_tx_o,
    req_usr_data_tx_o
);

//--------------------------------------------------------------------
// Input
//--------------------------------------------------------------------
input         clk_tx_i;
input         crc_err_en_tx_i;
input         local_rece_rdy_tx_i;
input  [7:0]  local_token_tx_i;
input  [7:0]  min_remote_token_tx_i;
input  [7:0]  remote_token_tx_i;
input         rst_n_tx_i;
input         simplex_en_i;
input         usr_data_rdy_tx_i;
input  [31:0] usr_data_tx_i;
input         usr_data_val_tx_i;
//--------------------------------------------------------------------
// Output
//--------------------------------------------------------------------
output [31:0] LiteFast_data_tx_o;
output [3:0]  LiteFast_k_tx_o;
output        req_usr_data_tx_o;
//--------------------------------------------------------------------
// Nets
//--------------------------------------------------------------------
wire          clk_tx_i;
wire          crc_err_en_tx_i;
wire   [31:0] LiteFast_data_tx_o_net_0;
wire   [3:0]  LiteFast_k_tx_o_net_0;
wire          local_rece_rdy_tx_i;
wire   [7:0]  local_token_tx_i;
wire   [7:0]  min_remote_token_tx_i;
wire   [7:0]  remote_token_tx_i;
wire          req_usr_data_tx_o_net_0;
wire          rst_n_tx_i;
wire          simplex_en_i;
wire          usr_data_rdy_tx_i;
wire   [31:0] usr_data_tx_i;
wire          usr_data_val_tx_i;
wire          req_usr_data_tx_o_net_1;
wire   [3:0]  LiteFast_k_tx_o_net_1;
wire   [31:0] LiteFast_data_tx_o_net_1;
//--------------------------------------------------------------------
// TiedOff Nets
//--------------------------------------------------------------------
wire          GND_net;
wire   [3:0]  lane_k_rx_i_const_net_0;
wire   [31:0] lane_data_rx_i_const_net_0;
//--------------------------------------------------------------------
// Constant assignments
//--------------------------------------------------------------------
assign GND_net                    = 1'b0;
assign lane_k_rx_i_const_net_0    = 4'h0;
assign lane_data_rx_i_const_net_0 = 32'h00000000;
//--------------------------------------------------------------------
// Top level output port assignments
//--------------------------------------------------------------------
assign req_usr_data_tx_o_net_1  = req_usr_data_tx_o_net_0;
assign req_usr_data_tx_o        = req_usr_data_tx_o_net_1;
assign LiteFast_k_tx_o_net_1    = LiteFast_k_tx_o_net_0;
assign LiteFast_k_tx_o[3:0]     = LiteFast_k_tx_o_net_1;
assign LiteFast_data_tx_o_net_1 = LiteFast_data_tx_o_net_0;
assign LiteFast_data_tx_o[31:0] = LiteFast_data_tx_o_net_1;
//--------------------------------------------------------------------
// Component instances
//--------------------------------------------------------------------
//--------LiteFast   -   Microsemi:SolutionCore:LiteFast:1.0.5
LiteFast #( 
        .g_DATA_WID    ( 32 ),
        .g_LANE_NUM    ( 1 ),
        .LiteFast_Mode ( 2 ) )
LiteFast_C2_0(
        // Inputs
        .clk_tx_i              ( clk_tx_i ),
        .rst_n_tx_i            ( rst_n_tx_i ),
        .min_remote_token_tx_i ( min_remote_token_tx_i ),
        .simplex_en_i          ( simplex_en_i ),
        .local_rece_rdy_tx_i   ( local_rece_rdy_tx_i ),
        .usr_data_rdy_tx_i     ( usr_data_rdy_tx_i ),
        .usr_data_tx_i         ( usr_data_tx_i ),
        .usr_data_val_tx_i     ( usr_data_val_tx_i ),
        .local_token_tx_i      ( local_token_tx_i ),
        .remote_token_tx_i     ( remote_token_tx_i ),
        .crc_err_en_tx_i       ( crc_err_en_tx_i ),
        .clk_rx_i              ( GND_net ), // tied to 1'b0 from definition
        .rst_n_rx_i            ( GND_net ), // tied to 1'b0 from definition
        .serdes_rx_val_i       ( GND_net ), // tied to 1'b0 from definition
        .word_aligned_rx_i     ( GND_net ), // tied to 1'b0 from definition
        .lane_k_rx_i           ( lane_k_rx_i_const_net_0 ), // tied to 4'h0 from definition
        .lane_data_rx_i        ( lane_data_rx_i_const_net_0 ), // tied to 32'h00000000 from definition
        // Outputs
        .req_usr_data_tx_o     ( req_usr_data_tx_o_net_0 ),
        .LiteFast_k_tx_o       ( LiteFast_k_tx_o_net_0 ),
        .LiteFast_data_tx_o    ( LiteFast_data_tx_o_net_0 ),
        .block_aligned_rx_o    (  ),
        .lane_aligned_rx_o     (  ),
        .remote_token_rx_o     (  ),
        .crc_err_rx_o          (  ),
        .usr_data_val_rx_o     (  ),
        .usr_data_rx_o         (  ) 
        );


endmodule
