//////////////////////////////////////////////////////////////////////
// Created by SmartDesign Tue Jan 14 12:09:33 2025
// Version: 2022.2 2022.2.0.10
//////////////////////////////////////////////////////////////////////

`timescale 1ns / 100ps

// LiteFast_transmitter
module LiteFast_transmitter(
    // Inputs
    DATA,
    DATA_0,
    DATA_1,
    WCLOCK,
    clk_i,
    local_rece_rdy_tx_i,
    local_token_tx_i,
    remote_token_tx_i,
    start_i,
    // Outputs
    LiteFast_data_tx_o,
    LiteFast_k_tx_o
);

//--------------------------------------------------------------------
// Input
//--------------------------------------------------------------------
input         DATA;
input         DATA_0;
input         DATA_1;
input         WCLOCK;
input         clk_i;
input         local_rece_rdy_tx_i;
input  [7:0]  local_token_tx_i;
input  [7:0]  remote_token_tx_i;
input         start_i;
//--------------------------------------------------------------------
// Output
//--------------------------------------------------------------------
output [31:0] LiteFast_data_tx_o;
output [3:0]  LiteFast_k_tx_o;
//--------------------------------------------------------------------
// Nets
//--------------------------------------------------------------------
wire          clk_i;
wire   [0:0]  COREFIFO_C0_0_Q0to0;
wire   [1:1]  COREFIFO_C0_0_Q1to1;
wire   [2:2]  COREFIFO_C0_0_Q2to2;
wire   [31:0] Counter_0_data_out_o;
wire          DATA;
wire          DATA_0;
wire          DATA_1;
wire          LiteFast_C2_0_req_usr_data_tx_o;
wire   [31:0] LiteFast_data_tx_o_net_0;
wire   [3:0]  LiteFast_k_tx_o_net_0;
wire          local_rece_rdy_tx_i;
wire   [7:0]  local_token_tx_i;
wire   [7:0]  remote_token_tx_i;
wire          start_i;
wire          synchronizer_0_user_data_val_tx_o;
wire          WCLOCK;
wire   [31:0] LiteFast_data_tx_o_net_1;
wire   [3:0]  LiteFast_k_tx_o_net_1;
wire   [2:0]  DATA_net_0;
wire   [2:0]  Q_net_0;
//--------------------------------------------------------------------
// TiedOff Nets
//--------------------------------------------------------------------
wire          VCC_net;
wire   [7:0]  min_remote_token_tx_i_const_net_0;
wire          GND_net;
//--------------------------------------------------------------------
// Constant assignments
//--------------------------------------------------------------------
assign VCC_net                           = 1'b1;
assign min_remote_token_tx_i_const_net_0 = 8'h08;
assign GND_net                           = 1'b0;
//--------------------------------------------------------------------
// Top level output port assignments
//--------------------------------------------------------------------
assign LiteFast_data_tx_o_net_1 = LiteFast_data_tx_o_net_0;
assign LiteFast_data_tx_o[31:0] = LiteFast_data_tx_o_net_1;
assign LiteFast_k_tx_o_net_1    = LiteFast_k_tx_o_net_0;
assign LiteFast_k_tx_o[3:0]     = LiteFast_k_tx_o_net_1;
//--------------------------------------------------------------------
// Slices assignments
//--------------------------------------------------------------------
assign COREFIFO_C0_0_Q0to0[0] = Q_net_0[0:0];
assign COREFIFO_C0_0_Q1to1[1] = Q_net_0[1:1];
assign COREFIFO_C0_0_Q2to2[2] = Q_net_0[2:2];
//--------------------------------------------------------------------
// Concatenation assignments
//--------------------------------------------------------------------
assign DATA_net_0 = { DATA_0 , DATA_1 , DATA };
//--------------------------------------------------------------------
// Component instances
//--------------------------------------------------------------------
//--------COREFIFO_C0
COREFIFO_C0 COREFIFO_C0_0(
        // Inputs
        .WCLOCK   ( WCLOCK ),
        .RCLOCK   ( clk_i ),
        .WRESET_N ( start_i ),
        .RRESET_N ( start_i ),
        .DATA     ( DATA_net_0 ),
        .WE       ( VCC_net ),
        .RE       ( VCC_net ),
        // Outputs
        .Q        ( Q_net_0 ),
        .FULL     (  ),
        .EMPTY    (  ) 
        );

//--------Counter
Counter Counter_0(
        // Inputs
        .clk_i           ( clk_i ),
        .reset_n_i       ( start_i ),
        .start_i         ( COREFIFO_C0_0_Q0to0 ),
        .payload_error_i ( COREFIFO_C0_0_Q2to2 ),
        // Outputs
        .data_out_o      ( Counter_0_data_out_o ) 
        );

//--------LiteFast_C2
LiteFast_C2 LiteFast_C2_0(
        // Inputs
        .clk_tx_i              ( clk_i ),
        .rst_n_tx_i            ( start_i ),
        .min_remote_token_tx_i ( min_remote_token_tx_i_const_net_0 ),
        .simplex_en_i          ( GND_net ),
        .local_rece_rdy_tx_i   ( local_rece_rdy_tx_i ),
        .usr_data_rdy_tx_i     ( VCC_net ),
        .usr_data_tx_i         ( Counter_0_data_out_o ),
        .usr_data_val_tx_i     ( synchronizer_0_user_data_val_tx_o ),
        .local_token_tx_i      ( local_token_tx_i ),
        .remote_token_tx_i     ( remote_token_tx_i ),
        .crc_err_en_tx_i       ( COREFIFO_C0_0_Q1to1 ),
        // Outputs
        .req_usr_data_tx_o     ( LiteFast_C2_0_req_usr_data_tx_o ),
        .LiteFast_k_tx_o       ( LiteFast_k_tx_o_net_0 ),
        .LiteFast_data_tx_o    ( LiteFast_data_tx_o_net_0 ) 
        );

//--------synchronizer
synchronizer synchronizer_0(
        // Inputs
        .clk_i              ( clk_i ),
        .req_user_data_tx_i ( LiteFast_C2_0_req_usr_data_tx_o ),
        // Outputs
        .user_data_val_tx_o ( synchronizer_0_user_data_val_tx_o ) 
        );


endmodule
