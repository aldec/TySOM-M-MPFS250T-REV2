//////////////////////////////////////////////////////////////////////
// Created by SmartDesign Tue Jan 14 12:09:23 2025
// Version: 2022.2 2022.2.0.10
//////////////////////////////////////////////////////////////////////

`timescale 1ns / 100ps

// LiteFast_receiver
module LiteFast_receiver(
    // Inputs
    DATA,
    DATA_0,
    RCLOCK,
    RESET,
    WCLOCK,
    WCLOCK_0,
    lane_data_rx_i,
    lane_k_rx_i,
    // Outputs
    Local_Token_o,
    Remote_Token_o,
    crc_error_o,
    data_rx_o,
    data_tx_o,
    error_o,
    lane_aligned_rx_o,
    lock_o,
    rx_val_o
);

//--------------------------------------------------------------------
// Input
//--------------------------------------------------------------------
input          DATA;
input          DATA_0;
input          RCLOCK;
input          RESET;
input          WCLOCK;
input          WCLOCK_0;
input  [31:0]  lane_data_rx_i;
input  [3:0]   lane_k_rx_i;
//--------------------------------------------------------------------
// Output
//--------------------------------------------------------------------
output [7:0]   Local_Token_o;
output [7:0]   Remote_Token_o;
output         crc_error_o;
output [15:0]  data_rx_o;
output [31:16] data_tx_o;
output         error_o;
output         lane_aligned_rx_o;
output         lock_o;
output         rx_val_o;
//--------------------------------------------------------------------
// Nets
//--------------------------------------------------------------------
wire   [0:0]   COREFIFO_C2_0_Q0to0;
wire   [1:1]   COREFIFO_C2_0_Q1to1;
wire           Count_Checker_0_crc_error_o;
wire   [15:0]  Count_Checker_0_data_rx_o15to0;
wire   [15:0]  Count_Checker_0_data_tx_o15to0;
wire           Count_Checker_0_error_o;
wire           Count_Checker_0_lock_o;
wire           Count_Checker_0_rx_val_o;
wire   [32:32] crc_error_o_net_0;
wire           DATA;
wire           DATA_0;
wire   [15:0]  data_rx_o_net_0;
wire   [31:16] data_tx_o_net_0;
wire   [33:33] error_o_net_0;
wire           lane_aligned_rx_o_net_0;
wire   [31:0]  lane_data_rx_i;
wire   [3:0]   lane_k_rx_i;
wire           LiteFast_C3_0_crc_err_rx_o;
wire   [7:0]   LiteFast_C3_0_remote_token_rx_o;
wire   [31:0]  LiteFast_C3_0_usr_data_rx_o;
wire           LiteFast_C3_0_usr_data_val_rx_o;
wire   [7:0]   Local_Token_o_net_0;
wire   [34:34] lock_o_net_0;
wire           RCLOCK;
wire   [7:0]   Remote_Token_o_net_0;
wire           RESET;
wire   [35:35] rx_val_o_net_0;
wire           WCLOCK;
wire           WCLOCK_0;
wire           crc_error_o_net_1;
wire           error_o_net_1;
wire           lane_aligned_rx_o_net_1;
wire           lock_o_net_1;
wire           rx_val_o_net_1;
wire   [7:0]   Local_Token_o_net_1;
wire   [7:0]   Remote_Token_o_net_1;
wire   [15:0]  data_rx_o_net_1;
wire   [31:16] data_tx_o_net_1;
wire   [31:16] data_tx_o_slice_0;
wire   [31:16] data_rx_o_slice_0;
wire   [1:0]   DATA_net_0;
wire   [1:0]   Q_net_0;
wire   [35:0]  DATA_net_1;
wire   [35:0]  Q_net_1;
wire   [31:0]  data_tx_o_net_2;
wire   [31:0]  data_rx_o_net_2;
//--------------------------------------------------------------------
// TiedOff Nets
//--------------------------------------------------------------------
wire   [7:0]   DATA_const_net_0;
wire           VCC_net;
//--------------------------------------------------------------------
// Constant assignments
//--------------------------------------------------------------------
assign DATA_const_net_0 = 8'h3F;
assign VCC_net          = 1'b1;
//--------------------------------------------------------------------
// Top level output port assignments
//--------------------------------------------------------------------
assign crc_error_o_net_1       = crc_error_o_net_0[32];
assign crc_error_o             = crc_error_o_net_1;
assign error_o_net_1           = error_o_net_0[33];
assign error_o                 = error_o_net_1;
assign lane_aligned_rx_o_net_1 = lane_aligned_rx_o_net_0;
assign lane_aligned_rx_o       = lane_aligned_rx_o_net_1;
assign lock_o_net_1            = lock_o_net_0[34];
assign lock_o                  = lock_o_net_1;
assign rx_val_o_net_1          = rx_val_o_net_0[35];
assign rx_val_o                = rx_val_o_net_1;
assign Local_Token_o_net_1     = Local_Token_o_net_0;
assign Local_Token_o[7:0]      = Local_Token_o_net_1;
assign Remote_Token_o_net_1    = Remote_Token_o_net_0;
assign Remote_Token_o[7:0]     = Remote_Token_o_net_1;
assign data_rx_o_net_1         = data_rx_o_net_0;
assign data_rx_o[15:0]         = data_rx_o_net_1;
assign data_tx_o_net_1         = data_tx_o_net_0;
assign data_tx_o[31:16]        = data_tx_o_net_1;
//--------------------------------------------------------------------
// Slices assignments
//--------------------------------------------------------------------
assign COREFIFO_C2_0_Q0to0[0]         = Q_net_0[0:0];
assign COREFIFO_C2_0_Q1to1[1]         = Q_net_0[1:1];
assign Count_Checker_0_data_rx_o15to0 = data_rx_o_net_2[15:0];
assign Count_Checker_0_data_tx_o15to0 = data_tx_o_net_2[15:0];
assign crc_error_o_net_0[32]          = Q_net_1[32:32];
assign data_rx_o_net_0                = Q_net_1[15:0];
assign data_tx_o_net_0                = Q_net_1[31:16];
assign error_o_net_0[33]              = Q_net_1[33:33];
assign lock_o_net_0[34]               = Q_net_1[34:34];
assign rx_val_o_net_0[35]             = Q_net_1[35:35];
assign data_tx_o_slice_0              = data_tx_o_net_2[31:16];
assign data_rx_o_slice_0              = data_rx_o_net_2[31:16];
//--------------------------------------------------------------------
// Concatenation assignments
//--------------------------------------------------------------------
assign DATA_net_0 = { DATA_0 , DATA };
assign DATA_net_1 = { Count_Checker_0_rx_val_o , Count_Checker_0_lock_o , Count_Checker_0_error_o , Count_Checker_0_crc_error_o , Count_Checker_0_data_rx_o15to0 , Count_Checker_0_data_tx_o15to0 };
//--------------------------------------------------------------------
// Component instances
//--------------------------------------------------------------------
//--------COREFIFO_C1
COREFIFO_C1 COREFIFO_C1_0(
        // Inputs
        .WCLOCK   ( WCLOCK ),
        .RCLOCK   ( RCLOCK ),
        .WRESET_N ( RESET ),
        .RRESET_N ( RESET ),
        .DATA     ( DATA_const_net_0 ),
        .WE       ( VCC_net ),
        .RE       ( VCC_net ),
        // Outputs
        .Q        ( Local_Token_o_net_0 ),
        .FULL     (  ),
        .EMPTY    (  ) 
        );

//--------COREFIFO_C2
COREFIFO_C2 COREFIFO_C2_0(
        // Inputs
        .WCLOCK   ( WCLOCK_0 ),
        .RCLOCK   ( WCLOCK ),
        .WRESET_N ( RESET ),
        .RRESET_N ( RESET ),
        .DATA     ( DATA_net_0 ),
        .WE       ( VCC_net ),
        .RE       ( VCC_net ),
        // Outputs
        .Q        ( Q_net_0 ),
        .FULL     (  ),
        .EMPTY    (  ) 
        );

//--------COREFIFO_C3
COREFIFO_C3 COREFIFO_C3_0(
        // Inputs
        .WCLOCK   ( WCLOCK ),
        .RCLOCK   ( WCLOCK_0 ),
        .WRESET_N ( RESET ),
        .RRESET_N ( RESET ),
        .DATA     ( DATA_net_1 ),
        .WE       ( VCC_net ),
        .RE       ( VCC_net ),
        // Outputs
        .Q        ( Q_net_1 ),
        .FULL     (  ),
        .EMPTY    (  ) 
        );

//--------COREFIFO_C4
COREFIFO_C4 COREFIFO_C4_0(
        // Inputs
        .WCLOCK   ( WCLOCK ),
        .RCLOCK   ( RCLOCK ),
        .WRESET_N ( RESET ),
        .RRESET_N ( RESET ),
        .DATA     ( LiteFast_C3_0_remote_token_rx_o ),
        .WE       ( VCC_net ),
        .RE       ( VCC_net ),
        // Outputs
        .Q        ( Remote_Token_o_net_0 ),
        .FULL     (  ),
        .EMPTY    (  ) 
        );

//--------Count_Checker
Count_Checker Count_Checker_0(
        // Inputs
        .clk_i              ( WCLOCK ),
        .reset_n_i          ( RESET ),
        .data_i             ( LiteFast_C3_0_usr_data_rx_o ),
        .start_i            ( COREFIFO_C2_0_Q0to0 ),
        .rx_val_in          ( RESET ),
        .usr_data_valid_i   ( LiteFast_C3_0_usr_data_val_rx_o ),
        .clear_i            ( COREFIFO_C2_0_Q1to1 ),
        .crc_error_result_i ( LiteFast_C3_0_crc_err_rx_o ),
        // Outputs
        .rx_val_o           ( Count_Checker_0_rx_val_o ),
        .lock_o             ( Count_Checker_0_lock_o ),
        .error_o            ( Count_Checker_0_error_o ),
        .crc_error_o        ( Count_Checker_0_crc_error_o ),
        .data_tx_o          ( data_tx_o_net_2 ),
        .data_rx_o          ( data_rx_o_net_2 ) 
        );

//--------LiteFast_C3
LiteFast_C3 LiteFast_C3_0(
        // Inputs
        .clk_rx_i           ( WCLOCK ),
        .rst_n_rx_i         ( RESET ),
        .serdes_rx_val_i    ( RESET ),
        .word_aligned_rx_i  ( VCC_net ),
        .lane_k_rx_i        ( lane_k_rx_i ),
        .lane_data_rx_i     ( lane_data_rx_i ),
        // Outputs
        .block_aligned_rx_o (  ),
        .lane_aligned_rx_o  ( lane_aligned_rx_o_net_0 ),
        .remote_token_rx_o  ( LiteFast_C3_0_remote_token_rx_o ),
        .crc_err_rx_o       ( LiteFast_C3_0_crc_err_rx_o ),
        .usr_data_val_rx_o  ( LiteFast_C3_0_usr_data_val_rx_o ),
        .usr_data_rx_o      ( LiteFast_C3_0_usr_data_rx_o ) 
        );


endmodule
