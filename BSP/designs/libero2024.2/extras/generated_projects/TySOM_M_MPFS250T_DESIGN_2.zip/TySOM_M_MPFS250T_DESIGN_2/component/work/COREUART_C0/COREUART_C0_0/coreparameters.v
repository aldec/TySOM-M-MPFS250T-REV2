//--------------------------------------------------------------------
// Created by Microsemi SmartDesign Tue Jan 14 12:09:33 2025
// Parameters for COREUART
//--------------------------------------------------------------------


parameter BAUD_VAL_FRCTN_EN = 1;
parameter FAMILY = 27;
parameter HDL_license = "U";
parameter RX_FIFO = 0;
parameter RX_LEGACY_MODE = 0;
parameter testbench = "User";
parameter TX_FIFO = 0;
parameter USE_SOFT_FIFO = 0;
