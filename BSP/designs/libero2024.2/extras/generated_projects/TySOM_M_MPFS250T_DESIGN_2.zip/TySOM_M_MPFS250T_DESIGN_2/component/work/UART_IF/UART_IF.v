//////////////////////////////////////////////////////////////////////
// Created by SmartDesign Tue Jan 14 12:09:41 2025
// Version: 2022.2 2022.2.0.10
//////////////////////////////////////////////////////////////////////

`timescale 1ns / 100ps

// UART_IF
module UART_IF(
    // Inputs
    CLK_125,
    RESET,
    RX,
    crc_error_i,
    payload_err_i,
    rx_error_i,
    rx_lock_i,
    rx_val_i,
    rx_words_in,
    start_test,
    tx_words_in,
    // Outputs
    TX,
    UART_IF_CLK,
    clear_o,
    crc_err_o,
    payload_err_o,
    start_o
);

//--------------------------------------------------------------------
// Input
//--------------------------------------------------------------------
input         CLK_125;
input         RESET;
input         RX;
input         crc_error_i;
input         payload_err_i;
input         rx_error_i;
input         rx_lock_i;
input         rx_val_i;
input  [15:0] rx_words_in;
input         start_test;
input  [15:0] tx_words_in;
//--------------------------------------------------------------------
// Output
//--------------------------------------------------------------------
output        TX;
output        UART_IF_CLK;
output        clear_o;
output        crc_err_o;
output        payload_err_o;
output        start_o;
//--------------------------------------------------------------------
// Nets
//--------------------------------------------------------------------
wire          clear_o_net_0;
wire   [7:0]  COREUART_C0_0_DATA_OUT;
wire          COREUART_C0_0_RXRDY;
wire          COREUART_C0_0_TXRDY;
wire          crc_err_o_net_0;
wire          crc_error_i;
wire   [7:0]  FabUART_0_uart_data_out;
wire          FabUART_0_uart_oen;
wire          FabUART_0_uart_wen;
wire          payload_err_i;
wire          payload_err_o_net_0;
wire          RESET;
wire          Reset_Synchronizer_0_reset_o;
wire          RX;
wire          rx_error_i;
wire          rx_lock_i;
wire          rx_val_i;
wire   [15:0] rx_words_in;
wire          start_o_net_0;
wire          start_test;
wire          TX_net_0;
wire   [15:0] tx_words_in;
wire          CLK_125;
wire          TX_net_1;
wire          UART_IF_CLK_net_0;
wire          clear_o_net_1;
wire          crc_err_o_net_1;
wire          payload_err_o_net_1;
wire          start_o_net_1;
//--------------------------------------------------------------------
// TiedOff Nets
//--------------------------------------------------------------------
wire   [12:0] BAUD_VAL_const_net_0;
wire          VCC_net;
wire          GND_net;
wire   [2:0]  BAUD_VAL_FRACTION_const_net_0;
//--------------------------------------------------------------------
// Constant assignments
//--------------------------------------------------------------------
assign BAUD_VAL_const_net_0          = 13'h032C;
assign VCC_net                       = 1'b1;
assign GND_net                       = 1'b0;
assign BAUD_VAL_FRACTION_const_net_0 = 3'h6;
//--------------------------------------------------------------------
// Top level output port assignments
//--------------------------------------------------------------------
assign TX_net_1            = TX_net_0;
assign TX                  = TX_net_1;
assign UART_IF_CLK_net_0   = CLK_125;
assign UART_IF_CLK         = UART_IF_CLK_net_0;
assign clear_o_net_1       = clear_o_net_0;
assign clear_o             = clear_o_net_1;
assign crc_err_o_net_1     = crc_err_o_net_0;
assign crc_err_o           = crc_err_o_net_1;
assign payload_err_o_net_1 = payload_err_o_net_0;
assign payload_err_o       = payload_err_o_net_1;
assign start_o_net_1       = start_o_net_0;
assign start_o             = start_o_net_1;
//--------------------------------------------------------------------
// Component instances
//--------------------------------------------------------------------
//--------COREUART_C0
COREUART_C0 COREUART_C0_0(
        // Inputs
        .BAUD_VAL          ( BAUD_VAL_const_net_0 ),
        .BIT8              ( VCC_net ),
        .CLK               ( CLK_125 ),
        .CSN               ( GND_net ),
        .DATA_IN           ( FabUART_0_uart_data_out ),
        .ODD_N_EVEN        ( GND_net ),
        .OEN               ( FabUART_0_uart_oen ),
        .PARITY_EN         ( GND_net ),
        .RESET_N           ( Reset_Synchronizer_0_reset_o ),
        .RX                ( RX ),
        .WEN               ( FabUART_0_uart_wen ),
        .BAUD_VAL_FRACTION ( BAUD_VAL_FRACTION_const_net_0 ),
        // Outputs
        .DATA_OUT          ( COREUART_C0_0_DATA_OUT ),
        .OVERFLOW          (  ),
        .PARITY_ERR        (  ),
        .RXRDY             ( COREUART_C0_0_RXRDY ),
        .TX                ( TX_net_0 ),
        .TXRDY             ( COREUART_C0_0_TXRDY ),
        .FRAMING_ERR       (  ) 
        );

//--------FabUART
FabUART #( 
        .INIT            ( 0 ),
        .UART_TX1        ( 3 ),
        .UART_TX2        ( 5 ),
        .UART_TX3        ( 19 ),
        .UART_TX4        ( 21 ),
        .UART_TX5        ( 23 ),
        .UART_TX_CMD     ( 1 ),
        .UART_TX_CNT     ( 6 ),
        .UART_TX_CNT1    ( 8 ),
        .UART_TX_CNT2    ( 10 ),
        .UART_TX_SCAN    ( 12 ),
        .UART_TX_SCAN1   ( 14 ),
        .UART_TX_SCAN2   ( 16 ),
        .UART_WAIT0      ( 2 ),
        .UART_WAIT1      ( 4 ),
        .UART_WAIT1_EXT1 ( 18 ),
        .UART_WAIT1_EXT2 ( 20 ),
        .UART_WAIT1_EXT3 ( 22 ),
        .UART_WAIT2      ( 7 ),
        .UART_WAIT3      ( 9 ),
        .UART_WAIT4      ( 11 ),
        .UART_WAIT5      ( 13 ),
        .UART_WAIT6      ( 15 ),
        .UART_WAIT7      ( 17 ) )
FabUART_0(
        // Inputs
        .clk           ( CLK_125 ),
        .reset         ( Reset_Synchronizer_0_reset_o ),
        .uart_txrdy    ( COREUART_C0_0_TXRDY ),
        .uart_rxrdy    ( COREUART_C0_0_RXRDY ),
        .rx_val_i      ( rx_val_i ),
        .rx_lock_i     ( rx_lock_i ),
        .rx_error_i    ( rx_error_i ),
        .crc_error_i   ( crc_error_i ),
        .payload_err_i ( payload_err_i ),
        .uart_data_in  ( COREUART_C0_0_DATA_OUT ),
        .tx_words_in   ( tx_words_in ),
        .rx_words_in   ( rx_words_in ),
        .start_test    ( start_test ),
        // Outputs
        .uart_wen      ( FabUART_0_uart_wen ),
        .uart_oen      ( FabUART_0_uart_oen ),
        .start_o       ( start_o_net_0 ),
        .clear_o       ( clear_o_net_0 ),
        .payload_err_o ( payload_err_o_net_0 ),
        .crc_err_o     ( crc_err_o_net_0 ),
        .connect_o     (  ),
        .uart_data_out ( FabUART_0_uart_data_out ) 
        );

//--------Reset_Synchronizer
Reset_Synchronizer Reset_Synchronizer_0(
        // Inputs
        .clk_i     ( CLK_125 ),
        .reset_n_i ( RESET ),
        .lock_i    ( RESET ),
        // Outputs
        .reset_o   ( Reset_Synchronizer_0_reset_o ) 
        );


endmodule
