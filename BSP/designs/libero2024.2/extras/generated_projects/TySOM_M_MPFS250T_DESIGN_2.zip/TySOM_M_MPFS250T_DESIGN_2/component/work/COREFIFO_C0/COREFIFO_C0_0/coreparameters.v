//--------------------------------------------------------------------
// Created by Microsemi SmartDesign Tue Jan 14 12:09:25 2025
// Parameters for COREFIFO
//--------------------------------------------------------------------


parameter AE_STATIC_EN = 0;
parameter AEVAL = 4;
parameter AF_STATIC_EN = 0;
parameter AFVAL = 60;
parameter CTRL_TYPE = 3;
parameter DIE_SIZE = 20;
parameter ECC = 0;
parameter ESTOP = 1;
parameter FAMILY = 27;
parameter FSTOP = 1;
parameter FWFT = 0;
parameter NUM_STAGES = 2;
parameter OVERFLOW_EN = 0;
parameter PIPE = 2;
parameter PREFETCH = 0;
parameter RAM_OPT = 0;
parameter RDCNT_EN = 0;
parameter RDEPTH = 64;
parameter RE_POLARITY = 0;
parameter READ_DVALID = 0;
parameter RWIDTH = 3;
parameter SYNC = 0;
parameter SYNC_RESET = 0;
parameter testbench = "User";
parameter UNDERFLOW_EN = 0;
parameter WDEPTH = 64;
parameter WE_POLARITY = 0;
parameter WRCNT_EN = 0;
parameter WRITE_ACK = 0;
parameter WWIDTH = 3;
