set_component PF_TX_PLL_C0_PF_TX_PLL_C0_0_PF_TX_PLL
# Microchip Technology Inc.
# Date: 2025-Apr-17 10:49:32
#

create_clock -period 8 [ get_pins { txpll_isnt_0/REF_CLK_P } ]
create_clock -period 8 [ get_pins { txpll_isnt_0/DIV_CLK } ]
