//////////////////////////////////////////////////////////////////////
// Created by SmartDesign Fri Apr 18 09:26:05 2025
// Version: 2024.2 2024.2.0.13
//////////////////////////////////////////////////////////////////////

`timescale 1ns / 100ps

// FIC_3_PERIPHERALS
module FIC_3_PERIPHERALS(
    // Inputs
    APB_MMASTER_in_paddr,
    APB_MMASTER_in_penable,
    APB_MMASTER_in_psel,
    APB_MMASTER_in_pwdata,
    APB_MMASTER_in_pwrite,
    PCLK,
    PLL0_SW_DRI_INTERRUPT,
    PLL0_SW_DRI_RDATA,
    PRESETN,
    PSTRB,
    Q0_LANE0_DRI_INTERRUPT,
    Q0_LANE0_DRI_RDATA,
    Q0_LANE1_DRI_INTERRUPT,
    Q0_LANE1_DRI_RDATA,
    Q0_LANE2_DRI_INTERRUPT,
    Q0_LANE2_DRI_RDATA,
    Q0_LANE3_DRI_INTERRUPT,
    Q0_LANE3_DRI_RDATA,
    // Outputs
    APB_MMASTER_in_prdata,
    APB_MMASTER_in_pready,
    APB_MMASTER_in_pslverr,
    PLL0_SW_DRI_CTRL,
    Q0_LANE0_DRI_CTRL,
    Q0_LANE0_DRI_DRI_ARST_N,
    Q0_LANE0_DRI_DRI_CLK,
    Q0_LANE0_DRI_DRI_WDATA,
    Q0_LANE1_DRI_CTRL,
    Q0_LANE2_DRI_CTRL,
    Q0_LANE3_DRI_CTRL,
    fabric_sd_emmc_demux_select_out
);

//--------------------------------------------------------------------
// Input
//--------------------------------------------------------------------
input  [31:0] APB_MMASTER_in_paddr;
input         APB_MMASTER_in_penable;
input         APB_MMASTER_in_psel;
input  [31:0] APB_MMASTER_in_pwdata;
input         APB_MMASTER_in_pwrite;
input         PCLK;
input         PLL0_SW_DRI_INTERRUPT;
input  [32:0] PLL0_SW_DRI_RDATA;
input         PRESETN;
input  [3:0]  PSTRB;
input         Q0_LANE0_DRI_INTERRUPT;
input  [32:0] Q0_LANE0_DRI_RDATA;
input         Q0_LANE1_DRI_INTERRUPT;
input  [32:0] Q0_LANE1_DRI_RDATA;
input         Q0_LANE2_DRI_INTERRUPT;
input  [32:0] Q0_LANE2_DRI_RDATA;
input         Q0_LANE3_DRI_INTERRUPT;
input  [32:0] Q0_LANE3_DRI_RDATA;
//--------------------------------------------------------------------
// Output
//--------------------------------------------------------------------
output [31:0] APB_MMASTER_in_prdata;
output        APB_MMASTER_in_pready;
output        APB_MMASTER_in_pslverr;
output [10:0] PLL0_SW_DRI_CTRL;
output [10:0] Q0_LANE0_DRI_CTRL;
output        Q0_LANE0_DRI_DRI_ARST_N;
output        Q0_LANE0_DRI_DRI_CLK;
output [32:0] Q0_LANE0_DRI_DRI_WDATA;
output [10:0] Q0_LANE1_DRI_CTRL;
output [10:0] Q0_LANE2_DRI_CTRL;
output [10:0] Q0_LANE3_DRI_CTRL;
output        fabric_sd_emmc_demux_select_out;
//--------------------------------------------------------------------
// Nets
//--------------------------------------------------------------------
wire   [31:0] APB_MMASTER_in_paddr;
wire          APB_MMASTER_in_penable;
wire   [31:0] APB_MMASTER_PRDATA;
wire          APB_MMASTER_PREADY;
wire          APB_MMASTER_in_psel;
wire          APB_MMASTER_PSLVERR;
wire   [31:0] APB_MMASTER_in_pwdata;
wire          APB_MMASTER_in_pwrite;
wire          fabric_sd_emmc_demux_select_out_net_0;
wire   [31:0] FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PADDR;
wire          FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PENABLE;
wire   [31:0] FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PRDATA;
wire          FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PREADY;
wire          FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PSELx;
wire          FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PSLVERR;
wire   [31:0] FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PWDATA;
wire          FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PWRITE;
wire          FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PENABLE;
wire   [31:0] FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PRDATA;
wire          FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PREADY;
wire          FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PSELx;
wire          FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PSLVERR;
wire   [31:0] FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PWDATA;
wire          FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PWRITE;
wire          PCLK;
wire          PLL0_SW_DRI_DRI_ARST_N;
wire          PLL0_SW_DRI_DRI_CLK;
wire   [10:0] PLL0_SW_DRI_DRI_CTRL;
wire          PLL0_SW_DRI_INTERRUPT;
wire   [32:0] PLL0_SW_DRI_RDATA;
wire   [32:0] PLL0_SW_DRI_DRI_WDATA;
wire          PRESETN;
wire   [3:0]  PSTRB;
wire   [10:0] Q0_LANE0_DRI_DRI_CTRL;
wire          Q0_LANE0_DRI_INTERRUPT;
wire   [32:0] Q0_LANE0_DRI_RDATA;
wire   [10:0] Q0_LANE1_DRI_DRI_CTRL;
wire          Q0_LANE1_DRI_INTERRUPT;
wire   [32:0] Q0_LANE1_DRI_RDATA;
wire   [10:0] Q0_LANE2_DRI_DRI_CTRL;
wire          Q0_LANE2_DRI_INTERRUPT;
wire   [32:0] Q0_LANE2_DRI_RDATA;
wire   [10:0] Q0_LANE3_DRI_DRI_CTRL;
wire          Q0_LANE3_DRI_INTERRUPT;
wire   [32:0] Q0_LANE3_DRI_RDATA;
wire          APB_MMASTER_PREADY_net_0;
wire          APB_MMASTER_PSLVERR_net_0;
wire          PLL0_SW_DRI_DRI_ARST_N_net_0;
wire          PLL0_SW_DRI_DRI_CLK_net_0;
wire          fabric_sd_emmc_demux_select_out_net_1;
wire   [31:0] APB_MMASTER_PRDATA_net_0;
wire   [10:0] PLL0_SW_DRI_DRI_CTRL_net_0;
wire   [10:0] Q0_LANE0_DRI_DRI_CTRL_net_0;
wire   [32:0] PLL0_SW_DRI_DRI_WDATA_net_0;
wire   [10:0] Q0_LANE1_DRI_DRI_CTRL_net_0;
wire   [10:0] Q0_LANE2_DRI_DRI_CTRL_net_0;
wire   [10:0] Q0_LANE3_DRI_DRI_CTRL_net_0;
//--------------------------------------------------------------------
// Bus Interface Nets Declarations - Unequal Pin Widths
//--------------------------------------------------------------------
wire   [31:0] FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PADDR;
wire   [28:0] FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PADDR_0;
wire   [28:0] FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PADDR_0_28to0;
//--------------------------------------------------------------------
// Top level output port assignments
//--------------------------------------------------------------------
assign APB_MMASTER_PREADY_net_0              = APB_MMASTER_PREADY;
assign APB_MMASTER_in_pready                 = APB_MMASTER_PREADY_net_0;
assign APB_MMASTER_PSLVERR_net_0             = APB_MMASTER_PSLVERR;
assign APB_MMASTER_in_pslverr                = APB_MMASTER_PSLVERR_net_0;
assign PLL0_SW_DRI_DRI_ARST_N_net_0          = PLL0_SW_DRI_DRI_ARST_N;
assign Q0_LANE0_DRI_DRI_ARST_N               = PLL0_SW_DRI_DRI_ARST_N_net_0;
assign PLL0_SW_DRI_DRI_CLK_net_0             = PLL0_SW_DRI_DRI_CLK;
assign Q0_LANE0_DRI_DRI_CLK                  = PLL0_SW_DRI_DRI_CLK_net_0;
assign fabric_sd_emmc_demux_select_out_net_1 = fabric_sd_emmc_demux_select_out_net_0;
assign fabric_sd_emmc_demux_select_out       = fabric_sd_emmc_demux_select_out_net_1;
assign APB_MMASTER_PRDATA_net_0              = APB_MMASTER_PRDATA;
assign APB_MMASTER_in_prdata[31:0]           = APB_MMASTER_PRDATA_net_0;
assign PLL0_SW_DRI_DRI_CTRL_net_0            = PLL0_SW_DRI_DRI_CTRL;
assign PLL0_SW_DRI_CTRL[10:0]                = PLL0_SW_DRI_DRI_CTRL_net_0;
assign Q0_LANE0_DRI_DRI_CTRL_net_0           = Q0_LANE0_DRI_DRI_CTRL;
assign Q0_LANE0_DRI_CTRL[10:0]               = Q0_LANE0_DRI_DRI_CTRL_net_0;
assign PLL0_SW_DRI_DRI_WDATA_net_0           = PLL0_SW_DRI_DRI_WDATA;
assign Q0_LANE0_DRI_DRI_WDATA[32:0]          = PLL0_SW_DRI_DRI_WDATA_net_0;
assign Q0_LANE1_DRI_DRI_CTRL_net_0           = Q0_LANE1_DRI_DRI_CTRL;
assign Q0_LANE1_DRI_CTRL[10:0]               = Q0_LANE1_DRI_DRI_CTRL_net_0;
assign Q0_LANE2_DRI_DRI_CTRL_net_0           = Q0_LANE2_DRI_DRI_CTRL;
assign Q0_LANE2_DRI_CTRL[10:0]               = Q0_LANE2_DRI_DRI_CTRL_net_0;
assign Q0_LANE3_DRI_DRI_CTRL_net_0           = Q0_LANE3_DRI_DRI_CTRL;
assign Q0_LANE3_DRI_CTRL[10:0]               = Q0_LANE3_DRI_DRI_CTRL_net_0;
//--------------------------------------------------------------------
// Bus Interface Nets Assignments - Unequal Pin Widths
//--------------------------------------------------------------------
assign FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PADDR_0 = { FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PADDR_0_28to0 };
assign FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PADDR_0_28to0 = FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PADDR[28:0];

//--------------------------------------------------------------------
// Component instances
//--------------------------------------------------------------------
//--------fabric_sd_emmc_demux_select
fabric_sd_emmc_demux_select fabric_sd_emmc_demux_select_0(
        // Inputs
        .pclk                            ( PCLK ),
        .presetn                         ( PRESETN ),
        .penable                         ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PENABLE ),
        .psel                            ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PSELx ),
        .paddr                           ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PADDR ),
        .pwrite                          ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PWRITE ),
        .pwdata                          ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PWDATA ),
        // Outputs
        .prdata                          ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PRDATA ),
        .pready                          ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PREADY ),
        .pslverr                         ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PSLVERR ),
        .fabric_sd_emmc_demux_select_out ( fabric_sd_emmc_demux_select_out_net_0 ) 
        );

//--------FIC_3_ADDRESS_GENERATION
FIC_3_ADDRESS_GENERATION FIC_3_ADDRESS_GENERATION_1(
        // Inputs
        .APB_MMASTER_in_penable ( APB_MMASTER_in_penable ),
        .APB_MMASTER_in_psel    ( APB_MMASTER_in_psel ),
        .APB_MMASTER_in_pwrite  ( APB_MMASTER_in_pwrite ),
        .APBmslave15_PREADYS15  ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PREADY ),
        .APBmslave15_PSLVERRS15 ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PSLVERR ),
        .APBmslave16_PREADYS16  ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PREADY ),
        .APBmslave16_PSLVERRS16 ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PSLVERR ),
        .APB_MMASTER_in_paddr   ( APB_MMASTER_in_paddr ),
        .APB_MMASTER_in_pwdata  ( APB_MMASTER_in_pwdata ),
        .APBmslave15_PRDATAS15  ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PRDATA ),
        .APBmslave16_PRDATAS16  ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PRDATA ),
        // Outputs
        .APB_MMASTER_in_pready  ( APB_MMASTER_PREADY ),
        .APB_MMASTER_in_pslverr ( APB_MMASTER_PSLVERR ),
        .APBmslave15_PENABLES   ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PENABLE ),
        .APBmslave15_PSELS15    ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PSELx ),
        .APBmslave15_PWRITES    ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PWRITE ),
        .APBmslave16_PENABLES   ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PENABLE ),
        .APBmslave16_PSELS16    ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PSELx ),
        .APBmslave16_PWRITES    ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PWRITE ),
        .APB_MMASTER_in_prdata  ( APB_MMASTER_PRDATA ),
        .APBmslave15_PADDRS     ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PADDR ),
        .APBmslave15_PWDATAS    ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x4FFF_FFxx_PWDATA ),
        .APBmslave16_PADDRS     ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PADDR ),
        .APBmslave16_PWDATAS    ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PWDATA ) 
        );

//--------RECONFIGURATION_INTERFACE
RECONFIGURATION_INTERFACE RECONFIGURATION_INTERFACE_0(
        // Inputs
        .PCLK                   ( PCLK ),
        .PSTRB                  ( PSTRB ),
        .PRESETN                ( PRESETN ),
        .Q0_LANE0_DRI_RDATA     ( Q0_LANE0_DRI_RDATA ),
        .Q0_LANE0_DRI_INTERRUPT ( Q0_LANE0_DRI_INTERRUPT ),
        .Q0_LANE1_DRI_RDATA     ( Q0_LANE1_DRI_RDATA ),
        .Q0_LANE1_DRI_INTERRUPT ( Q0_LANE1_DRI_INTERRUPT ),
        .Q0_LANE2_DRI_RDATA     ( Q0_LANE2_DRI_RDATA ),
        .Q0_LANE2_DRI_INTERRUPT ( Q0_LANE2_DRI_INTERRUPT ),
        .Q0_LANE3_DRI_RDATA     ( Q0_LANE3_DRI_RDATA ),
        .Q0_LANE3_DRI_INTERRUPT ( Q0_LANE3_DRI_INTERRUPT ),
        .PLL0_SW_DRI_RDATA      ( PLL0_SW_DRI_RDATA ),
        .PLL0_SW_DRI_INTERRUPT  ( PLL0_SW_DRI_INTERRUPT ),
        .PSEL                   ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PSELx ),
        .PENABLE                ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PENABLE ),
        .PWRITE                 ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PWRITE ),
        .PADDR                  ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PADDR_0 ),
        .PWDATA                 ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PWDATA ),
        // Outputs
        .PINTERRUPT             (  ),
        .PTIMEOUT               (  ),
        .BUSERROR               (  ),
        .DRI_CLK                ( PLL0_SW_DRI_DRI_CLK ),
        .DRI_WDATA              ( PLL0_SW_DRI_DRI_WDATA ),
        .DRI_ARST_N             ( PLL0_SW_DRI_DRI_ARST_N ),
        .Q0_LANE0_DRI_CTRL      ( Q0_LANE0_DRI_DRI_CTRL ),
        .Q0_LANE1_DRI_CTRL      ( Q0_LANE1_DRI_DRI_CTRL ),
        .Q0_LANE2_DRI_CTRL      ( Q0_LANE2_DRI_DRI_CTRL ),
        .Q0_LANE3_DRI_CTRL      ( Q0_LANE3_DRI_DRI_CTRL ),
        .PLL0_SW_DRI_CTRL       ( PLL0_SW_DRI_DRI_CTRL ),
        .PRDATA                 ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PRDATA ),
        .PREADY                 ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PREADY ),
        .PSLVERR                ( FIC_3_ADDRESS_GENERATION_1_FIC_3_0x43xx_xxxx_0x48xx_xxxx_PSLVERR ) 
        );


endmodule
