//////////////////////////////////////////////////////////////////////
// Created by SmartDesign Fri Apr 18 09:26:00 2025
// Version: 2024.2 2024.2.0.13
//////////////////////////////////////////////////////////////////////

`timescale 1ns / 100ps

// FIC_3_ADDRESS_GENERATION
module FIC_3_ADDRESS_GENERATION(
    // Inputs
    APB_MMASTER_in_paddr,
    APB_MMASTER_in_penable,
    APB_MMASTER_in_psel,
    APB_MMASTER_in_pwdata,
    APB_MMASTER_in_pwrite,
    APBmslave15_PRDATAS15,
    APBmslave15_PREADYS15,
    APBmslave15_PSLVERRS15,
    APBmslave16_PRDATAS16,
    APBmslave16_PREADYS16,
    APBmslave16_PSLVERRS16,
    // Outputs
    APB_MMASTER_in_prdata,
    APB_MMASTER_in_pready,
    APB_MMASTER_in_pslverr,
    APBmslave15_PADDRS,
    APBmslave15_PENABLES,
    APBmslave15_PSELS15,
    APBmslave15_PWDATAS,
    APBmslave15_PWRITES,
    APBmslave16_PADDRS,
    APBmslave16_PENABLES,
    APBmslave16_PSELS16,
    APBmslave16_PWDATAS,
    APBmslave16_PWRITES
);

//--------------------------------------------------------------------
// Input
//--------------------------------------------------------------------
input  [31:0] APB_MMASTER_in_paddr;
input         APB_MMASTER_in_penable;
input         APB_MMASTER_in_psel;
input  [31:0] APB_MMASTER_in_pwdata;
input         APB_MMASTER_in_pwrite;
input  [31:0] APBmslave15_PRDATAS15;
input         APBmslave15_PREADYS15;
input         APBmslave15_PSLVERRS15;
input  [31:0] APBmslave16_PRDATAS16;
input         APBmslave16_PREADYS16;
input         APBmslave16_PSLVERRS16;
//--------------------------------------------------------------------
// Output
//--------------------------------------------------------------------
output [31:0] APB_MMASTER_in_prdata;
output        APB_MMASTER_in_pready;
output        APB_MMASTER_in_pslverr;
output [31:0] APBmslave15_PADDRS;
output        APBmslave15_PENABLES;
output        APBmslave15_PSELS15;
output [31:0] APBmslave15_PWDATAS;
output        APBmslave15_PWRITES;
output [31:0] APBmslave16_PADDRS;
output        APBmslave16_PENABLES;
output        APBmslave16_PSELS16;
output [31:0] APBmslave16_PWDATAS;
output        APBmslave16_PWRITES;
//--------------------------------------------------------------------
// Nets
//--------------------------------------------------------------------
wire   [31:0] APB_ARBITER_0_APB_MASTER_low_PADDR;
wire          APB_ARBITER_0_APB_MASTER_low_PENABLE;
wire   [31:0] APB_ARBITER_0_APB_MASTER_low_PRDATA;
wire          APB_ARBITER_0_APB_MASTER_low_PREADY;
wire          APB_ARBITER_0_APB_MASTER_low_PSELx;
wire          APB_ARBITER_0_APB_MASTER_low_PSLVERR;
wire   [31:0] APB_ARBITER_0_APB_MASTER_low_PWDATA;
wire          APB_ARBITER_0_APB_MASTER_low_PWRITE;
wire   [31:0] APB_MMASTER_in_paddr;
wire          APB_MMASTER_in_penable;
wire   [31:0] APB_MMASTER_PRDATA;
wire          APB_MMASTER_PREADY;
wire          APB_MMASTER_in_psel;
wire          APB_MMASTER_PSLVERR;
wire   [31:0] APB_MMASTER_in_pwdata;
wire          APB_MMASTER_in_pwrite;
wire   [31:0] APB_PASS_THROUGH_1_APB_INITIATOR_PADDR;
wire          APB_PASS_THROUGH_1_APB_INITIATOR_PENABLE;
wire   [31:0] APB_PASS_THROUGH_1_APB_INITIATOR_PRDATA;
wire          APB_PASS_THROUGH_1_APB_INITIATOR_PREADY;
wire          APB_PASS_THROUGH_1_APB_INITIATOR_PSELx;
wire          APB_PASS_THROUGH_1_APB_INITIATOR_PSLVERR;
wire   [31:0] APB_PASS_THROUGH_1_APB_INITIATOR_PWDATA;
wire          APB_PASS_THROUGH_1_APB_INITIATOR_PWRITE;
wire   [31:0] FIC_3_0x4FFF_FFxx_PADDR;
wire          FIC_3_0x4FFF_FFxx_PENABLE;
wire   [31:0] APBmslave15_PRDATAS15;
wire          APBmslave15_PREADYS15;
wire          FIC_3_0x4FFF_FFxx_PSELx;
wire          APBmslave15_PSLVERRS15;
wire   [31:0] FIC_3_0x4FFF_FFxx_PWDATA;
wire          FIC_3_0x4FFF_FFxx_PWRITE;
wire   [31:0] FIC_3_0x4xxx_xxxx_0_APBmslave15_PADDR;
wire          FIC_3_0x4xxx_xxxx_0_APBmslave15_PENABLE;
wire   [31:0] FIC_3_0x4xxx_xxxx_0_APBmslave15_PRDATA;
wire          FIC_3_0x4xxx_xxxx_0_APBmslave15_PREADY;
wire          FIC_3_0x4xxx_xxxx_0_APBmslave15_PSELx;
wire          FIC_3_0x4xxx_xxxx_0_APBmslave15_PSLVERR;
wire   [31:0] FIC_3_0x4xxx_xxxx_0_APBmslave15_PWDATA;
wire          FIC_3_0x4xxx_xxxx_0_APBmslave15_PWRITE;
wire   [31:0] APBmslave16_PRDATAS16;
wire          APBmslave16_PREADYS16;
wire          FIC_3_0x43xx_xxxx_0x48xx_xxxx_PSELx;
wire          APBmslave16_PSLVERRS16;
wire          APB_MMASTER_PREADY_net_0;
wire          APB_MMASTER_PSLVERR_net_0;
wire          FIC_3_0x4FFF_FFxx_PENABLE_net_0;
wire          FIC_3_0x4FFF_FFxx_PSELx_net_0;
wire          FIC_3_0x4FFF_FFxx_PWRITE_net_0;
wire          FIC_3_0x4xxx_xxxx_0_APBmslave15_PENABLE_net_0;
wire          FIC_3_0x43xx_xxxx_0x48xx_xxxx_PSELx_net_0;
wire          FIC_3_0x4xxx_xxxx_0_APBmslave15_PWRITE_net_0;
wire   [31:0] APB_MMASTER_PRDATA_net_0;
wire   [31:0] FIC_3_0x4FFF_FFxx_PADDR_net_0;
wire   [31:0] FIC_3_0x4FFF_FFxx_PWDATA_net_0;
wire   [31:0] FIC_3_0x4xxx_xxxx_0_APBmslave15_PADDR_net_0;
wire   [31:0] FIC_3_0x4xxx_xxxx_0_APBmslave15_PWDATA_net_0;
//--------------------------------------------------------------------
// TiedOff Nets
//--------------------------------------------------------------------
wire   [31:0] out_high_prdata_const_net_0;
wire          VCC_net;
wire          GND_net;
//--------------------------------------------------------------------
// Constant assignments
//--------------------------------------------------------------------
assign out_high_prdata_const_net_0 = 32'h00000000;
assign VCC_net                     = 1'b1;
assign GND_net                     = 1'b0;
//--------------------------------------------------------------------
// Top level output port assignments
//--------------------------------------------------------------------
assign APB_MMASTER_PREADY_net_0                      = APB_MMASTER_PREADY;
assign APB_MMASTER_in_pready                         = APB_MMASTER_PREADY_net_0;
assign APB_MMASTER_PSLVERR_net_0                     = APB_MMASTER_PSLVERR;
assign APB_MMASTER_in_pslverr                        = APB_MMASTER_PSLVERR_net_0;
assign FIC_3_0x4FFF_FFxx_PENABLE_net_0               = FIC_3_0x4FFF_FFxx_PENABLE;
assign APBmslave15_PENABLES                          = FIC_3_0x4FFF_FFxx_PENABLE_net_0;
assign FIC_3_0x4FFF_FFxx_PSELx_net_0                 = FIC_3_0x4FFF_FFxx_PSELx;
assign APBmslave15_PSELS15                           = FIC_3_0x4FFF_FFxx_PSELx_net_0;
assign FIC_3_0x4FFF_FFxx_PWRITE_net_0                = FIC_3_0x4FFF_FFxx_PWRITE;
assign APBmslave15_PWRITES                           = FIC_3_0x4FFF_FFxx_PWRITE_net_0;
assign FIC_3_0x4xxx_xxxx_0_APBmslave15_PENABLE_net_0 = FIC_3_0x4xxx_xxxx_0_APBmslave15_PENABLE;
assign APBmslave16_PENABLES                          = FIC_3_0x4xxx_xxxx_0_APBmslave15_PENABLE_net_0;
assign FIC_3_0x43xx_xxxx_0x48xx_xxxx_PSELx_net_0     = FIC_3_0x43xx_xxxx_0x48xx_xxxx_PSELx;
assign APBmslave16_PSELS16                           = FIC_3_0x43xx_xxxx_0x48xx_xxxx_PSELx_net_0;
assign FIC_3_0x4xxx_xxxx_0_APBmslave15_PWRITE_net_0  = FIC_3_0x4xxx_xxxx_0_APBmslave15_PWRITE;
assign APBmslave16_PWRITES                           = FIC_3_0x4xxx_xxxx_0_APBmslave15_PWRITE_net_0;
assign APB_MMASTER_PRDATA_net_0                      = APB_MMASTER_PRDATA;
assign APB_MMASTER_in_prdata[31:0]                   = APB_MMASTER_PRDATA_net_0;
assign FIC_3_0x4FFF_FFxx_PADDR_net_0                 = FIC_3_0x4FFF_FFxx_PADDR;
assign APBmslave15_PADDRS[31:0]                      = FIC_3_0x4FFF_FFxx_PADDR_net_0;
assign FIC_3_0x4FFF_FFxx_PWDATA_net_0                = FIC_3_0x4FFF_FFxx_PWDATA;
assign APBmslave15_PWDATAS[31:0]                     = FIC_3_0x4FFF_FFxx_PWDATA_net_0;
assign FIC_3_0x4xxx_xxxx_0_APBmslave15_PADDR_net_0   = FIC_3_0x4xxx_xxxx_0_APBmslave15_PADDR;
assign APBmslave16_PADDRS[31:0]                      = FIC_3_0x4xxx_xxxx_0_APBmslave15_PADDR_net_0;
assign FIC_3_0x4xxx_xxxx_0_APBmslave15_PWDATA_net_0  = FIC_3_0x4xxx_xxxx_0_APBmslave15_PWDATA;
assign APBmslave16_PWDATAS[31:0]                     = FIC_3_0x4xxx_xxxx_0_APBmslave15_PWDATA_net_0;
//--------------------------------------------------------------------
// Component instances
//--------------------------------------------------------------------
//--------APB_ARBITER
APB_ARBITER #( 
        .select_bit ( 28 ) )
APB_ARBITER_0(
        // Inputs
        .in_penable       ( APB_MMASTER_in_penable ),
        .in_psel          ( APB_MMASTER_in_psel ),
        .in_paddr         ( APB_MMASTER_in_paddr ),
        .in_pwrite        ( APB_MMASTER_in_pwrite ),
        .in_pwdata        ( APB_MMASTER_in_pwdata ),
        .out_low_prdata   ( APB_ARBITER_0_APB_MASTER_low_PRDATA ),
        .out_low_pready   ( APB_ARBITER_0_APB_MASTER_low_PREADY ),
        .out_low_pslverr  ( APB_ARBITER_0_APB_MASTER_low_PSLVERR ),
        .out_high_prdata  ( out_high_prdata_const_net_0 ), // tied to 32'h00000000 from definition
        .out_high_pready  ( VCC_net ), // tied to 1'b1 from definition
        .out_high_pslverr ( GND_net ), // tied to 1'b0 from definition
        // Outputs
        .in_prdata        ( APB_MMASTER_PRDATA ),
        .in_pready        ( APB_MMASTER_PREADY ),
        .in_pslverr       ( APB_MMASTER_PSLVERR ),
        .out_low_penable  ( APB_ARBITER_0_APB_MASTER_low_PENABLE ),
        .out_low_psel     ( APB_ARBITER_0_APB_MASTER_low_PSELx ),
        .out_low_paddr    ( APB_ARBITER_0_APB_MASTER_low_PADDR ),
        .out_low_pwrite   ( APB_ARBITER_0_APB_MASTER_low_PWRITE ),
        .out_low_pwdata   ( APB_ARBITER_0_APB_MASTER_low_PWDATA ),
        .out_high_penable (  ),
        .out_high_psel    (  ),
        .out_high_paddr   (  ),
        .out_high_pwrite  (  ),
        .out_high_pwdata  (  ) 
        );

//--------APB_PASS_THROUGH
APB_PASS_THROUGH APB_PASS_THROUGH_1(
        // Inputs
        .target_penable    ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PENABLE ),
        .target_psel       ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PSELx ),
        .target_paddr      ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PADDR ),
        .target_pwrite     ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PWRITE ),
        .target_pwdata     ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PWDATA ),
        .initiator_prdata  ( APB_PASS_THROUGH_1_APB_INITIATOR_PRDATA ),
        .initiator_pready  ( APB_PASS_THROUGH_1_APB_INITIATOR_PREADY ),
        .initiator_pslverr ( APB_PASS_THROUGH_1_APB_INITIATOR_PSLVERR ),
        // Outputs
        .target_prdata     ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PRDATA ),
        .target_pready     ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PREADY ),
        .target_pslverr    ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PSLVERR ),
        .initiator_penable ( APB_PASS_THROUGH_1_APB_INITIATOR_PENABLE ),
        .initiator_psel    ( APB_PASS_THROUGH_1_APB_INITIATOR_PSELx ),
        .initiator_paddr   ( APB_PASS_THROUGH_1_APB_INITIATOR_PADDR ),
        .initiator_pwrite  ( APB_PASS_THROUGH_1_APB_INITIATOR_PWRITE ),
        .initiator_pwdata  ( APB_PASS_THROUGH_1_APB_INITIATOR_PWDATA ) 
        );

//--------FIC_3_0x4FFF_Fxxx
FIC_3_0x4FFF_Fxxx FIC_3_0x4FFF_Fxxx_0(
        // Inputs
        .PADDR      ( APB_PASS_THROUGH_1_APB_INITIATOR_PADDR ),
        .PSEL       ( APB_PASS_THROUGH_1_APB_INITIATOR_PSELx ),
        .PENABLE    ( APB_PASS_THROUGH_1_APB_INITIATOR_PENABLE ),
        .PWRITE     ( APB_PASS_THROUGH_1_APB_INITIATOR_PWRITE ),
        .PWDATA     ( APB_PASS_THROUGH_1_APB_INITIATOR_PWDATA ),
        .PRDATAS15  ( APBmslave15_PRDATAS15 ),
        .PREADYS15  ( APBmslave15_PREADYS15 ),
        .PSLVERRS15 ( APBmslave15_PSLVERRS15 ),
        // Outputs
        .PRDATA     ( APB_PASS_THROUGH_1_APB_INITIATOR_PRDATA ),
        .PREADY     ( APB_PASS_THROUGH_1_APB_INITIATOR_PREADY ),
        .PSLVERR    ( APB_PASS_THROUGH_1_APB_INITIATOR_PSLVERR ),
        .PADDRS     ( FIC_3_0x4FFF_FFxx_PADDR ),
        .PSELS15    ( FIC_3_0x4FFF_FFxx_PSELx ),
        .PENABLES   ( FIC_3_0x4FFF_FFxx_PENABLE ),
        .PWRITES    ( FIC_3_0x4FFF_FFxx_PWRITE ),
        .PWDATAS    ( FIC_3_0x4FFF_FFxx_PWDATA ) 
        );

//--------FIC_3_0x4xxx_xxxx
FIC_3_0x4xxx_xxxx FIC_3_0x4xxx_xxxx_0(
        // Inputs
        .PADDR      ( APB_ARBITER_0_APB_MASTER_low_PADDR ),
        .PSEL       ( APB_ARBITER_0_APB_MASTER_low_PSELx ),
        .PENABLE    ( APB_ARBITER_0_APB_MASTER_low_PENABLE ),
        .PWRITE     ( APB_ARBITER_0_APB_MASTER_low_PWRITE ),
        .PWDATA     ( APB_ARBITER_0_APB_MASTER_low_PWDATA ),
        .PRDATAS15  ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PRDATA ),
        .PREADYS15  ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PREADY ),
        .PSLVERRS15 ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PSLVERR ),
        .PRDATAS16  ( APBmslave16_PRDATAS16 ),
        .PREADYS16  ( APBmslave16_PREADYS16 ),
        .PSLVERRS16 ( APBmslave16_PSLVERRS16 ),
        // Outputs
        .PRDATA     ( APB_ARBITER_0_APB_MASTER_low_PRDATA ),
        .PREADY     ( APB_ARBITER_0_APB_MASTER_low_PREADY ),
        .PSLVERR    ( APB_ARBITER_0_APB_MASTER_low_PSLVERR ),
        .PADDRS     ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PADDR ),
        .PSELS15    ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PSELx ),
        .PENABLES   ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PENABLE ),
        .PWRITES    ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PWRITE ),
        .PWDATAS    ( FIC_3_0x4xxx_xxxx_0_APBmslave15_PWDATA ),
        .PSELS16    ( FIC_3_0x43xx_xxxx_0x48xx_xxxx_PSELx ) 
        );


endmodule
