# Microchip Corp.
# Date: Thu Apr 17 09:16:45 2025
# 
set_component {TySOM_M_PCIe_2024_9}
