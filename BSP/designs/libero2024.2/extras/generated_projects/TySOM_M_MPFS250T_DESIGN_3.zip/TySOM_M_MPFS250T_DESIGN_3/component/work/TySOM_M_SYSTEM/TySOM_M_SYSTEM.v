//////////////////////////////////////////////////////////////////////
// Created by SmartDesign Fri Apr 18 09:26:47 2025
// Version: 2024.2 2024.2.0.13
//////////////////////////////////////////////////////////////////////

`timescale 1ns / 100ps

// TySOM_M_SYSTEM
module TySOM_M_SYSTEM(
    // Inputs
    GPIO_1_20_IN,
    MMUART_0_RXD,
    MMUART_1_RXD_F2M,
    MMUART_2_RXD_F2M,
    MMUART_3_RXD_F2M,
    PCIESS_LANE_RXD0_N,
    PCIESS_LANE_RXD0_P,
    PCIESS_LANE_RXD1_N,
    PCIESS_LANE_RXD1_P,
    PCIESS_LANE_RXD2_N,
    PCIESS_LANE_RXD2_P,
    PCIESS_LANE_RXD3_N,
    PCIESS_LANE_RXD3_P,
    REFCLK,
    REFCLK_N,
    REF_CLK_50MHz,
    REF_CLK_PAD_N,
    REF_CLK_PAD_P,
    SD_CD_EMMC_STRB,
    SD_WP_EMMC_RSTN,
    SGMII_RX0_N,
    SGMII_RX0_P,
    SGMII_RX1_N,
    SGMII_RX1_P,
    SPI_1_DI,
    USB_CLK,
    USB_DIR,
    USB_NXT,
    // Outputs
    A,
    ACT_N,
    ACT_N_0,
    A_0,
    BA,
    BA_0,
    BG,
    BG_0,
    CAS_N,
    CAS_N_0,
    CK0,
    CK0_0,
    CK0_N,
    CK0_N_0,
    CKE,
    CKE0,
    CS0_N,
    CS_N,
    DM_N,
    GPIO_1_23_OUT,
    MAC_1_MDC,
    MMUART_0_TXD,
    MMUART_1_TXD_M2F,
    MMUART_2_TXD_M2F,
    MMUART_3_TXD_M2F,
    ODT,
    ODT0,
    PCIESS_LANE_TXD0_N,
    PCIESS_LANE_TXD0_P,
    PCIESS_LANE_TXD1_N,
    PCIESS_LANE_TXD1_P,
    PCIESS_LANE_TXD2_N,
    PCIESS_LANE_TXD2_P,
    PCIESS_LANE_TXD3_N,
    PCIESS_LANE_TXD3_P,
    PCIE_1_PERST_N,
    RAS_N,
    RAS_N_0,
    RESET_N,
    RESET_N_0,
    SD_CLK_EMMC_CLK,
    SD_POW_EMMC_DATA4,
    SD_SEL,
    SD_VOLT_CMD_DIR_EMMC_DATA7,
    SD_VOLT_DIR_0_EMMC_UNUSED,
    SD_VOLT_DIR_1_3_EMMC_UNUSED,
    SD_VOLT_EN_EMMC_DATA6,
    SD_VOLT_SEL_EMMC_DATA5,
    SGMII_TX0_N,
    SGMII_TX0_P,
    SGMII_TX1_N,
    SGMII_TX1_P,
    SHIELD0,
    SHIELD1,
    SHIELD2,
    SHIELD3,
    SPI_1_DO,
    USB_STP,
    USB_ULPI_RESET,
    VSC_8662_CMODE7,
    VSC_8662_RESETN,
    VSC_8662_SRESET,
    WE_N,
    WE_N_0,
    // Inouts
    DQ,
    DQS,
    DQS_0,
    DQS_N,
    DQS_N_0,
    DQ_0,
    DQ_ECC,
    I2C0_SCL,
    I2C0_SDA,
    I2C_1_SCL,
    I2C_1_SDA,
    MAC_1_MDIO,
    SD_CMD_EMMC_CMD,
    SD_DATA0_EMMC_DATA0,
    SD_DATA1_EMMC_DATA1,
    SD_DATA2_EMMC_DATA2,
    SD_DATA3_EMMC_DATA3,
    SPI_1_CLK,
    SPI_1_SS0,
    USB_DATA0,
    USB_DATA1,
    USB_DATA2,
    USB_DATA3,
    USB_DATA4,
    USB_DATA5,
    USB_DATA6,
    USB_DATA7
);

//--------------------------------------------------------------------
// Input
//--------------------------------------------------------------------
input          GPIO_1_20_IN;
input          MMUART_0_RXD;
input          MMUART_1_RXD_F2M;
input          MMUART_2_RXD_F2M;
input          MMUART_3_RXD_F2M;
input          PCIESS_LANE_RXD0_N;
input          PCIESS_LANE_RXD0_P;
input          PCIESS_LANE_RXD1_N;
input          PCIESS_LANE_RXD1_P;
input          PCIESS_LANE_RXD2_N;
input          PCIESS_LANE_RXD2_P;
input          PCIESS_LANE_RXD3_N;
input          PCIESS_LANE_RXD3_P;
input          REFCLK;
input          REFCLK_N;
input          REF_CLK_50MHz;
input          REF_CLK_PAD_N;
input          REF_CLK_PAD_P;
input          SD_CD_EMMC_STRB;
input          SD_WP_EMMC_RSTN;
input          SGMII_RX0_N;
input          SGMII_RX0_P;
input          SGMII_RX1_N;
input          SGMII_RX1_P;
input          SPI_1_DI;
input          USB_CLK;
input          USB_DIR;
input          USB_NXT;
//--------------------------------------------------------------------
// Output
//--------------------------------------------------------------------
output [13:0]  A;
output         ACT_N;
output         ACT_N_0;
output [13:0]  A_0;
output [1:0]   BA;
output [1:0]   BA_0;
output [1:0]   BG;
output [1:0]   BG_0;
output         CAS_N;
output         CAS_N_0;
output         CK0;
output         CK0_0;
output         CK0_N;
output         CK0_N_0;
output         CKE;
output         CKE0;
output         CS0_N;
output         CS_N;
output [3:0]   DM_N;
output         GPIO_1_23_OUT;
output         MAC_1_MDC;
output         MMUART_0_TXD;
output         MMUART_1_TXD_M2F;
output         MMUART_2_TXD_M2F;
output         MMUART_3_TXD_M2F;
output         ODT;
output         ODT0;
output         PCIESS_LANE_TXD0_N;
output         PCIESS_LANE_TXD0_P;
output         PCIESS_LANE_TXD1_N;
output         PCIESS_LANE_TXD1_P;
output         PCIESS_LANE_TXD2_N;
output         PCIESS_LANE_TXD2_P;
output         PCIESS_LANE_TXD3_N;
output         PCIESS_LANE_TXD3_P;
output         PCIE_1_PERST_N;
output         RAS_N;
output         RAS_N_0;
output         RESET_N;
output         RESET_N_0;
output         SD_CLK_EMMC_CLK;
output         SD_POW_EMMC_DATA4;
output         SD_SEL;
output         SD_VOLT_CMD_DIR_EMMC_DATA7;
output         SD_VOLT_DIR_0_EMMC_UNUSED;
output         SD_VOLT_DIR_1_3_EMMC_UNUSED;
output         SD_VOLT_EN_EMMC_DATA6;
output         SD_VOLT_SEL_EMMC_DATA5;
output         SGMII_TX0_N;
output         SGMII_TX0_P;
output         SGMII_TX1_N;
output         SGMII_TX1_P;
output         SHIELD0;
output         SHIELD1;
output         SHIELD2;
output         SHIELD3;
output         SPI_1_DO;
output         USB_STP;
output         USB_ULPI_RESET;
output         VSC_8662_CMODE7;
output         VSC_8662_RESETN;
output         VSC_8662_SRESET;
output         WE_N;
output         WE_N_0;
//--------------------------------------------------------------------
// Inout
//--------------------------------------------------------------------
inout  [31:0]  DQ;
inout  [4:0]   DQS;
inout  [3:0]   DQS_0;
inout  [4:0]   DQS_N;
inout  [3:0]   DQS_N_0;
inout  [31:0]  DQ_0;
inout  [35:32] DQ_ECC;
inout          I2C0_SCL;
inout          I2C0_SDA;
inout          I2C_1_SCL;
inout          I2C_1_SDA;
inout          MAC_1_MDIO;
inout          SD_CMD_EMMC_CMD;
inout          SD_DATA0_EMMC_DATA0;
inout          SD_DATA1_EMMC_DATA1;
inout          SD_DATA2_EMMC_DATA2;
inout          SD_DATA3_EMMC_DATA3;
inout          SPI_1_CLK;
inout          SPI_1_SS0;
inout          USB_DATA0;
inout          USB_DATA1;
inout          USB_DATA2;
inout          USB_DATA3;
inout          USB_DATA4;
inout          USB_DATA5;
inout          USB_DATA6;
inout          USB_DATA7;
//--------------------------------------------------------------------
// Nets
//--------------------------------------------------------------------
wire   [13:0]  A_net_0;
wire   [13:0]  A_0_net_0;
wire           ACT_N_net_0;
wire           ACT_N_0_net_0;
wire   [1:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARBURST;
wire   [3:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARCACHE;
wire   [7:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARID;
wire   [7:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARLEN;
wire   [2:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARPROT;
wire   [3:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARQOS;
wire           ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARREADY;
wire   [2:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARSIZE;
wire           ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARVALID;
wire   [1:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWBURST;
wire   [3:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWCACHE;
wire   [7:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWID;
wire   [7:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWLEN;
wire   [2:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWPROT;
wire   [3:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWQOS;
wire           ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWREADY;
wire   [2:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWSIZE;
wire           ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWVALID;
wire   [7:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_BID;
wire           ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_BREADY;
wire   [1:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_BRESP;
wire   [0:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_BUSER;
wire           ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_BVALID;
wire   [63:0]  ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RDATA;
wire   [7:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RID;
wire           ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RLAST;
wire           ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RREADY;
wire   [1:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RRESP;
wire   [0:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RUSER;
wire           ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RVALID;
wire   [63:0]  ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_WDATA;
wire           ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_WLAST;
wire           ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_WREADY;
wire   [7:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_WSTRB;
wire           ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_WVALID;
wire           ALDEC_MSS_2024_9_FIC_0_DLL_LOCK_M2F;
wire   [37:0]  ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARADDR;
wire   [1:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARBURST;
wire   [3:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARCACHE;
wire   [7:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARID;
wire   [7:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARLEN;
wire   [2:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARPROT;
wire   [3:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARQOS;
wire           ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARREADY;
wire   [2:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARSIZE;
wire           ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARVALID;
wire   [37:0]  ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWADDR;
wire   [1:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWBURST;
wire   [3:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWCACHE;
wire   [7:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWID;
wire   [7:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWLEN;
wire   [2:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWPROT;
wire   [3:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWQOS;
wire           ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWREADY;
wire   [2:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWSIZE;
wire           ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWVALID;
wire   [7:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_BID;
wire           ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_BREADY;
wire   [1:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_BRESP;
wire   [0:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_BUSER;
wire           ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_BVALID;
wire   [63:0]  ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RDATA;
wire   [7:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RID;
wire           ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RLAST;
wire           ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RREADY;
wire   [1:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RRESP;
wire   [0:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RUSER;
wire           ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RVALID;
wire   [63:0]  ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_WDATA;
wire           ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_WLAST;
wire           ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_WREADY;
wire   [7:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_WSTRB;
wire           ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_WVALID;
wire           ALDEC_MSS_2024_9_FIC_1_DLL_LOCK_M2F;
wire           ALDEC_MSS_2024_9_FIC_2_DLL_LOCK_M2F;
wire   [31:0]  ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PADDR;
wire           ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PENABLE;
wire   [31:0]  ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PRDATA;
wire           ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PREADY;
wire           ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PSELx;
wire           ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PSLVERR;
wire   [31:0]  ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PWDATA;
wire           ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PWRITE;
wire   [3:0]   ALDEC_MSS_2024_9_FIC_3_APB_M_PSTRB;
wire           ALDEC_MSS_2024_9_FIC_3_DLL_LOCK_M2F;
wire           ALDEC_MSS_2024_9_I2C_0_SCL_OE_M2F;
wire           ALDEC_MSS_2024_9_I2C_0_SDA_OE_M2F;
wire           ALDEC_MSS_2024_9_MMUART_4_TXD_M2F;
wire           AND4_MSS_DLL_LOCKS_Y;
wire   [1:0]   BA_net_0;
wire   [1:0]   BA_0_net_0;
wire   [1:0]   BG_net_0;
wire   [1:0]   BG_0_net_0;
wire           BIBUF_I2C0_SCL_Y;
wire           BIBUF_I2C0_SDA_Y;
wire           CAS_N_net_0;
wire           CAS_N_0_net_0;
wire           CK0_net_0;
wire           CK0_0_net_0;
wire           CK0_N_net_0;
wire           CK0_N_0_net_0;
wire           CKE_net_0;
wire           CKE0_net_0;
wire           CLOCKS_AND_RESETS_CLKS_TO_XCVR_BIT_CLK;
wire           CLOCKS_AND_RESETS_CLKS_TO_XCVR_LOCK;
wire           CLOCKS_AND_RESETS_CLKS_TO_XCVR_REF_CLK_TO_LANE;
wire           CLOCKS_AND_RESETS_FIC_0_CLK;
wire           CLOCKS_AND_RESETS_FIC_1_CLK;
wire           CLOCKS_AND_RESETS_FIC_2_CLK;
wire           CLOCKS_AND_RESETS_FIC_3_CLK;
wire           CLOCKS_AND_RESETS_PCIe_CLK_125MHz;
wire           CLOCKS_AND_RESETS_PCIE_INIT_DONE;
wire           CLOCKS_AND_RESETS_PCIe_REFERENCE_CLK;
wire           CLOCKS_AND_RESETS_RESETN_FIC_0_CLK;
wire           CLOCKS_AND_RESETS_RESETN_FIC_1_CLK;
wire           CLOCKS_AND_RESETS_RESETN_FIC_3_CLK;
wire           CS0_N_net_0;
wire           CS_N_net_0;
wire   [31:0]  DDR4_INITIATOR_0_AXI4mslave0_ARADDR;
wire   [1:0]   DDR4_INITIATOR_0_AXI4mslave0_ARBURST;
wire   [3:0]   DDR4_INITIATOR_0_AXI4mslave0_ARCACHE;
wire   [7:0]   DDR4_INITIATOR_0_AXI4mslave0_ARLEN;
wire   [1:0]   DDR4_INITIATOR_0_AXI4mslave0_ARLOCK;
wire   [2:0]   DDR4_INITIATOR_0_AXI4mslave0_ARPROT;
wire   [3:0]   DDR4_INITIATOR_0_AXI4mslave0_ARQOS;
wire           DDR4_INITIATOR_0_AXI4mslave0_ARREADY;
wire   [3:0]   DDR4_INITIATOR_0_AXI4mslave0_ARREGION;
wire   [2:0]   DDR4_INITIATOR_0_AXI4mslave0_ARSIZE;
wire   [0:0]   DDR4_INITIATOR_0_AXI4mslave0_ARUSER;
wire           DDR4_INITIATOR_0_AXI4mslave0_ARVALID;
wire   [31:0]  DDR4_INITIATOR_0_AXI4mslave0_AWADDR;
wire   [1:0]   DDR4_INITIATOR_0_AXI4mslave0_AWBURST;
wire   [3:0]   DDR4_INITIATOR_0_AXI4mslave0_AWCACHE;
wire   [7:0]   DDR4_INITIATOR_0_AXI4mslave0_AWLEN;
wire   [1:0]   DDR4_INITIATOR_0_AXI4mslave0_AWLOCK;
wire   [2:0]   DDR4_INITIATOR_0_AXI4mslave0_AWPROT;
wire   [3:0]   DDR4_INITIATOR_0_AXI4mslave0_AWQOS;
wire           DDR4_INITIATOR_0_AXI4mslave0_AWREADY;
wire   [3:0]   DDR4_INITIATOR_0_AXI4mslave0_AWREGION;
wire   [2:0]   DDR4_INITIATOR_0_AXI4mslave0_AWSIZE;
wire   [0:0]   DDR4_INITIATOR_0_AXI4mslave0_AWUSER;
wire           DDR4_INITIATOR_0_AXI4mslave0_AWVALID;
wire           DDR4_INITIATOR_0_AXI4mslave0_BREADY;
wire   [1:0]   DDR4_INITIATOR_0_AXI4mslave0_BRESP;
wire           DDR4_INITIATOR_0_AXI4mslave0_BVALID;
wire   [63:0]  DDR4_INITIATOR_0_AXI4mslave0_RDATA;
wire           DDR4_INITIATOR_0_AXI4mslave0_RLAST;
wire           DDR4_INITIATOR_0_AXI4mslave0_RREADY;
wire   [1:0]   DDR4_INITIATOR_0_AXI4mslave0_RRESP;
wire           DDR4_INITIATOR_0_AXI4mslave0_RVALID;
wire   [63:0]  DDR4_INITIATOR_0_AXI4mslave0_WDATA;
wire           DDR4_INITIATOR_0_AXI4mslave0_WLAST;
wire           DDR4_INITIATOR_0_AXI4mslave0_WREADY;
wire   [7:0]   DDR4_INITIATOR_0_AXI4mslave0_WSTRB;
wire   [0:0]   DDR4_INITIATOR_0_AXI4mslave0_WUSER;
wire           DDR4_INITIATOR_0_AXI4mslave0_WVALID;
wire   [3:0]   DM_N_net_0;
wire   [31:0]  DQ;
wire   [31:0]  DQ_0;
wire   [35:32] DQ_ECC;
wire   [4:0]   DQS;
wire   [3:0]   DQS_0;
wire   [4:0]   DQS_N;
wire   [3:0]   DQS_N_0;
wire   [37:0]  FIC_1_PERIPHERALS_1_AXI4mslave0_ARADDR;
wire   [1:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_ARBURST;
wire   [3:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_ARCACHE;
wire   [7:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_ARLEN;
wire   [2:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_ARPROT;
wire   [3:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_ARQOS;
wire           FIC_1_PERIPHERALS_1_AXI4mslave0_ARREADY;
wire   [3:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_ARREGION;
wire   [2:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_ARSIZE;
wire   [0:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_ARUSER;
wire           FIC_1_PERIPHERALS_1_AXI4mslave0_ARVALID;
wire   [37:0]  FIC_1_PERIPHERALS_1_AXI4mslave0_AWADDR;
wire   [1:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_AWBURST;
wire   [3:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_AWCACHE;
wire   [7:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_AWLEN;
wire   [2:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_AWPROT;
wire   [3:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_AWQOS;
wire           FIC_1_PERIPHERALS_1_AXI4mslave0_AWREADY;
wire   [3:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_AWREGION;
wire   [2:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_AWSIZE;
wire   [0:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_AWUSER;
wire           FIC_1_PERIPHERALS_1_AXI4mslave0_AWVALID;
wire           FIC_1_PERIPHERALS_1_AXI4mslave0_BREADY;
wire   [1:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_BRESP;
wire           FIC_1_PERIPHERALS_1_AXI4mslave0_BVALID;
wire   [63:0]  FIC_1_PERIPHERALS_1_AXI4mslave0_RDATA;
wire           FIC_1_PERIPHERALS_1_AXI4mslave0_RLAST;
wire           FIC_1_PERIPHERALS_1_AXI4mslave0_RREADY;
wire   [1:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_RRESP;
wire           FIC_1_PERIPHERALS_1_AXI4mslave0_RVALID;
wire   [63:0]  FIC_1_PERIPHERALS_1_AXI4mslave0_WDATA;
wire           FIC_1_PERIPHERALS_1_AXI4mslave0_WLAST;
wire           FIC_1_PERIPHERALS_1_AXI4mslave0_WREADY;
wire   [7:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_WSTRB;
wire   [0:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_WUSER;
wire           FIC_1_PERIPHERALS_1_AXI4mslave0_WVALID;
wire           FIC_1_PERIPHERALS_1_PCIe_IRQ;
wire           FIC_3_PERIPHERALS_1_fabric_sd_emmc_demux_select_out;
wire           FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_ARST_N;
wire           FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_CLK;
wire   [10:0]  FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_CTRL;
wire           FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_INTERRUPT;
wire   [32:0]  FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_RDATA;
wire   [32:0]  FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_WDATA;
wire   [10:0]  FIC_3_PERIPHERALS_1_Q0_LANE1_DRI_DRI_CTRL;
wire           FIC_3_PERIPHERALS_1_Q0_LANE1_DRI_DRI_INTERRUPT;
wire   [32:0]  FIC_3_PERIPHERALS_1_Q0_LANE1_DRI_DRI_RDATA;
wire   [10:0]  FIC_3_PERIPHERALS_1_Q0_LANE2_DRI_DRI_CTRL;
wire           FIC_3_PERIPHERALS_1_Q0_LANE2_DRI_DRI_INTERRUPT;
wire   [32:0]  FIC_3_PERIPHERALS_1_Q0_LANE2_DRI_DRI_RDATA;
wire   [10:0]  FIC_3_PERIPHERALS_1_Q0_LANE3_DRI_DRI_CTRL;
wire           FIC_3_PERIPHERALS_1_Q0_LANE3_DRI_DRI_INTERRUPT;
wire   [32:0]  FIC_3_PERIPHERALS_1_Q0_LANE3_DRI_DRI_RDATA;
wire           GPIO_1_20_IN;
wire           GPIO_1_23_OUT_net_0;
wire           I2C0_SCL;
wire           I2C0_SDA;
wire           I2C_1_SCL;
wire           I2C_1_SDA;
wire           MAC_1_MDC_net_0;
wire           MAC_1_MDIO;
wire           MMUART_0_RXD;
wire           MMUART_0_TXD_net_0;
wire           MMUART_1_RXD_F2M;
wire           MMUART_1_TXD_M2F_net_0;
wire           MMUART_2_RXD_F2M;
wire           MMUART_2_TXD_M2F_net_0;
wire           MMUART_3_RXD_F2M;
wire           MMUART_3_TXD_M2F_net_0;
wire           ODT_net_0;
wire           ODT0_net_0;
wire           PCIE_1_PERST_N_net_0;
wire           PCIESS_LANE_RXD0_N;
wire           PCIESS_LANE_RXD0_P;
wire           PCIESS_LANE_RXD1_N;
wire           PCIESS_LANE_RXD1_P;
wire           PCIESS_LANE_RXD2_N;
wire           PCIESS_LANE_RXD2_P;
wire           PCIESS_LANE_RXD3_N;
wire           PCIESS_LANE_RXD3_P;
wire           PCIESS_LANE_TXD0_N_net_0;
wire           PCIESS_LANE_TXD0_P_net_0;
wire           PCIESS_LANE_TXD1_N_net_0;
wire           PCIESS_LANE_TXD1_P_net_0;
wire           PCIESS_LANE_TXD2_N_net_0;
wire           PCIESS_LANE_TXD2_P_net_0;
wire           PCIESS_LANE_TXD3_N_net_0;
wire           PCIESS_LANE_TXD3_P_net_0;
wire           PF_DDR4_C0_0_SYS_CLK;
wire           RAS_N_net_0;
wire           RAS_N_0_net_0;
wire           REF_CLK_50MHz;
wire           REF_CLK_PAD_N;
wire           REF_CLK_PAD_P;
wire           REFCLK;
wire           REFCLK_N;
wire           RESET_N_net_0;
wire           RESET_N_0_net_0;
wire           SD_CD_EMMC_STRB;
wire           SD_CLK_EMMC_CLK_net_0;
wire           SD_CMD_EMMC_CMD;
wire           SD_DATA0_EMMC_DATA0;
wire           SD_DATA1_EMMC_DATA1;
wire           SD_DATA2_EMMC_DATA2;
wire           SD_DATA3_EMMC_DATA3;
wire           SD_POW_EMMC_DATA4_net_0;
wire           SD_SEL_net_0;
wire           SD_VOLT_CMD_DIR_EMMC_DATA7_net_0;
wire           SD_VOLT_DIR_0_EMMC_UNUSED_net_0;
wire           SD_VOLT_DIR_1_3_EMMC_UNUSED_net_0;
wire           SD_VOLT_EN_EMMC_DATA6_net_0;
wire           SD_VOLT_SEL_EMMC_DATA5_net_0;
wire           SD_WP_EMMC_RSTN;
wire           SGMII_RX0_N;
wire           SGMII_RX0_P;
wire           SGMII_RX1_N;
wire           SGMII_RX1_P;
wire           SGMII_TX0_N_net_0;
wire           SGMII_TX0_P_net_0;
wire           SGMII_TX1_N_net_0;
wire           SGMII_TX1_P_net_0;
wire           SHIELD0_net_0;
wire           SHIELD1_net_0;
wire           SHIELD2_net_0;
wire           SHIELD3_net_0;
wire           SPI_1_CLK;
wire           SPI_1_DI;
wire           SPI_1_DO_net_0;
wire           SPI_1_SS0;
wire           USB_CLK;
wire           USB_DATA0;
wire           USB_DATA1;
wire           USB_DATA2;
wire           USB_DATA3;
wire           USB_DATA4;
wire           USB_DATA5;
wire           USB_DATA6;
wire           USB_DATA7;
wire           USB_DIR;
wire           USB_NXT;
wire           USB_STP_net_0;
wire           USB_ULPI_RESET_net_0;
wire           WE_N_net_0;
wire           WE_N_0_net_0;
wire           ACT_N_0_net_1;
wire           ACT_N_net_1;
wire           CAS_N_0_net_1;
wire           CAS_N_net_1;
wire           CK0_0_net_1;
wire           CK0_N_0_net_1;
wire           CK0_N_net_1;
wire           CK0_net_1;
wire           CKE0_net_1;
wire           CKE_net_1;
wire           CS0_N_net_1;
wire           CS_N_net_1;
wire           GPIO_1_23_OUT_net_1;
wire           MAC_1_MDC_net_1;
wire           MMUART_0_TXD_net_1;
wire           MMUART_1_TXD_M2F_net_1;
wire           MMUART_2_TXD_M2F_net_1;
wire           MMUART_3_TXD_M2F_net_1;
wire           ODT0_net_1;
wire           ODT_net_1;
wire           PCIESS_LANE_TXD0_N_net_1;
wire           PCIESS_LANE_TXD0_P_net_1;
wire           PCIESS_LANE_TXD1_N_net_1;
wire           PCIESS_LANE_TXD1_P_net_1;
wire           PCIESS_LANE_TXD2_N_net_1;
wire           PCIESS_LANE_TXD2_P_net_1;
wire           PCIESS_LANE_TXD3_N_net_1;
wire           PCIESS_LANE_TXD3_P_net_1;
wire           PCIE_1_PERST_N_net_1;
wire           RAS_N_0_net_1;
wire           RAS_N_net_1;
wire           RESET_N_0_net_1;
wire           RESET_N_net_1;
wire           SD_CLK_EMMC_CLK_net_1;
wire           SD_POW_EMMC_DATA4_net_1;
wire           SD_SEL_net_1;
wire           SD_VOLT_CMD_DIR_EMMC_DATA7_net_1;
wire           SD_VOLT_DIR_0_EMMC_UNUSED_net_1;
wire           SD_VOLT_DIR_1_3_EMMC_UNUSED_net_1;
wire           SD_VOLT_EN_EMMC_DATA6_net_1;
wire           SD_VOLT_SEL_EMMC_DATA5_net_1;
wire           SGMII_TX0_N_net_1;
wire           SGMII_TX0_P_net_1;
wire           SGMII_TX1_N_net_1;
wire           SGMII_TX1_P_net_1;
wire           SHIELD0_net_1;
wire           SHIELD1_net_1;
wire           SHIELD2_net_1;
wire           SHIELD3_net_1;
wire           SPI_1_DO_net_1;
wire           USB_STP_net_1;
wire           USB_ULPI_RESET_net_2;
wire           WE_N_0_net_1;
wire           WE_N_net_1;
wire   [13:0]  A_0_net_1;
wire   [13:0]  A_net_1;
wire   [1:0]   BA_0_net_1;
wire   [1:0]   BA_net_1;
wire   [1:0]   BG_0_net_1;
wire   [1:0]   BG_net_1;
wire   [3:0]   DM_N_net_1;
wire   [63:0]  MSS_INT_F2M_net_0;
//--------------------------------------------------------------------
// TiedOff Nets
//--------------------------------------------------------------------
wire           GND_net;
wire           VCC_net;
wire   [3:0]   QSPI_DATA_F2M_const_net_0;
wire   [4:58]  MSS_INT_F2M_const_net_0;
wire   [3:0]   FIC_0_AXI4_S_AWID_const_net_0;
wire   [37:0]  FIC_0_AXI4_S_AWADDR_const_net_0;
wire   [7:0]   FIC_0_AXI4_S_AWLEN_const_net_0;
wire   [2:0]   FIC_0_AXI4_S_AWSIZE_const_net_0;
wire   [1:0]   FIC_0_AXI4_S_AWBURST_const_net_0;
wire   [3:0]   FIC_0_AXI4_S_AWQOS_const_net_0;
wire   [3:0]   FIC_0_AXI4_S_AWCACHE_const_net_0;
wire   [2:0]   FIC_0_AXI4_S_AWPROT_const_net_0;
wire   [63:0]  FIC_0_AXI4_S_WDATA_const_net_0;
wire   [7:0]   FIC_0_AXI4_S_WSTRB_const_net_0;
wire   [3:0]   FIC_0_AXI4_S_ARID_const_net_0;
wire   [37:0]  FIC_0_AXI4_S_ARADDR_const_net_0;
wire   [7:0]   FIC_0_AXI4_S_ARLEN_const_net_0;
wire   [2:0]   FIC_0_AXI4_S_ARSIZE_const_net_0;
wire   [1:0]   FIC_0_AXI4_S_ARBURST_const_net_0;
wire   [3:0]   FIC_0_AXI4_S_ARQOS_const_net_0;
wire   [3:0]   FIC_0_AXI4_S_ARCACHE_const_net_0;
wire   [2:0]   FIC_0_AXI4_S_ARPROT_const_net_0;
wire   [3:0]   FIC_2_AXI4_S_AWID_const_net_0;
wire   [37:0]  FIC_2_AXI4_S_AWADDR_const_net_0;
wire   [7:0]   FIC_2_AXI4_S_AWLEN_const_net_0;
wire   [2:0]   FIC_2_AXI4_S_AWSIZE_const_net_0;
wire   [1:0]   FIC_2_AXI4_S_AWBURST_const_net_0;
wire   [3:0]   FIC_2_AXI4_S_AWCACHE_const_net_0;
wire   [3:0]   FIC_2_AXI4_S_AWQOS_const_net_0;
wire   [2:0]   FIC_2_AXI4_S_AWPROT_const_net_0;
wire   [63:0]  FIC_2_AXI4_S_WDATA_const_net_0;
wire   [7:0]   FIC_2_AXI4_S_WSTRB_const_net_0;
wire   [3:0]   FIC_2_AXI4_S_ARID_const_net_0;
wire   [37:0]  FIC_2_AXI4_S_ARADDR_const_net_0;
wire   [7:0]   FIC_2_AXI4_S_ARLEN_const_net_0;
wire   [2:0]   FIC_2_AXI4_S_ARSIZE_const_net_0;
wire   [1:0]   FIC_2_AXI4_S_ARBURST_const_net_0;
wire   [3:0]   FIC_2_AXI4_S_ARCACHE_const_net_0;
wire   [3:0]   FIC_2_AXI4_S_ARQOS_const_net_0;
wire   [2:0]   FIC_2_AXI4_S_ARPROT_const_net_0;
wire   [3:0]   MASTER0_AWREGION_const_net_0;
wire   [3:0]   MASTER0_ARREGION_const_net_0;
wire   [3:0]   AXI4mmaster0_MASTER0_AWREGION_const_net_0;
wire   [3:0]   AXI4mmaster0_MASTER0_ARREGION_const_net_0;
wire   [25:0]  PCIE_APB_SLAVE_APB_S_PADDR_const_net_0;
wire   [31:0]  PCIE_APB_SLAVE_APB_S_PWDATA_const_net_0;
wire   [32:0]  PLL0_SW_DRI_RDATA_const_net_0;
//--------------------------------------------------------------------
// Inverted Nets
//--------------------------------------------------------------------
wire           USB_ULPI_RESET_net_1;
wire           USB_ULPI_RESET_OUT_PRE_INV0_0;
//--------------------------------------------------------------------
// Bus Interface Nets Declarations - Unequal Pin Widths
//--------------------------------------------------------------------
wire   [37:0]  ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARADDR;
wire   [31:0]  ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARADDR_0;
wire   [31:0]  ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARADDR_0_31to0;
wire           ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARLOCK;
wire   [1:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARLOCK_0;
wire   [0:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARLOCK_0_0to0;
wire   [1:1]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARLOCK_0_1to1;
wire   [37:0]  ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWADDR;
wire   [31:0]  ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWADDR_0;
wire   [31:0]  ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWADDR_0_31to0;
wire           ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWLOCK;
wire   [1:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWLOCK_0;
wire   [0:0]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWLOCK_0_0to0;
wire   [1:1]   ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWLOCK_0_1to1;
wire           ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARLOCK;
wire   [1:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARLOCK_0;
wire   [0:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARLOCK_0_0to0;
wire   [1:1]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARLOCK_0_1to1;
wire           ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWLOCK;
wire   [1:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWLOCK_0;
wire   [0:0]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWLOCK_0_0to0;
wire   [1:1]   ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWLOCK_0_1to1;
wire   [8:0]   DDR4_INITIATOR_0_AXI4mslave0_ARID;
wire   [7:0]   DDR4_INITIATOR_0_AXI4mslave0_ARID_0;
wire   [7:0]   DDR4_INITIATOR_0_AXI4mslave0_ARID_0_7to0;
wire   [8:0]   DDR4_INITIATOR_0_AXI4mslave0_AWID;
wire   [7:0]   DDR4_INITIATOR_0_AXI4mslave0_AWID_0;
wire   [7:0]   DDR4_INITIATOR_0_AXI4mslave0_AWID_0_7to0;
wire   [7:0]   DDR4_INITIATOR_0_AXI4mslave0_BID;
wire   [8:0]   DDR4_INITIATOR_0_AXI4mslave0_BID_0;
wire   [7:0]   DDR4_INITIATOR_0_AXI4mslave0_BID_0_7to0;
wire   [8:8]   DDR4_INITIATOR_0_AXI4mslave0_BID_0_8to8;
wire   [7:0]   DDR4_INITIATOR_0_AXI4mslave0_RID;
wire   [8:0]   DDR4_INITIATOR_0_AXI4mslave0_RID_0;
wire   [7:0]   DDR4_INITIATOR_0_AXI4mslave0_RID_0_7to0;
wire   [8:8]   DDR4_INITIATOR_0_AXI4mslave0_RID_0_8to8;
wire   [4:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_ARID;
wire   [3:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_ARID_0;
wire   [3:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_ARID_0_3to0;
wire   [1:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_ARLOCK;
wire           FIC_1_PERIPHERALS_1_AXI4mslave0_ARLOCK_0;
wire   [0:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_ARLOCK_0_0to0;
wire   [4:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_AWID;
wire   [3:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_AWID_0;
wire   [3:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_AWID_0_3to0;
wire   [1:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_AWLOCK;
wire           FIC_1_PERIPHERALS_1_AXI4mslave0_AWLOCK_0;
wire   [0:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_AWLOCK_0_0to0;
wire   [3:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_BID;
wire   [4:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_BID_0;
wire   [3:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_BID_0_3to0;
wire   [4:4]   FIC_1_PERIPHERALS_1_AXI4mslave0_BID_0_4to4;
wire   [3:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_RID;
wire   [4:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_RID_0;
wire   [3:0]   FIC_1_PERIPHERALS_1_AXI4mslave0_RID_0_3to0;
wire   [4:4]   FIC_1_PERIPHERALS_1_AXI4mslave0_RID_0_4to4;
//--------------------------------------------------------------------
// Constant assignments
//--------------------------------------------------------------------
assign GND_net                                   = 1'b0;
assign VCC_net                                   = 1'b1;
assign QSPI_DATA_F2M_const_net_0                 = 4'h0;
assign MSS_INT_F2M_const_net_0                   = 55'h00000000000000;
assign FIC_0_AXI4_S_AWID_const_net_0             = 4'h0;
assign FIC_0_AXI4_S_AWADDR_const_net_0           = 38'h0000000000;
assign FIC_0_AXI4_S_AWLEN_const_net_0            = 8'h00;
assign FIC_0_AXI4_S_AWSIZE_const_net_0           = 3'h0;
assign FIC_0_AXI4_S_AWBURST_const_net_0          = 2'h3;
assign FIC_0_AXI4_S_AWQOS_const_net_0            = 4'h0;
assign FIC_0_AXI4_S_AWCACHE_const_net_0          = 4'h0;
assign FIC_0_AXI4_S_AWPROT_const_net_0           = 3'h0;
assign FIC_0_AXI4_S_WDATA_const_net_0            = 64'h0000000000000000;
assign FIC_0_AXI4_S_WSTRB_const_net_0            = 8'hFF;
assign FIC_0_AXI4_S_ARID_const_net_0             = 4'h0;
assign FIC_0_AXI4_S_ARADDR_const_net_0           = 38'h0000000000;
assign FIC_0_AXI4_S_ARLEN_const_net_0            = 8'h00;
assign FIC_0_AXI4_S_ARSIZE_const_net_0           = 3'h0;
assign FIC_0_AXI4_S_ARBURST_const_net_0          = 2'h3;
assign FIC_0_AXI4_S_ARQOS_const_net_0            = 4'h0;
assign FIC_0_AXI4_S_ARCACHE_const_net_0          = 4'h0;
assign FIC_0_AXI4_S_ARPROT_const_net_0           = 3'h0;
assign FIC_2_AXI4_S_AWID_const_net_0             = 4'h0;
assign FIC_2_AXI4_S_AWADDR_const_net_0           = 38'h0000000000;
assign FIC_2_AXI4_S_AWLEN_const_net_0            = 8'h00;
assign FIC_2_AXI4_S_AWSIZE_const_net_0           = 3'h0;
assign FIC_2_AXI4_S_AWBURST_const_net_0          = 2'h3;
assign FIC_2_AXI4_S_AWCACHE_const_net_0          = 4'h0;
assign FIC_2_AXI4_S_AWQOS_const_net_0            = 4'h0;
assign FIC_2_AXI4_S_AWPROT_const_net_0           = 3'h0;
assign FIC_2_AXI4_S_WDATA_const_net_0            = 64'h0000000000000000;
assign FIC_2_AXI4_S_WSTRB_const_net_0            = 8'hFF;
assign FIC_2_AXI4_S_ARID_const_net_0             = 4'h0;
assign FIC_2_AXI4_S_ARADDR_const_net_0           = 38'h0000000000;
assign FIC_2_AXI4_S_ARLEN_const_net_0            = 8'h00;
assign FIC_2_AXI4_S_ARSIZE_const_net_0           = 3'h0;
assign FIC_2_AXI4_S_ARBURST_const_net_0          = 2'h3;
assign FIC_2_AXI4_S_ARCACHE_const_net_0          = 4'h0;
assign FIC_2_AXI4_S_ARQOS_const_net_0            = 4'h0;
assign FIC_2_AXI4_S_ARPROT_const_net_0           = 3'h0;
assign MASTER0_AWREGION_const_net_0              = 4'h0;
assign MASTER0_ARREGION_const_net_0              = 4'h0;
assign AXI4mmaster0_MASTER0_AWREGION_const_net_0 = 4'h0;
assign AXI4mmaster0_MASTER0_ARREGION_const_net_0 = 4'h0;
assign PCIE_APB_SLAVE_APB_S_PADDR_const_net_0    = 26'h0000000;
assign PCIE_APB_SLAVE_APB_S_PWDATA_const_net_0   = 32'h00000000;
assign PLL0_SW_DRI_RDATA_const_net_0             = 33'h000000000;
//--------------------------------------------------------------------
// Inversions
//--------------------------------------------------------------------
assign USB_ULPI_RESET_net_1 = ~ USB_ULPI_RESET_OUT_PRE_INV0_0;
//--------------------------------------------------------------------
// TieOff assignments
//--------------------------------------------------------------------
assign VSC_8662_CMODE7                   = 1'b0;
assign VSC_8662_SRESET                   = 1'b1;
//--------------------------------------------------------------------
// Top level output port assignments
//--------------------------------------------------------------------
assign ACT_N_0_net_1                     = ACT_N_0_net_0;
assign ACT_N_0                           = ACT_N_0_net_1;
assign ACT_N_net_1                       = ACT_N_net_0;
assign ACT_N                             = ACT_N_net_1;
assign CAS_N_0_net_1                     = CAS_N_0_net_0;
assign CAS_N_0                           = CAS_N_0_net_1;
assign CAS_N_net_1                       = CAS_N_net_0;
assign CAS_N                             = CAS_N_net_1;
assign CK0_0_net_1                       = CK0_0_net_0;
assign CK0_0                             = CK0_0_net_1;
assign CK0_N_0_net_1                     = CK0_N_0_net_0;
assign CK0_N_0                           = CK0_N_0_net_1;
assign CK0_N_net_1                       = CK0_N_net_0;
assign CK0_N                             = CK0_N_net_1;
assign CK0_net_1                         = CK0_net_0;
assign CK0                               = CK0_net_1;
assign CKE0_net_1                        = CKE0_net_0;
assign CKE0                              = CKE0_net_1;
assign CKE_net_1                         = CKE_net_0;
assign CKE                               = CKE_net_1;
assign CS0_N_net_1                       = CS0_N_net_0;
assign CS0_N                             = CS0_N_net_1;
assign CS_N_net_1                        = CS_N_net_0;
assign CS_N                              = CS_N_net_1;
assign GPIO_1_23_OUT_net_1               = GPIO_1_23_OUT_net_0;
assign GPIO_1_23_OUT                     = GPIO_1_23_OUT_net_1;
assign MAC_1_MDC_net_1                   = MAC_1_MDC_net_0;
assign MAC_1_MDC                         = MAC_1_MDC_net_1;
assign MMUART_0_TXD_net_1                = MMUART_0_TXD_net_0;
assign MMUART_0_TXD                      = MMUART_0_TXD_net_1;
assign MMUART_1_TXD_M2F_net_1            = MMUART_1_TXD_M2F_net_0;
assign MMUART_1_TXD_M2F                  = MMUART_1_TXD_M2F_net_1;
assign MMUART_2_TXD_M2F_net_1            = MMUART_2_TXD_M2F_net_0;
assign MMUART_2_TXD_M2F                  = MMUART_2_TXD_M2F_net_1;
assign MMUART_3_TXD_M2F_net_1            = MMUART_3_TXD_M2F_net_0;
assign MMUART_3_TXD_M2F                  = MMUART_3_TXD_M2F_net_1;
assign ODT0_net_1                        = ODT0_net_0;
assign ODT0                              = ODT0_net_1;
assign ODT_net_1                         = ODT_net_0;
assign ODT                               = ODT_net_1;
assign PCIESS_LANE_TXD0_N_net_1          = PCIESS_LANE_TXD0_N_net_0;
assign PCIESS_LANE_TXD0_N                = PCIESS_LANE_TXD0_N_net_1;
assign PCIESS_LANE_TXD0_P_net_1          = PCIESS_LANE_TXD0_P_net_0;
assign PCIESS_LANE_TXD0_P                = PCIESS_LANE_TXD0_P_net_1;
assign PCIESS_LANE_TXD1_N_net_1          = PCIESS_LANE_TXD1_N_net_0;
assign PCIESS_LANE_TXD1_N                = PCIESS_LANE_TXD1_N_net_1;
assign PCIESS_LANE_TXD1_P_net_1          = PCIESS_LANE_TXD1_P_net_0;
assign PCIESS_LANE_TXD1_P                = PCIESS_LANE_TXD1_P_net_1;
assign PCIESS_LANE_TXD2_N_net_1          = PCIESS_LANE_TXD2_N_net_0;
assign PCIESS_LANE_TXD2_N                = PCIESS_LANE_TXD2_N_net_1;
assign PCIESS_LANE_TXD2_P_net_1          = PCIESS_LANE_TXD2_P_net_0;
assign PCIESS_LANE_TXD2_P                = PCIESS_LANE_TXD2_P_net_1;
assign PCIESS_LANE_TXD3_N_net_1          = PCIESS_LANE_TXD3_N_net_0;
assign PCIESS_LANE_TXD3_N                = PCIESS_LANE_TXD3_N_net_1;
assign PCIESS_LANE_TXD3_P_net_1          = PCIESS_LANE_TXD3_P_net_0;
assign PCIESS_LANE_TXD3_P                = PCIESS_LANE_TXD3_P_net_1;
assign PCIE_1_PERST_N_net_1              = PCIE_1_PERST_N_net_0;
assign PCIE_1_PERST_N                    = PCIE_1_PERST_N_net_1;
assign RAS_N_0_net_1                     = RAS_N_0_net_0;
assign RAS_N_0                           = RAS_N_0_net_1;
assign RAS_N_net_1                       = RAS_N_net_0;
assign RAS_N                             = RAS_N_net_1;
assign RESET_N_0_net_1                   = RESET_N_0_net_0;
assign RESET_N_0                         = RESET_N_0_net_1;
assign RESET_N_net_1                     = RESET_N_net_0;
assign RESET_N                           = RESET_N_net_1;
assign SD_CLK_EMMC_CLK_net_1             = SD_CLK_EMMC_CLK_net_0;
assign SD_CLK_EMMC_CLK                   = SD_CLK_EMMC_CLK_net_1;
assign SD_POW_EMMC_DATA4_net_1           = SD_POW_EMMC_DATA4_net_0;
assign SD_POW_EMMC_DATA4                 = SD_POW_EMMC_DATA4_net_1;
assign SD_SEL_net_1                      = SD_SEL_net_0;
assign SD_SEL                            = SD_SEL_net_1;
assign SD_VOLT_CMD_DIR_EMMC_DATA7_net_1  = SD_VOLT_CMD_DIR_EMMC_DATA7_net_0;
assign SD_VOLT_CMD_DIR_EMMC_DATA7        = SD_VOLT_CMD_DIR_EMMC_DATA7_net_1;
assign SD_VOLT_DIR_0_EMMC_UNUSED_net_1   = SD_VOLT_DIR_0_EMMC_UNUSED_net_0;
assign SD_VOLT_DIR_0_EMMC_UNUSED         = SD_VOLT_DIR_0_EMMC_UNUSED_net_1;
assign SD_VOLT_DIR_1_3_EMMC_UNUSED_net_1 = SD_VOLT_DIR_1_3_EMMC_UNUSED_net_0;
assign SD_VOLT_DIR_1_3_EMMC_UNUSED       = SD_VOLT_DIR_1_3_EMMC_UNUSED_net_1;
assign SD_VOLT_EN_EMMC_DATA6_net_1       = SD_VOLT_EN_EMMC_DATA6_net_0;
assign SD_VOLT_EN_EMMC_DATA6             = SD_VOLT_EN_EMMC_DATA6_net_1;
assign SD_VOLT_SEL_EMMC_DATA5_net_1      = SD_VOLT_SEL_EMMC_DATA5_net_0;
assign SD_VOLT_SEL_EMMC_DATA5            = SD_VOLT_SEL_EMMC_DATA5_net_1;
assign SGMII_TX0_N_net_1                 = SGMII_TX0_N_net_0;
assign SGMII_TX0_N                       = SGMII_TX0_N_net_1;
assign SGMII_TX0_P_net_1                 = SGMII_TX0_P_net_0;
assign SGMII_TX0_P                       = SGMII_TX0_P_net_1;
assign SGMII_TX1_N_net_1                 = SGMII_TX1_N_net_0;
assign SGMII_TX1_N                       = SGMII_TX1_N_net_1;
assign SGMII_TX1_P_net_1                 = SGMII_TX1_P_net_0;
assign SGMII_TX1_P                       = SGMII_TX1_P_net_1;
assign SHIELD0_net_1                     = SHIELD0_net_0;
assign SHIELD0                           = SHIELD0_net_1;
assign SHIELD1_net_1                     = SHIELD1_net_0;
assign SHIELD1                           = SHIELD1_net_1;
assign SHIELD2_net_1                     = SHIELD2_net_0;
assign SHIELD2                           = SHIELD2_net_1;
assign SHIELD3_net_1                     = SHIELD3_net_0;
assign SHIELD3                           = SHIELD3_net_1;
assign SPI_1_DO_net_1                    = SPI_1_DO_net_0;
assign SPI_1_DO                          = SPI_1_DO_net_1;
assign USB_STP_net_1                     = USB_STP_net_0;
assign USB_STP                           = USB_STP_net_1;
assign USB_ULPI_RESET_OUT_PRE_INV0_0     = USB_ULPI_RESET_net_0;
assign USB_ULPI_RESET                    = USB_ULPI_RESET_net_1;
assign USB_ULPI_RESET_net_2              = USB_ULPI_RESET_net_0;
assign VSC_8662_RESETN                   = USB_ULPI_RESET_net_2;
assign WE_N_0_net_1                      = WE_N_0_net_0;
assign WE_N_0                            = WE_N_0_net_1;
assign WE_N_net_1                        = WE_N_net_0;
assign WE_N                              = WE_N_net_1;
assign A_0_net_1                         = A_0_net_0;
assign A_0[13:0]                         = A_0_net_1;
assign A_net_1                           = A_net_0;
assign A[13:0]                           = A_net_1;
assign BA_0_net_1                        = BA_0_net_0;
assign BA_0[1:0]                         = BA_0_net_1;
assign BA_net_1                          = BA_net_0;
assign BA[1:0]                           = BA_net_1;
assign BG_0_net_1                        = BG_0_net_0;
assign BG_0[1:0]                         = BG_0_net_1;
assign BG_net_1                          = BG_net_0;
assign BG[1:0]                           = BG_net_1;
assign DM_N_net_1                        = DM_N_net_0;
assign DM_N[3:0]                         = DM_N_net_1;
//--------------------------------------------------------------------
// Concatenation assignments
//--------------------------------------------------------------------
assign MSS_INT_F2M_net_0 = { 1'b0 , 1'b0 , 1'b0 , 1'b0 , 1'b0 , 55'h00000000000000 , 1'b0 , 1'b0 , FIC_1_PERIPHERALS_1_PCIe_IRQ , 1'b0 };
//--------------------------------------------------------------------
// Bus Interface Nets Assignments - Unequal Pin Widths
//--------------------------------------------------------------------
assign ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARADDR_0 = { ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARADDR_0_31to0 };
assign ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARADDR_0_31to0 = ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARADDR[31:0];

assign ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARLOCK_0 = { ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARLOCK_0_1to1, ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARLOCK_0_0to0 };
assign ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARLOCK_0_0to0 = ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARLOCK;
assign ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARLOCK_0_1to1 = 1'b0;

assign ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWADDR_0 = { ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWADDR_0_31to0 };
assign ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWADDR_0_31to0 = ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWADDR[31:0];

assign ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWLOCK_0 = { ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWLOCK_0_1to1, ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWLOCK_0_0to0 };
assign ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWLOCK_0_0to0 = ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWLOCK;
assign ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWLOCK_0_1to1 = 1'b0;

assign ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARLOCK_0 = { ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARLOCK_0_1to1, ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARLOCK_0_0to0 };
assign ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARLOCK_0_0to0 = ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARLOCK;
assign ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARLOCK_0_1to1 = 1'b0;

assign ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWLOCK_0 = { ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWLOCK_0_1to1, ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWLOCK_0_0to0 };
assign ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWLOCK_0_0to0 = ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWLOCK;
assign ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWLOCK_0_1to1 = 1'b0;

assign DDR4_INITIATOR_0_AXI4mslave0_ARID_0 = { DDR4_INITIATOR_0_AXI4mslave0_ARID_0_7to0 };
assign DDR4_INITIATOR_0_AXI4mslave0_ARID_0_7to0 = DDR4_INITIATOR_0_AXI4mslave0_ARID[7:0];

assign DDR4_INITIATOR_0_AXI4mslave0_AWID_0 = { DDR4_INITIATOR_0_AXI4mslave0_AWID_0_7to0 };
assign DDR4_INITIATOR_0_AXI4mslave0_AWID_0_7to0 = DDR4_INITIATOR_0_AXI4mslave0_AWID[7:0];

assign DDR4_INITIATOR_0_AXI4mslave0_BID_0 = { DDR4_INITIATOR_0_AXI4mslave0_BID_0_8to8, DDR4_INITIATOR_0_AXI4mslave0_BID_0_7to0 };
assign DDR4_INITIATOR_0_AXI4mslave0_BID_0_7to0 = DDR4_INITIATOR_0_AXI4mslave0_BID[7:0];
assign DDR4_INITIATOR_0_AXI4mslave0_BID_0_8to8 = 1'b0;

assign DDR4_INITIATOR_0_AXI4mslave0_RID_0 = { DDR4_INITIATOR_0_AXI4mslave0_RID_0_8to8, DDR4_INITIATOR_0_AXI4mslave0_RID_0_7to0 };
assign DDR4_INITIATOR_0_AXI4mslave0_RID_0_7to0 = DDR4_INITIATOR_0_AXI4mslave0_RID[7:0];
assign DDR4_INITIATOR_0_AXI4mslave0_RID_0_8to8 = 1'b0;

assign FIC_1_PERIPHERALS_1_AXI4mslave0_ARID_0 = { FIC_1_PERIPHERALS_1_AXI4mslave0_ARID_0_3to0 };
assign FIC_1_PERIPHERALS_1_AXI4mslave0_ARID_0_3to0 = FIC_1_PERIPHERALS_1_AXI4mslave0_ARID[3:0];

assign FIC_1_PERIPHERALS_1_AXI4mslave0_ARLOCK_0 = { FIC_1_PERIPHERALS_1_AXI4mslave0_ARLOCK_0_0to0 };
assign FIC_1_PERIPHERALS_1_AXI4mslave0_ARLOCK_0_0to0 = FIC_1_PERIPHERALS_1_AXI4mslave0_ARLOCK[0:0];

assign FIC_1_PERIPHERALS_1_AXI4mslave0_AWID_0 = { FIC_1_PERIPHERALS_1_AXI4mslave0_AWID_0_3to0 };
assign FIC_1_PERIPHERALS_1_AXI4mslave0_AWID_0_3to0 = FIC_1_PERIPHERALS_1_AXI4mslave0_AWID[3:0];

assign FIC_1_PERIPHERALS_1_AXI4mslave0_AWLOCK_0 = { FIC_1_PERIPHERALS_1_AXI4mslave0_AWLOCK_0_0to0 };
assign FIC_1_PERIPHERALS_1_AXI4mslave0_AWLOCK_0_0to0 = FIC_1_PERIPHERALS_1_AXI4mslave0_AWLOCK[0:0];

assign FIC_1_PERIPHERALS_1_AXI4mslave0_BID_0 = { FIC_1_PERIPHERALS_1_AXI4mslave0_BID_0_4to4, FIC_1_PERIPHERALS_1_AXI4mslave0_BID_0_3to0 };
assign FIC_1_PERIPHERALS_1_AXI4mslave0_BID_0_3to0 = FIC_1_PERIPHERALS_1_AXI4mslave0_BID[3:0];
assign FIC_1_PERIPHERALS_1_AXI4mslave0_BID_0_4to4 = 1'b0;

assign FIC_1_PERIPHERALS_1_AXI4mslave0_RID_0 = { FIC_1_PERIPHERALS_1_AXI4mslave0_RID_0_4to4, FIC_1_PERIPHERALS_1_AXI4mslave0_RID_0_3to0 };
assign FIC_1_PERIPHERALS_1_AXI4mslave0_RID_0_3to0 = FIC_1_PERIPHERALS_1_AXI4mslave0_RID[3:0];
assign FIC_1_PERIPHERALS_1_AXI4mslave0_RID_0_4to4 = 1'b0;

//--------------------------------------------------------------------
// Component instances
//--------------------------------------------------------------------
//--------TySOM_M_PCIe_2024_9
TySOM_M_PCIe_2024_9 ALDEC_MSS_2024_9(
        // Inputs
        .FIC_0_ACLK                   ( CLOCKS_AND_RESETS_FIC_0_CLK ),
        .FIC_0_AXI4_M_AWREADY         ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWREADY ),
        .FIC_0_AXI4_M_WREADY          ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_WREADY ),
        .FIC_0_AXI4_M_BID             ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_BID ),
        .FIC_0_AXI4_M_BRESP           ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_BRESP ),
        .FIC_0_AXI4_M_BVALID          ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_BVALID ),
        .FIC_0_AXI4_M_ARREADY         ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARREADY ),
        .FIC_0_AXI4_M_RID             ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RID ),
        .FIC_0_AXI4_M_RDATA           ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RDATA ),
        .FIC_0_AXI4_M_RRESP           ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RRESP ),
        .FIC_0_AXI4_M_RLAST           ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RLAST ),
        .FIC_0_AXI4_M_RVALID          ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RVALID ),
        .FIC_0_AXI4_S_AWID            ( FIC_0_AXI4_S_AWID_const_net_0 ), // tied to 4'h0 from definition
        .FIC_0_AXI4_S_AWADDR          ( FIC_0_AXI4_S_AWADDR_const_net_0 ), // tied to 38'h0000000000 from definition
        .FIC_0_AXI4_S_AWLEN           ( FIC_0_AXI4_S_AWLEN_const_net_0 ), // tied to 8'h00 from definition
        .FIC_0_AXI4_S_AWSIZE          ( FIC_0_AXI4_S_AWSIZE_const_net_0 ), // tied to 3'h0 from definition
        .FIC_0_AXI4_S_AWBURST         ( FIC_0_AXI4_S_AWBURST_const_net_0 ), // tied to 2'h3 from definition
        .FIC_0_AXI4_S_AWQOS           ( FIC_0_AXI4_S_AWQOS_const_net_0 ), // tied to 4'h0 from definition
        .FIC_0_AXI4_S_AWLOCK          ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_S_AWCACHE         ( FIC_0_AXI4_S_AWCACHE_const_net_0 ), // tied to 4'h0 from definition
        .FIC_0_AXI4_S_AWPROT          ( FIC_0_AXI4_S_AWPROT_const_net_0 ), // tied to 3'h0 from definition
        .FIC_0_AXI4_S_AWVALID         ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_S_WDATA           ( FIC_0_AXI4_S_WDATA_const_net_0 ), // tied to 64'h0000000000000000 from definition
        .FIC_0_AXI4_S_WSTRB           ( FIC_0_AXI4_S_WSTRB_const_net_0 ), // tied to 8'hFF from definition
        .FIC_0_AXI4_S_WLAST           ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_S_WVALID          ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_S_BREADY          ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_S_ARID            ( FIC_0_AXI4_S_ARID_const_net_0 ), // tied to 4'h0 from definition
        .FIC_0_AXI4_S_ARADDR          ( FIC_0_AXI4_S_ARADDR_const_net_0 ), // tied to 38'h0000000000 from definition
        .FIC_0_AXI4_S_ARLEN           ( FIC_0_AXI4_S_ARLEN_const_net_0 ), // tied to 8'h00 from definition
        .FIC_0_AXI4_S_ARSIZE          ( FIC_0_AXI4_S_ARSIZE_const_net_0 ), // tied to 3'h0 from definition
        .FIC_0_AXI4_S_ARBURST         ( FIC_0_AXI4_S_ARBURST_const_net_0 ), // tied to 2'h3 from definition
        .FIC_0_AXI4_S_ARQOS           ( FIC_0_AXI4_S_ARQOS_const_net_0 ), // tied to 4'h0 from definition
        .FIC_0_AXI4_S_ARLOCK          ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_S_ARCACHE         ( FIC_0_AXI4_S_ARCACHE_const_net_0 ), // tied to 4'h0 from definition
        .FIC_0_AXI4_S_ARPROT          ( FIC_0_AXI4_S_ARPROT_const_net_0 ), // tied to 3'h0 from definition
        .FIC_0_AXI4_S_ARVALID         ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_S_RREADY          ( GND_net ), // tied to 1'b0 from definition
        .FIC_1_ACLK                   ( CLOCKS_AND_RESETS_FIC_1_CLK ),
        .FIC_1_AXI4_M_AWREADY         ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWREADY ),
        .FIC_1_AXI4_M_WREADY          ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_WREADY ),
        .FIC_1_AXI4_M_BID             ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_BID ),
        .FIC_1_AXI4_M_BRESP           ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_BRESP ),
        .FIC_1_AXI4_M_BVALID          ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_BVALID ),
        .FIC_1_AXI4_M_ARREADY         ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARREADY ),
        .FIC_1_AXI4_M_RID             ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RID ),
        .FIC_1_AXI4_M_RDATA           ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RDATA ),
        .FIC_1_AXI4_M_RRESP           ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RRESP ),
        .FIC_1_AXI4_M_RLAST           ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RLAST ),
        .FIC_1_AXI4_M_RVALID          ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RVALID ),
        .FIC_1_AXI4_S_AWID            ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWID_0 ),
        .FIC_1_AXI4_S_AWADDR          ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWADDR ),
        .FIC_1_AXI4_S_AWLEN           ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWLEN ),
        .FIC_1_AXI4_S_AWSIZE          ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWSIZE ),
        .FIC_1_AXI4_S_AWBURST         ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWBURST ),
        .FIC_1_AXI4_S_AWLOCK          ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWLOCK_0 ),
        .FIC_1_AXI4_S_AWCACHE         ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWCACHE ),
        .FIC_1_AXI4_S_AWQOS           ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWQOS ),
        .FIC_1_AXI4_S_AWPROT          ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWPROT ),
        .FIC_1_AXI4_S_AWVALID         ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWVALID ),
        .FIC_1_AXI4_S_WDATA           ( FIC_1_PERIPHERALS_1_AXI4mslave0_WDATA ),
        .FIC_1_AXI4_S_WSTRB           ( FIC_1_PERIPHERALS_1_AXI4mslave0_WSTRB ),
        .FIC_1_AXI4_S_WLAST           ( FIC_1_PERIPHERALS_1_AXI4mslave0_WLAST ),
        .FIC_1_AXI4_S_WVALID          ( FIC_1_PERIPHERALS_1_AXI4mslave0_WVALID ),
        .FIC_1_AXI4_S_BREADY          ( FIC_1_PERIPHERALS_1_AXI4mslave0_BREADY ),
        .FIC_1_AXI4_S_ARID            ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARID_0 ),
        .FIC_1_AXI4_S_ARADDR          ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARADDR ),
        .FIC_1_AXI4_S_ARLEN           ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARLEN ),
        .FIC_1_AXI4_S_ARSIZE          ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARSIZE ),
        .FIC_1_AXI4_S_ARBURST         ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARBURST ),
        .FIC_1_AXI4_S_ARQOS           ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARQOS ),
        .FIC_1_AXI4_S_ARLOCK          ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARLOCK_0 ),
        .FIC_1_AXI4_S_ARCACHE         ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARCACHE ),
        .FIC_1_AXI4_S_ARPROT          ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARPROT ),
        .FIC_1_AXI4_S_ARVALID         ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARVALID ),
        .FIC_1_AXI4_S_RREADY          ( FIC_1_PERIPHERALS_1_AXI4mslave0_RREADY ),
        .FIC_2_ACLK                   ( CLOCKS_AND_RESETS_FIC_2_CLK ),
        .FIC_2_AXI4_S_AWID            ( FIC_2_AXI4_S_AWID_const_net_0 ), // tied to 4'h0 from definition
        .FIC_2_AXI4_S_AWADDR          ( FIC_2_AXI4_S_AWADDR_const_net_0 ), // tied to 38'h0000000000 from definition
        .FIC_2_AXI4_S_AWLEN           ( FIC_2_AXI4_S_AWLEN_const_net_0 ), // tied to 8'h00 from definition
        .FIC_2_AXI4_S_AWSIZE          ( FIC_2_AXI4_S_AWSIZE_const_net_0 ), // tied to 3'h0 from definition
        .FIC_2_AXI4_S_AWBURST         ( FIC_2_AXI4_S_AWBURST_const_net_0 ), // tied to 2'h3 from definition
        .FIC_2_AXI4_S_AWLOCK          ( GND_net ), // tied to 1'b0 from definition
        .FIC_2_AXI4_S_AWCACHE         ( FIC_2_AXI4_S_AWCACHE_const_net_0 ), // tied to 4'h0 from definition
        .FIC_2_AXI4_S_AWQOS           ( FIC_2_AXI4_S_AWQOS_const_net_0 ), // tied to 4'h0 from definition
        .FIC_2_AXI4_S_AWPROT          ( FIC_2_AXI4_S_AWPROT_const_net_0 ), // tied to 3'h0 from definition
        .FIC_2_AXI4_S_AWVALID         ( GND_net ), // tied to 1'b0 from definition
        .FIC_2_AXI4_S_WDATA           ( FIC_2_AXI4_S_WDATA_const_net_0 ), // tied to 64'h0000000000000000 from definition
        .FIC_2_AXI4_S_WSTRB           ( FIC_2_AXI4_S_WSTRB_const_net_0 ), // tied to 8'hFF from definition
        .FIC_2_AXI4_S_WLAST           ( GND_net ), // tied to 1'b0 from definition
        .FIC_2_AXI4_S_WVALID          ( GND_net ), // tied to 1'b0 from definition
        .FIC_2_AXI4_S_BREADY          ( GND_net ), // tied to 1'b0 from definition
        .FIC_2_AXI4_S_ARID            ( FIC_2_AXI4_S_ARID_const_net_0 ), // tied to 4'h0 from definition
        .FIC_2_AXI4_S_ARADDR          ( FIC_2_AXI4_S_ARADDR_const_net_0 ), // tied to 38'h0000000000 from definition
        .FIC_2_AXI4_S_ARLEN           ( FIC_2_AXI4_S_ARLEN_const_net_0 ), // tied to 8'h00 from definition
        .FIC_2_AXI4_S_ARSIZE          ( FIC_2_AXI4_S_ARSIZE_const_net_0 ), // tied to 3'h0 from definition
        .FIC_2_AXI4_S_ARBURST         ( FIC_2_AXI4_S_ARBURST_const_net_0 ), // tied to 2'h3 from definition
        .FIC_2_AXI4_S_ARLOCK          ( GND_net ), // tied to 1'b0 from definition
        .FIC_2_AXI4_S_ARCACHE         ( FIC_2_AXI4_S_ARCACHE_const_net_0 ), // tied to 4'h0 from definition
        .FIC_2_AXI4_S_ARQOS           ( FIC_2_AXI4_S_ARQOS_const_net_0 ), // tied to 4'h0 from definition
        .FIC_2_AXI4_S_ARPROT          ( FIC_2_AXI4_S_ARPROT_const_net_0 ), // tied to 3'h0 from definition
        .FIC_2_AXI4_S_ARVALID         ( GND_net ), // tied to 1'b0 from definition
        .FIC_2_AXI4_S_RREADY          ( GND_net ), // tied to 1'b0 from definition
        .FIC_3_PCLK                   ( CLOCKS_AND_RESETS_FIC_3_CLK ),
        .FIC_3_APB_M_PRDATA           ( ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PRDATA ),
        .FIC_3_APB_M_PREADY           ( ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PREADY ),
        .FIC_3_APB_M_PSLVERR          ( ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PSLVERR ),
        .MMUART_1_RXD_F2M             ( MMUART_1_RXD_F2M ),
        .MMUART_2_RXD_F2M             ( MMUART_2_RXD_F2M ),
        .MMUART_3_RXD_F2M             ( MMUART_3_RXD_F2M ),
        .MMUART_4_RXD_F2M             ( ALDEC_MSS_2024_9_MMUART_4_TXD_M2F ),
        .CAN_0_RXBUS_F2M              ( GND_net ),
        .CAN_1_RXBUS_F2M              ( GND_net ),
        .QSPI_DATA_F2M                ( QSPI_DATA_F2M_const_net_0 ),
        .I2C_0_SCL_F2M                ( BIBUF_I2C0_SCL_Y ),
        .I2C_0_SDA_F2M                ( BIBUF_I2C0_SDA_Y ),
        .MSS_INT_F2M                  ( MSS_INT_F2M_net_0 ),
        .MSS_RESET_N_F2M              ( CLOCKS_AND_RESETS_RESETN_FIC_0_CLK ),
        .MMUART_0_RXD                 ( MMUART_0_RXD ),
        .GPIO_1_20_IN                 ( GPIO_1_20_IN ),
        .USB_CLK                      ( USB_CLK ),
        .USB_DIR                      ( USB_DIR ),
        .USB_NXT                      ( USB_NXT ),
        .SPI_1_DI                     ( SPI_1_DI ),
        .SD_CD_EMMC_STRB              ( SD_CD_EMMC_STRB ),
        .SD_WP_EMMC_RSTN              ( SD_WP_EMMC_RSTN ),
        .SGMII_RX1_P                  ( SGMII_RX1_P ),
        .SGMII_RX1_N                  ( SGMII_RX1_N ),
        .SGMII_RX0_P                  ( SGMII_RX0_P ),
        .SGMII_RX0_N                  ( SGMII_RX0_N ),
        .REFCLK                       ( REFCLK ),
        .REFCLK_N                     ( REFCLK_N ),
        // Outputs
        .FIC_0_DLL_LOCK_M2F           ( ALDEC_MSS_2024_9_FIC_0_DLL_LOCK_M2F ),
        .FIC_1_DLL_LOCK_M2F           ( ALDEC_MSS_2024_9_FIC_1_DLL_LOCK_M2F ),
        .FIC_2_DLL_LOCK_M2F           ( ALDEC_MSS_2024_9_FIC_2_DLL_LOCK_M2F ),
        .FIC_3_DLL_LOCK_M2F           ( ALDEC_MSS_2024_9_FIC_3_DLL_LOCK_M2F ),
        .FIC_0_AXI4_M_AWID            ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWID ),
        .FIC_0_AXI4_M_AWADDR          ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWADDR ),
        .FIC_0_AXI4_M_AWLEN           ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWLEN ),
        .FIC_0_AXI4_M_AWSIZE          ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWSIZE ),
        .FIC_0_AXI4_M_AWBURST         ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWBURST ),
        .FIC_0_AXI4_M_AWLOCK          ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWLOCK ),
        .FIC_0_AXI4_M_AWQOS           ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWQOS ),
        .FIC_0_AXI4_M_AWCACHE         ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWCACHE ),
        .FIC_0_AXI4_M_AWPROT          ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWPROT ),
        .FIC_0_AXI4_M_AWVALID         ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWVALID ),
        .FIC_0_AXI4_M_WDATA           ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_WDATA ),
        .FIC_0_AXI4_M_WSTRB           ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_WSTRB ),
        .FIC_0_AXI4_M_WLAST           ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_WLAST ),
        .FIC_0_AXI4_M_WVALID          ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_WVALID ),
        .FIC_0_AXI4_M_BREADY          ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_BREADY ),
        .FIC_0_AXI4_M_ARID            ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARID ),
        .FIC_0_AXI4_M_ARADDR          ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARADDR ),
        .FIC_0_AXI4_M_ARLEN           ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARLEN ),
        .FIC_0_AXI4_M_ARSIZE          ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARSIZE ),
        .FIC_0_AXI4_M_ARBURST         ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARBURST ),
        .FIC_0_AXI4_M_ARLOCK          ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARLOCK ),
        .FIC_0_AXI4_M_ARQOS           ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARQOS ),
        .FIC_0_AXI4_M_ARCACHE         ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARCACHE ),
        .FIC_0_AXI4_M_ARPROT          ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARPROT ),
        .FIC_0_AXI4_M_ARVALID         ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARVALID ),
        .FIC_0_AXI4_M_RREADY          ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RREADY ),
        .FIC_0_AXI4_S_AWREADY         (  ),
        .FIC_0_AXI4_S_WREADY          (  ),
        .FIC_0_AXI4_S_BID             (  ),
        .FIC_0_AXI4_S_BRESP           (  ),
        .FIC_0_AXI4_S_BVALID          (  ),
        .FIC_0_AXI4_S_ARREADY         (  ),
        .FIC_0_AXI4_S_RID             (  ),
        .FIC_0_AXI4_S_RDATA           (  ),
        .FIC_0_AXI4_S_RRESP           (  ),
        .FIC_0_AXI4_S_RLAST           (  ),
        .FIC_0_AXI4_S_RVALID          (  ),
        .FIC_1_AXI4_M_AWID            ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWID ),
        .FIC_1_AXI4_M_AWADDR          ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWADDR ),
        .FIC_1_AXI4_M_AWLEN           ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWLEN ),
        .FIC_1_AXI4_M_AWSIZE          ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWSIZE ),
        .FIC_1_AXI4_M_AWBURST         ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWBURST ),
        .FIC_1_AXI4_M_AWLOCK          ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWLOCK ),
        .FIC_1_AXI4_M_AWQOS           ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWQOS ),
        .FIC_1_AXI4_M_AWCACHE         ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWCACHE ),
        .FIC_1_AXI4_M_AWPROT          ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWPROT ),
        .FIC_1_AXI4_M_AWVALID         ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWVALID ),
        .FIC_1_AXI4_M_WDATA           ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_WDATA ),
        .FIC_1_AXI4_M_WSTRB           ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_WSTRB ),
        .FIC_1_AXI4_M_WLAST           ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_WLAST ),
        .FIC_1_AXI4_M_WVALID          ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_WVALID ),
        .FIC_1_AXI4_M_BREADY          ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_BREADY ),
        .FIC_1_AXI4_M_ARID            ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARID ),
        .FIC_1_AXI4_M_ARADDR          ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARADDR ),
        .FIC_1_AXI4_M_ARLEN           ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARLEN ),
        .FIC_1_AXI4_M_ARSIZE          ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARSIZE ),
        .FIC_1_AXI4_M_ARBURST         ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARBURST ),
        .FIC_1_AXI4_M_ARLOCK          ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARLOCK ),
        .FIC_1_AXI4_M_ARQOS           ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARQOS ),
        .FIC_1_AXI4_M_ARCACHE         ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARCACHE ),
        .FIC_1_AXI4_M_ARPROT          ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARPROT ),
        .FIC_1_AXI4_M_ARVALID         ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARVALID ),
        .FIC_1_AXI4_M_RREADY          ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RREADY ),
        .FIC_1_AXI4_S_AWREADY         ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWREADY ),
        .FIC_1_AXI4_S_WREADY          ( FIC_1_PERIPHERALS_1_AXI4mslave0_WREADY ),
        .FIC_1_AXI4_S_BID             ( FIC_1_PERIPHERALS_1_AXI4mslave0_BID ),
        .FIC_1_AXI4_S_BRESP           ( FIC_1_PERIPHERALS_1_AXI4mslave0_BRESP ),
        .FIC_1_AXI4_S_BVALID          ( FIC_1_PERIPHERALS_1_AXI4mslave0_BVALID ),
        .FIC_1_AXI4_S_ARREADY         ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARREADY ),
        .FIC_1_AXI4_S_RID             ( FIC_1_PERIPHERALS_1_AXI4mslave0_RID ),
        .FIC_1_AXI4_S_RDATA           ( FIC_1_PERIPHERALS_1_AXI4mslave0_RDATA ),
        .FIC_1_AXI4_S_RRESP           ( FIC_1_PERIPHERALS_1_AXI4mslave0_RRESP ),
        .FIC_1_AXI4_S_RLAST           ( FIC_1_PERIPHERALS_1_AXI4mslave0_RLAST ),
        .FIC_1_AXI4_S_RVALID          ( FIC_1_PERIPHERALS_1_AXI4mslave0_RVALID ),
        .FIC_2_AXI4_S_AWREADY         (  ),
        .FIC_2_AXI4_S_WREADY          (  ),
        .FIC_2_AXI4_S_BID             (  ),
        .FIC_2_AXI4_S_BRESP           (  ),
        .FIC_2_AXI4_S_BVALID          (  ),
        .FIC_2_AXI4_S_ARREADY         (  ),
        .FIC_2_AXI4_S_RID             (  ),
        .FIC_2_AXI4_S_RDATA           (  ),
        .FIC_2_AXI4_S_RRESP           (  ),
        .FIC_2_AXI4_S_RLAST           (  ),
        .FIC_2_AXI4_S_RVALID          (  ),
        .FIC_3_APB_M_PSEL             ( ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PSELx ),
        .FIC_3_APB_M_PADDR            ( ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PADDR ),
        .FIC_3_APB_M_PWRITE           ( ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PWRITE ),
        .FIC_3_APB_M_PENABLE          ( ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PENABLE ),
        .FIC_3_APB_M_PSTRB            ( ALDEC_MSS_2024_9_FIC_3_APB_M_PSTRB ),
        .FIC_3_APB_M_PWDATA           ( ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PWDATA ),
        .MMUART_1_TXD_M2F             ( MMUART_1_TXD_M2F_net_0 ),
        .MMUART_1_TXD_OE_M2F          (  ),
        .MMUART_2_TXD_M2F             ( MMUART_2_TXD_M2F_net_0 ),
        .MMUART_3_TXD_M2F             ( MMUART_3_TXD_M2F_net_0 ),
        .MMUART_4_TXD_M2F             ( ALDEC_MSS_2024_9_MMUART_4_TXD_M2F ),
        .CAN_0_TX_EBL_M2F             (  ),
        .CAN_0_TXBUS_M2F              (  ),
        .CAN_1_TX_EBL_M2F             (  ),
        .CAN_1_TXBUS_M2F              (  ),
        .QSPI_SEL_M2F                 (  ),
        .QSPI_SEL_OE_M2F              (  ),
        .QSPI_DATA_M2F                (  ),
        .QSPI_DATA_OE_M2F             (  ),
        .I2C_0_SCL_OE_M2F             ( ALDEC_MSS_2024_9_I2C_0_SCL_OE_M2F ),
        .I2C_0_SDA_OE_M2F             ( ALDEC_MSS_2024_9_I2C_0_SDA_OE_M2F ),
        .MSS_INT_M2F                  (  ),
        .PLL_CPU_LOCK_M2F             (  ),
        .PLL_DDR_LOCK_M2F             (  ),
        .PLL_SGMII_LOCK_M2F           (  ),
        .MSS_RESET_N_M2F              ( USB_ULPI_RESET_net_0 ),
        .MAC_0_TSU_SOF_TX_M2F         (  ),
        .MAC_0_TSU_SYNC_FRAME_TX_M2F  (  ),
        .MAC_0_TSU_DELAY_REQ_TX_M2F   (  ),
        .MAC_0_TSU_PDELAY_REQ_TX_M2F  (  ),
        .MAC_0_TSU_PDELAY_RESP_TX_M2F (  ),
        .MAC_0_TSU_SOF_RX_M2F         (  ),
        .MAC_0_TSU_SYNC_FRAME_RX_M2F  (  ),
        .MAC_0_TSU_DELAY_REQ_RX_M2F   (  ),
        .MAC_0_TSU_PDELAY_REQ_RX_M2F  (  ),
        .MAC_0_TSU_PDELAY_RESP_RX_M2F (  ),
        .MAC_0_TSU_TIMER_CNT_M2F      (  ),
        .MAC_1_TSU_SOF_TX_M2F         (  ),
        .MAC_1_TSU_SYNC_FRAME_TX_M2F  (  ),
        .MAC_1_TSU_DELAY_REQ_TX_M2F   (  ),
        .MAC_1_TSU_PDELAY_REQ_TX_M2F  (  ),
        .MAC_1_TSU_PDELAY_RESP_TX_M2F (  ),
        .MAC_1_TSU_SOF_RX_M2F         (  ),
        .MAC_1_TSU_SYNC_FRAME_RX_M2F  (  ),
        .MAC_1_TSU_DELAY_REQ_RX_M2F   (  ),
        .MAC_1_TSU_PDELAY_REQ_RX_M2F  (  ),
        .MAC_1_TSU_PDELAY_RESP_RX_M2F (  ),
        .MAC_1_TSU_TIMER_CNT_M2F      (  ),
        .MMUART_0_TXD                 ( MMUART_0_TXD_net_0 ),
        .MAC_1_MDC                    ( MAC_1_MDC_net_0 ),
        .GPIO_1_23_OUT                ( GPIO_1_23_OUT_net_0 ),
        .USB_STP                      ( USB_STP_net_0 ),
        .SPI_1_DO                     ( SPI_1_DO_net_0 ),
        .SD_CLK_EMMC_CLK              ( SD_CLK_EMMC_CLK_net_0 ),
        .SD_POW_EMMC_DATA4            ( SD_POW_EMMC_DATA4_net_0 ),
        .SD_VOLT_SEL_EMMC_DATA5       ( SD_VOLT_SEL_EMMC_DATA5_net_0 ),
        .SD_VOLT_EN_EMMC_DATA6        ( SD_VOLT_EN_EMMC_DATA6_net_0 ),
        .SD_VOLT_CMD_DIR_EMMC_DATA7   ( SD_VOLT_CMD_DIR_EMMC_DATA7_net_0 ),
        .SD_VOLT_DIR_0_EMMC_UNUSED    ( SD_VOLT_DIR_0_EMMC_UNUSED_net_0 ),
        .SD_VOLT_DIR_1_3_EMMC_UNUSED  ( SD_VOLT_DIR_1_3_EMMC_UNUSED_net_0 ),
        .SGMII_TX1_P                  ( SGMII_TX1_P_net_0 ),
        .SGMII_TX1_N                  ( SGMII_TX1_N_net_0 ),
        .SGMII_TX0_P                  ( SGMII_TX0_P_net_0 ),
        .SGMII_TX0_N                  ( SGMII_TX0_N_net_0 ),
        .BA                           ( BA_net_0 ),
        .A                            ( A_net_0 ),
        .RESET_N                      ( RESET_N_net_0 ),
        .CKE0                         ( CKE0_net_0 ),
        .CS0_N                        ( CS0_N_net_0 ),
        .ODT0                         ( ODT0_net_0 ),
        .CK0                          ( CK0_net_0 ),
        .CK0_N                        ( CK0_N_net_0 ),
        .RAS_N                        ( RAS_N_net_0 ),
        .WE_N                         ( WE_N_net_0 ),
        .CAS_N                        ( CAS_N_net_0 ),
        .ACT_N                        ( ACT_N_net_0 ),
        .BG                           ( BG_net_0 ),
        // Inouts
        .I2C_1_SCL                    ( I2C_1_SCL ),
        .I2C_1_SDA                    ( I2C_1_SDA ),
        .MAC_1_MDIO                   ( MAC_1_MDIO ),
        .USB_DATA0                    ( USB_DATA0 ),
        .USB_DATA1                    ( USB_DATA1 ),
        .USB_DATA2                    ( USB_DATA2 ),
        .USB_DATA3                    ( USB_DATA3 ),
        .USB_DATA4                    ( USB_DATA4 ),
        .USB_DATA5                    ( USB_DATA5 ),
        .USB_DATA6                    ( USB_DATA6 ),
        .USB_DATA7                    ( USB_DATA7 ),
        .SPI_1_SS0                    ( SPI_1_SS0 ),
        .SPI_1_CLK                    ( SPI_1_CLK ),
        .SD_CMD_EMMC_CMD              ( SD_CMD_EMMC_CMD ),
        .SD_DATA0_EMMC_DATA0          ( SD_DATA0_EMMC_DATA0 ),
        .SD_DATA1_EMMC_DATA1          ( SD_DATA1_EMMC_DATA1 ),
        .SD_DATA2_EMMC_DATA2          ( SD_DATA2_EMMC_DATA2 ),
        .SD_DATA3_EMMC_DATA3          ( SD_DATA3_EMMC_DATA3 ),
        .DQ                           ( DQ ),
        .DQ_ECC                       ( DQ_ECC ),
        .DQS                          ( DQS ),
        .DQS_N                        ( DQS_N ) 
        );

//--------AND4
AND4 AND4_MSS_DLL_LOCKS(
        // Inputs
        .A ( ALDEC_MSS_2024_9_FIC_0_DLL_LOCK_M2F ),
        .B ( ALDEC_MSS_2024_9_FIC_1_DLL_LOCK_M2F ),
        .C ( ALDEC_MSS_2024_9_FIC_2_DLL_LOCK_M2F ),
        .D ( ALDEC_MSS_2024_9_FIC_3_DLL_LOCK_M2F ),
        // Outputs
        .Y ( AND4_MSS_DLL_LOCKS_Y ) 
        );

//--------BIBUF
BIBUF BIBUF_I2C0_SCL(
        // Inputs
        .D   ( GND_net ),
        .E   ( ALDEC_MSS_2024_9_I2C_0_SCL_OE_M2F ),
        // Outputs
        .Y   ( BIBUF_I2C0_SCL_Y ),
        // Inouts
        .PAD ( I2C0_SCL ) 
        );

//--------BIBUF
BIBUF BIBUF_I2C0_SDA(
        // Inputs
        .D   ( GND_net ),
        .E   ( ALDEC_MSS_2024_9_I2C_0_SDA_OE_M2F ),
        // Outputs
        .Y   ( BIBUF_I2C0_SDA_Y ),
        // Inouts
        .PAD ( I2C0_SDA ) 
        );

//--------CLOCKS_AND_RESETS
CLOCKS_AND_RESETS CLOCKS_AND_RESETS_inst_0(
        // Inputs
        .EXT_RST_N          ( USB_ULPI_RESET_net_0 ),
        .MSS_PLL_LOCKS      ( AND4_MSS_DLL_LOCKS_Y ),
        .REF_CLK_50MHz      ( REF_CLK_50MHz ),
        .REF_CLK_PAD_N      ( REF_CLK_PAD_N ),
        .REF_CLK_PAD_P      ( REF_CLK_PAD_P ),
        // Outputs
        .BIT_CLK            ( CLOCKS_AND_RESETS_CLKS_TO_XCVR_BIT_CLK ),
        .FIC_0_CLK          ( CLOCKS_AND_RESETS_FIC_0_CLK ),
        .FIC_1_CLK          ( CLOCKS_AND_RESETS_FIC_1_CLK ),
        .FIC_2_CLK          ( CLOCKS_AND_RESETS_FIC_2_CLK ),
        .FIC_3_CLK          ( CLOCKS_AND_RESETS_FIC_3_CLK ),
        .LOCK               ( CLOCKS_AND_RESETS_CLKS_TO_XCVR_LOCK ),
        .PCIE_INIT_DONE     ( CLOCKS_AND_RESETS_PCIE_INIT_DONE ),
        .PCIe_CLK_125MHz    ( CLOCKS_AND_RESETS_PCIe_CLK_125MHz ),
        .PCIe_REFERENCE_CLK ( CLOCKS_AND_RESETS_PCIe_REFERENCE_CLK ),
        .REF_CLK_TO_LANE    ( CLOCKS_AND_RESETS_CLKS_TO_XCVR_REF_CLK_TO_LANE ),
        .RESETN_FIC2_CLK    (  ),
        .RESETN_FIC_0_CLK   ( CLOCKS_AND_RESETS_RESETN_FIC_0_CLK ),
        .RESETN_FIC_1_CLK   ( CLOCKS_AND_RESETS_RESETN_FIC_1_CLK ),
        .RESETN_FIC_3_CLK   ( CLOCKS_AND_RESETS_RESETN_FIC_3_CLK ) 
        );

//--------DDR4_INITIATOR
DDR4_INITIATOR DDR4_INITIATOR_0(
        // Inputs
        .ACLK             ( CLOCKS_AND_RESETS_FIC_2_CLK ),
        .ARESETN          ( USB_ULPI_RESET_net_0 ),
        .S_CLK0           ( PF_DDR4_C0_0_SYS_CLK ),
        .SLAVE0_AWREADY   ( DDR4_INITIATOR_0_AXI4mslave0_AWREADY ),
        .SLAVE0_WREADY    ( DDR4_INITIATOR_0_AXI4mslave0_WREADY ),
        .SLAVE0_BID       ( DDR4_INITIATOR_0_AXI4mslave0_BID_0 ),
        .SLAVE0_BRESP     ( DDR4_INITIATOR_0_AXI4mslave0_BRESP ),
        .SLAVE0_BVALID    ( DDR4_INITIATOR_0_AXI4mslave0_BVALID ),
        .SLAVE0_ARREADY   ( DDR4_INITIATOR_0_AXI4mslave0_ARREADY ),
        .SLAVE0_RID       ( DDR4_INITIATOR_0_AXI4mslave0_RID_0 ),
        .SLAVE0_RDATA     ( DDR4_INITIATOR_0_AXI4mslave0_RDATA ),
        .SLAVE0_RRESP     ( DDR4_INITIATOR_0_AXI4mslave0_RRESP ),
        .SLAVE0_RLAST     ( DDR4_INITIATOR_0_AXI4mslave0_RLAST ),
        .SLAVE0_RVALID    ( DDR4_INITIATOR_0_AXI4mslave0_RVALID ),
        .SLAVE0_BUSER     ( GND_net ), // tied to 1'b0 from definition
        .SLAVE0_RUSER     ( GND_net ), // tied to 1'b0 from definition
        .MASTER0_AWID     ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWID ),
        .MASTER0_AWADDR   ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWADDR_0 ),
        .MASTER0_AWLEN    ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWLEN ),
        .MASTER0_AWSIZE   ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWSIZE ),
        .MASTER0_AWBURST  ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWBURST ),
        .MASTER0_AWLOCK   ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWLOCK_0 ),
        .MASTER0_AWCACHE  ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWCACHE ),
        .MASTER0_AWPROT   ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWPROT ),
        .MASTER0_AWQOS    ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWQOS ),
        .MASTER0_AWREGION ( MASTER0_AWREGION_const_net_0 ), // tied to 4'h0 from definition
        .MASTER0_AWVALID  ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWVALID ),
        .MASTER0_WDATA    ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_WDATA ),
        .MASTER0_WSTRB    ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_WSTRB ),
        .MASTER0_WLAST    ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_WLAST ),
        .MASTER0_WVALID   ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_WVALID ),
        .MASTER0_BREADY   ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_BREADY ),
        .MASTER0_ARID     ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARID ),
        .MASTER0_ARADDR   ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARADDR_0 ),
        .MASTER0_ARLEN    ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARLEN ),
        .MASTER0_ARSIZE   ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARSIZE ),
        .MASTER0_ARBURST  ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARBURST ),
        .MASTER0_ARLOCK   ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARLOCK_0 ),
        .MASTER0_ARCACHE  ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARCACHE ),
        .MASTER0_ARPROT   ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARPROT ),
        .MASTER0_ARQOS    ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARQOS ),
        .MASTER0_ARREGION ( MASTER0_ARREGION_const_net_0 ), // tied to 4'h0 from definition
        .MASTER0_ARVALID  ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARVALID ),
        .MASTER0_RREADY   ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RREADY ),
        .MASTER0_AWUSER   ( GND_net ), // tied to 1'b0 from definition
        .MASTER0_WUSER    ( GND_net ), // tied to 1'b0 from definition
        .MASTER0_ARUSER   ( GND_net ), // tied to 1'b0 from definition
        // Outputs
        .SLAVE0_AWID      ( DDR4_INITIATOR_0_AXI4mslave0_AWID ),
        .SLAVE0_AWADDR    ( DDR4_INITIATOR_0_AXI4mslave0_AWADDR ),
        .SLAVE0_AWLEN     ( DDR4_INITIATOR_0_AXI4mslave0_AWLEN ),
        .SLAVE0_AWSIZE    ( DDR4_INITIATOR_0_AXI4mslave0_AWSIZE ),
        .SLAVE0_AWBURST   ( DDR4_INITIATOR_0_AXI4mslave0_AWBURST ),
        .SLAVE0_AWLOCK    ( DDR4_INITIATOR_0_AXI4mslave0_AWLOCK ),
        .SLAVE0_AWCACHE   ( DDR4_INITIATOR_0_AXI4mslave0_AWCACHE ),
        .SLAVE0_AWPROT    ( DDR4_INITIATOR_0_AXI4mslave0_AWPROT ),
        .SLAVE0_AWQOS     ( DDR4_INITIATOR_0_AXI4mslave0_AWQOS ),
        .SLAVE0_AWREGION  ( DDR4_INITIATOR_0_AXI4mslave0_AWREGION ),
        .SLAVE0_AWVALID   ( DDR4_INITIATOR_0_AXI4mslave0_AWVALID ),
        .SLAVE0_WDATA     ( DDR4_INITIATOR_0_AXI4mslave0_WDATA ),
        .SLAVE0_WSTRB     ( DDR4_INITIATOR_0_AXI4mslave0_WSTRB ),
        .SLAVE0_WLAST     ( DDR4_INITIATOR_0_AXI4mslave0_WLAST ),
        .SLAVE0_WVALID    ( DDR4_INITIATOR_0_AXI4mslave0_WVALID ),
        .SLAVE0_BREADY    ( DDR4_INITIATOR_0_AXI4mslave0_BREADY ),
        .SLAVE0_ARID      ( DDR4_INITIATOR_0_AXI4mslave0_ARID ),
        .SLAVE0_ARADDR    ( DDR4_INITIATOR_0_AXI4mslave0_ARADDR ),
        .SLAVE0_ARLEN     ( DDR4_INITIATOR_0_AXI4mslave0_ARLEN ),
        .SLAVE0_ARSIZE    ( DDR4_INITIATOR_0_AXI4mslave0_ARSIZE ),
        .SLAVE0_ARBURST   ( DDR4_INITIATOR_0_AXI4mslave0_ARBURST ),
        .SLAVE0_ARLOCK    ( DDR4_INITIATOR_0_AXI4mslave0_ARLOCK ),
        .SLAVE0_ARCACHE   ( DDR4_INITIATOR_0_AXI4mslave0_ARCACHE ),
        .SLAVE0_ARPROT    ( DDR4_INITIATOR_0_AXI4mslave0_ARPROT ),
        .SLAVE0_ARQOS     ( DDR4_INITIATOR_0_AXI4mslave0_ARQOS ),
        .SLAVE0_ARREGION  ( DDR4_INITIATOR_0_AXI4mslave0_ARREGION ),
        .SLAVE0_ARVALID   ( DDR4_INITIATOR_0_AXI4mslave0_ARVALID ),
        .SLAVE0_RREADY    ( DDR4_INITIATOR_0_AXI4mslave0_RREADY ),
        .SLAVE0_AWUSER    ( DDR4_INITIATOR_0_AXI4mslave0_AWUSER ),
        .SLAVE0_WUSER     ( DDR4_INITIATOR_0_AXI4mslave0_WUSER ),
        .SLAVE0_ARUSER    ( DDR4_INITIATOR_0_AXI4mslave0_ARUSER ),
        .MASTER0_AWREADY  ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_AWREADY ),
        .MASTER0_WREADY   ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_WREADY ),
        .MASTER0_BID      ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_BID ),
        .MASTER0_BRESP    ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_BRESP ),
        .MASTER0_BVALID   ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_BVALID ),
        .MASTER0_ARREADY  ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_ARREADY ),
        .MASTER0_RID      ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RID ),
        .MASTER0_RDATA    ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RDATA ),
        .MASTER0_RRESP    ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RRESP ),
        .MASTER0_RLAST    ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RLAST ),
        .MASTER0_RVALID   ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RVALID ),
        .MASTER0_BUSER    ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_BUSER ),
        .MASTER0_RUSER    ( ALDEC_MSS_2024_9_FIC_0_AXI4_INITIATOR_RUSER ) 
        );

//--------FIC_1_PERIPHERALS
FIC_1_PERIPHERALS FIC_1_PERIPHERALS_1(
        // Inputs
        .ACLK                                              ( CLOCKS_AND_RESETS_FIC_1_CLK ),
        .ARESETN                                           ( CLOCKS_AND_RESETS_RESETN_FIC_1_CLK ),
        .AXI4mmaster0_MASTER0_ARVALID                      ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARVALID ),
        .AXI4mmaster0_MASTER0_AWVALID                      ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWVALID ),
        .AXI4mmaster0_MASTER0_BREADY                       ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_BREADY ),
        .AXI4mmaster0_MASTER0_RREADY                       ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RREADY ),
        .AXI4mmaster0_MASTER0_WLAST                        ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_WLAST ),
        .AXI4mmaster0_MASTER0_WVALID                       ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_WVALID ),
        .AXI4mslave0_SLAVE0_ARREADY                        ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARREADY ),
        .AXI4mslave0_SLAVE0_AWREADY                        ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWREADY ),
        .AXI4mslave0_SLAVE0_BVALID                         ( FIC_1_PERIPHERALS_1_AXI4mslave0_BVALID ),
        .AXI4mslave0_SLAVE0_RLAST                          ( FIC_1_PERIPHERALS_1_AXI4mslave0_RLAST ),
        .AXI4mslave0_SLAVE0_RVALID                         ( FIC_1_PERIPHERALS_1_AXI4mslave0_RVALID ),
        .AXI4mslave0_SLAVE0_WREADY                         ( FIC_1_PERIPHERALS_1_AXI4mslave0_WREADY ),
        .CLKS_FROM_TXPLL_TO_PCIE_1_PCIE_1_TX_BIT_CLK       ( CLOCKS_AND_RESETS_CLKS_TO_XCVR_BIT_CLK ),
        .CLKS_FROM_TXPLL_TO_PCIE_1_PCIE_1_TX_PLL_LOCK      ( CLOCKS_AND_RESETS_CLKS_TO_XCVR_LOCK ),
        .CLKS_FROM_TXPLL_TO_PCIE_1_PCIE_1_TX_PLL_REF_CLK   ( CLOCKS_AND_RESETS_CLKS_TO_XCVR_REF_CLK_TO_LANE ),
        .PCIESS_LANE0_DRI_SLAVE_PCIESS_LANE0_DRI_ARST_N    ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_ARST_N ),
        .PCIESS_LANE0_DRI_SLAVE_PCIESS_LANE0_DRI_CLK       ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_CLK ),
        .PCIESS_LANE1_DRI_SLAVE_PCIESS_LANE1_DRI_ARST_N    ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_ARST_N ),
        .PCIESS_LANE1_DRI_SLAVE_PCIESS_LANE1_DRI_CLK       ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_CLK ),
        .PCIESS_LANE2_DRI_SLAVE_PCIESS_LANE2_DRI_ARST_N    ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_ARST_N ),
        .PCIESS_LANE2_DRI_SLAVE_PCIESS_LANE2_DRI_CLK       ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_CLK ),
        .PCIESS_LANE3_DRI_SLAVE_PCIESS_LANE3_DRI_ARST_N    ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_ARST_N ),
        .PCIESS_LANE3_DRI_SLAVE_PCIESS_LANE3_DRI_CLK       ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_CLK ),
        .PCIESS_LANE_RXD0_N                                ( PCIESS_LANE_RXD0_N ),
        .PCIESS_LANE_RXD0_P                                ( PCIESS_LANE_RXD0_P ),
        .PCIESS_LANE_RXD1_N                                ( PCIESS_LANE_RXD1_N ),
        .PCIESS_LANE_RXD1_P                                ( PCIESS_LANE_RXD1_P ),
        .PCIESS_LANE_RXD2_N                                ( PCIESS_LANE_RXD2_N ),
        .PCIESS_LANE_RXD2_P                                ( PCIESS_LANE_RXD2_P ),
        .PCIESS_LANE_RXD3_N                                ( PCIESS_LANE_RXD3_N ),
        .PCIESS_LANE_RXD3_P                                ( PCIESS_LANE_RXD3_P ),
        .PCIE_APB_SLAVE_APB_S_PENABLE                      ( GND_net ), // tied to 1'b0 from definition
        .PCIE_APB_SLAVE_APB_S_PSEL                         ( GND_net ), // tied to 1'b0 from definition
        .PCIE_APB_SLAVE_APB_S_PWRITE                       ( GND_net ), // tied to 1'b0 from definition
        .PCIe_CLK_125MHz                                   ( CLOCKS_AND_RESETS_PCIe_CLK_125MHz ),
        .PCIe_INIT_DONE                                    ( CLOCKS_AND_RESETS_PCIE_INIT_DONE ),
        .PCIe_REFERENCE_CLK                                ( CLOCKS_AND_RESETS_PCIe_REFERENCE_CLK ),
        .PCLK                                              ( CLOCKS_AND_RESETS_FIC_3_CLK ),
        .PRESETN                                           ( CLOCKS_AND_RESETS_RESETN_FIC_3_CLK ),
        .AXI4mmaster0_MASTER0_ARADDR                       ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARADDR ),
        .AXI4mmaster0_MASTER0_ARBURST                      ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARBURST ),
        .AXI4mmaster0_MASTER0_ARCACHE                      ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARCACHE ),
        .AXI4mmaster0_MASTER0_ARID                         ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARID ),
        .AXI4mmaster0_MASTER0_ARLEN                        ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARLEN ),
        .AXI4mmaster0_MASTER0_ARLOCK                       ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARLOCK_0 ),
        .AXI4mmaster0_MASTER0_ARPROT                       ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARPROT ),
        .AXI4mmaster0_MASTER0_ARQOS                        ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARQOS ),
        .AXI4mmaster0_MASTER0_ARREGION                     ( AXI4mmaster0_MASTER0_ARREGION_const_net_0 ), // tied to 4'h0 from definition
        .AXI4mmaster0_MASTER0_ARSIZE                       ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARSIZE ),
        .AXI4mmaster0_MASTER0_ARUSER                       ( GND_net ), // tied to 1'b0 from definition
        .AXI4mmaster0_MASTER0_AWADDR                       ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWADDR ),
        .AXI4mmaster0_MASTER0_AWBURST                      ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWBURST ),
        .AXI4mmaster0_MASTER0_AWCACHE                      ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWCACHE ),
        .AXI4mmaster0_MASTER0_AWID                         ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWID ),
        .AXI4mmaster0_MASTER0_AWLEN                        ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWLEN ),
        .AXI4mmaster0_MASTER0_AWLOCK                       ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWLOCK_0 ),
        .AXI4mmaster0_MASTER0_AWPROT                       ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWPROT ),
        .AXI4mmaster0_MASTER0_AWQOS                        ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWQOS ),
        .AXI4mmaster0_MASTER0_AWREGION                     ( AXI4mmaster0_MASTER0_AWREGION_const_net_0 ), // tied to 4'h0 from definition
        .AXI4mmaster0_MASTER0_AWSIZE                       ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWSIZE ),
        .AXI4mmaster0_MASTER0_AWUSER                       ( GND_net ), // tied to 1'b0 from definition
        .AXI4mmaster0_MASTER0_WDATA                        ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_WDATA ),
        .AXI4mmaster0_MASTER0_WSTRB                        ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_WSTRB ),
        .AXI4mmaster0_MASTER0_WUSER                        ( GND_net ), // tied to 1'b0 from definition
        .AXI4mslave0_SLAVE0_BID                            ( FIC_1_PERIPHERALS_1_AXI4mslave0_BID_0 ),
        .AXI4mslave0_SLAVE0_BRESP                          ( FIC_1_PERIPHERALS_1_AXI4mslave0_BRESP ),
        .AXI4mslave0_SLAVE0_BUSER                          ( GND_net ), // tied to 1'b0 from definition
        .AXI4mslave0_SLAVE0_RDATA                          ( FIC_1_PERIPHERALS_1_AXI4mslave0_RDATA ),
        .AXI4mslave0_SLAVE0_RID                            ( FIC_1_PERIPHERALS_1_AXI4mslave0_RID_0 ),
        .AXI4mslave0_SLAVE0_RRESP                          ( FIC_1_PERIPHERALS_1_AXI4mslave0_RRESP ),
        .AXI4mslave0_SLAVE0_RUSER                          ( GND_net ), // tied to 1'b0 from definition
        .PCIESS_LANE0_DRI_SLAVE_PCIESS_LANE0_DRI_CTRL      ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_CTRL ),
        .PCIESS_LANE0_DRI_SLAVE_PCIESS_LANE0_DRI_WDATA     ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_WDATA ),
        .PCIESS_LANE1_DRI_SLAVE_PCIESS_LANE1_DRI_CTRL      ( FIC_3_PERIPHERALS_1_Q0_LANE1_DRI_DRI_CTRL ),
        .PCIESS_LANE1_DRI_SLAVE_PCIESS_LANE1_DRI_WDATA     ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_WDATA ),
        .PCIESS_LANE2_DRI_SLAVE_PCIESS_LANE2_DRI_CTRL      ( FIC_3_PERIPHERALS_1_Q0_LANE2_DRI_DRI_CTRL ),
        .PCIESS_LANE2_DRI_SLAVE_PCIESS_LANE2_DRI_WDATA     ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_WDATA ),
        .PCIESS_LANE3_DRI_SLAVE_PCIESS_LANE3_DRI_CTRL      ( FIC_3_PERIPHERALS_1_Q0_LANE3_DRI_DRI_CTRL ),
        .PCIESS_LANE3_DRI_SLAVE_PCIESS_LANE3_DRI_WDATA     ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_WDATA ),
        .PCIE_APB_SLAVE_APB_S_PADDR                        ( PCIE_APB_SLAVE_APB_S_PADDR_const_net_0 ), // tied to 26'h0000000 from definition
        .PCIE_APB_SLAVE_APB_S_PWDATA                       ( PCIE_APB_SLAVE_APB_S_PWDATA_const_net_0 ), // tied to 32'h00000000 from definition
        // Outputs
        .AXI4mmaster0_MASTER0_ARREADY                      ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_ARREADY ),
        .AXI4mmaster0_MASTER0_AWREADY                      ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_AWREADY ),
        .AXI4mmaster0_MASTER0_BVALID                       ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_BVALID ),
        .AXI4mmaster0_MASTER0_RLAST                        ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RLAST ),
        .AXI4mmaster0_MASTER0_RVALID                       ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RVALID ),
        .AXI4mmaster0_MASTER0_WREADY                       ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_WREADY ),
        .AXI4mslave0_SLAVE0_ARVALID                        ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARVALID ),
        .AXI4mslave0_SLAVE0_AWVALID                        ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWVALID ),
        .AXI4mslave0_SLAVE0_BREADY                         ( FIC_1_PERIPHERALS_1_AXI4mslave0_BREADY ),
        .AXI4mslave0_SLAVE0_RREADY                         ( FIC_1_PERIPHERALS_1_AXI4mslave0_RREADY ),
        .AXI4mslave0_SLAVE0_WLAST                          ( FIC_1_PERIPHERALS_1_AXI4mslave0_WLAST ),
        .AXI4mslave0_SLAVE0_WVALID                         ( FIC_1_PERIPHERALS_1_AXI4mslave0_WVALID ),
        .PCIESS_LANE0_DRI_SLAVE_PCIESS_LANE0_DRI_INTERRUPT ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_INTERRUPT ),
        .PCIESS_LANE1_DRI_SLAVE_PCIESS_LANE1_DRI_INTERRUPT ( FIC_3_PERIPHERALS_1_Q0_LANE1_DRI_DRI_INTERRUPT ),
        .PCIESS_LANE2_DRI_SLAVE_PCIESS_LANE2_DRI_INTERRUPT ( FIC_3_PERIPHERALS_1_Q0_LANE2_DRI_DRI_INTERRUPT ),
        .PCIESS_LANE3_DRI_SLAVE_PCIESS_LANE3_DRI_INTERRUPT ( FIC_3_PERIPHERALS_1_Q0_LANE3_DRI_DRI_INTERRUPT ),
        .PCIESS_LANE_TXD0_N                                ( PCIESS_LANE_TXD0_N_net_0 ),
        .PCIESS_LANE_TXD0_P                                ( PCIESS_LANE_TXD0_P_net_0 ),
        .PCIESS_LANE_TXD1_N                                ( PCIESS_LANE_TXD1_N_net_0 ),
        .PCIESS_LANE_TXD1_P                                ( PCIESS_LANE_TXD1_P_net_0 ),
        .PCIESS_LANE_TXD2_N                                ( PCIESS_LANE_TXD2_N_net_0 ),
        .PCIESS_LANE_TXD2_P                                ( PCIESS_LANE_TXD2_P_net_0 ),
        .PCIESS_LANE_TXD3_N                                ( PCIESS_LANE_TXD3_N_net_0 ),
        .PCIESS_LANE_TXD3_P                                ( PCIESS_LANE_TXD3_P_net_0 ),
        .PCIE_1_PERST_N                                    ( PCIE_1_PERST_N_net_0 ),
        .PCIE_APB_SLAVE_APB_S_PREADY                       (  ),
        .PCIE_APB_SLAVE_APB_S_PSLVERR                      (  ),
        .PCIe_IRQ                                          ( FIC_1_PERIPHERALS_1_PCIe_IRQ ),
        .AXI4mmaster0_MASTER0_BID                          ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_BID ),
        .AXI4mmaster0_MASTER0_BRESP                        ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_BRESP ),
        .AXI4mmaster0_MASTER0_BUSER                        ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_BUSER ),
        .AXI4mmaster0_MASTER0_RDATA                        ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RDATA ),
        .AXI4mmaster0_MASTER0_RID                          ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RID ),
        .AXI4mmaster0_MASTER0_RRESP                        ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RRESP ),
        .AXI4mmaster0_MASTER0_RUSER                        ( ALDEC_MSS_2024_9_FIC_1_AXI4_INITIATOR_RUSER ),
        .AXI4mslave0_SLAVE0_ARADDR                         ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARADDR ),
        .AXI4mslave0_SLAVE0_ARBURST                        ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARBURST ),
        .AXI4mslave0_SLAVE0_ARCACHE                        ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARCACHE ),
        .AXI4mslave0_SLAVE0_ARID                           ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARID ),
        .AXI4mslave0_SLAVE0_ARLEN                          ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARLEN ),
        .AXI4mslave0_SLAVE0_ARLOCK                         ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARLOCK ),
        .AXI4mslave0_SLAVE0_ARPROT                         ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARPROT ),
        .AXI4mslave0_SLAVE0_ARQOS                          ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARQOS ),
        .AXI4mslave0_SLAVE0_ARREGION                       ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARREGION ),
        .AXI4mslave0_SLAVE0_ARSIZE                         ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARSIZE ),
        .AXI4mslave0_SLAVE0_ARUSER                         ( FIC_1_PERIPHERALS_1_AXI4mslave0_ARUSER ),
        .AXI4mslave0_SLAVE0_AWADDR                         ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWADDR ),
        .AXI4mslave0_SLAVE0_AWBURST                        ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWBURST ),
        .AXI4mslave0_SLAVE0_AWCACHE                        ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWCACHE ),
        .AXI4mslave0_SLAVE0_AWID                           ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWID ),
        .AXI4mslave0_SLAVE0_AWLEN                          ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWLEN ),
        .AXI4mslave0_SLAVE0_AWLOCK                         ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWLOCK ),
        .AXI4mslave0_SLAVE0_AWPROT                         ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWPROT ),
        .AXI4mslave0_SLAVE0_AWQOS                          ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWQOS ),
        .AXI4mslave0_SLAVE0_AWREGION                       ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWREGION ),
        .AXI4mslave0_SLAVE0_AWSIZE                         ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWSIZE ),
        .AXI4mslave0_SLAVE0_AWUSER                         ( FIC_1_PERIPHERALS_1_AXI4mslave0_AWUSER ),
        .AXI4mslave0_SLAVE0_WDATA                          ( FIC_1_PERIPHERALS_1_AXI4mslave0_WDATA ),
        .AXI4mslave0_SLAVE0_WSTRB                          ( FIC_1_PERIPHERALS_1_AXI4mslave0_WSTRB ),
        .AXI4mslave0_SLAVE0_WUSER                          ( FIC_1_PERIPHERALS_1_AXI4mslave0_WUSER ),
        .PCIESS_LANE0_DRI_SLAVE_PCIESS_LANE0_DRI_RDATA     ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_RDATA ),
        .PCIESS_LANE1_DRI_SLAVE_PCIESS_LANE1_DRI_RDATA     ( FIC_3_PERIPHERALS_1_Q0_LANE1_DRI_DRI_RDATA ),
        .PCIESS_LANE2_DRI_SLAVE_PCIESS_LANE2_DRI_RDATA     ( FIC_3_PERIPHERALS_1_Q0_LANE2_DRI_DRI_RDATA ),
        .PCIESS_LANE3_DRI_SLAVE_PCIESS_LANE3_DRI_RDATA     ( FIC_3_PERIPHERALS_1_Q0_LANE3_DRI_DRI_RDATA ),
        .PCIE_APB_SLAVE_APB_S_PRDATA                       (  ) 
        );

//--------FIC_3_PERIPHERALS
FIC_3_PERIPHERALS FIC_3_PERIPHERALS_1(
        // Inputs
        .APB_MMASTER_in_penable          ( ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PENABLE ),
        .APB_MMASTER_in_psel             ( ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PSELx ),
        .APB_MMASTER_in_pwrite           ( ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PWRITE ),
        .PCLK                            ( CLOCKS_AND_RESETS_FIC_3_CLK ),
        .PLL0_SW_DRI_INTERRUPT           ( VCC_net ), // tied to 1'b1 from definition
        .PRESETN                         ( CLOCKS_AND_RESETS_RESETN_FIC_3_CLK ),
        .Q0_LANE0_DRI_INTERRUPT          ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_INTERRUPT ),
        .Q0_LANE1_DRI_INTERRUPT          ( FIC_3_PERIPHERALS_1_Q0_LANE1_DRI_DRI_INTERRUPT ),
        .Q0_LANE2_DRI_INTERRUPT          ( FIC_3_PERIPHERALS_1_Q0_LANE2_DRI_DRI_INTERRUPT ),
        .Q0_LANE3_DRI_INTERRUPT          ( FIC_3_PERIPHERALS_1_Q0_LANE3_DRI_DRI_INTERRUPT ),
        .APB_MMASTER_in_paddr            ( ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PADDR ),
        .APB_MMASTER_in_pwdata           ( ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PWDATA ),
        .PLL0_SW_DRI_RDATA               ( PLL0_SW_DRI_RDATA_const_net_0 ), // tied to 33'h000000000 from definition
        .PSTRB                           ( ALDEC_MSS_2024_9_FIC_3_APB_M_PSTRB ),
        .Q0_LANE0_DRI_RDATA              ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_RDATA ),
        .Q0_LANE1_DRI_RDATA              ( FIC_3_PERIPHERALS_1_Q0_LANE1_DRI_DRI_RDATA ),
        .Q0_LANE2_DRI_RDATA              ( FIC_3_PERIPHERALS_1_Q0_LANE2_DRI_DRI_RDATA ),
        .Q0_LANE3_DRI_RDATA              ( FIC_3_PERIPHERALS_1_Q0_LANE3_DRI_DRI_RDATA ),
        // Outputs
        .APB_MMASTER_in_pready           ( ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PREADY ),
        .APB_MMASTER_in_pslverr          ( ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PSLVERR ),
        .Q0_LANE0_DRI_DRI_ARST_N         ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_ARST_N ),
        .Q0_LANE0_DRI_DRI_CLK            ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_CLK ),
        .fabric_sd_emmc_demux_select_out ( FIC_3_PERIPHERALS_1_fabric_sd_emmc_demux_select_out ),
        .APB_MMASTER_in_prdata           ( ALDEC_MSS_2024_9_FIC_3_APB_INITIATOR_PRDATA ),
        .PLL0_SW_DRI_CTRL                (  ),
        .Q0_LANE0_DRI_CTRL               ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_CTRL ),
        .Q0_LANE0_DRI_DRI_WDATA          ( FIC_3_PERIPHERALS_1_Q0_LANE0_DRI_DRI_WDATA ),
        .Q0_LANE1_DRI_CTRL               ( FIC_3_PERIPHERALS_1_Q0_LANE1_DRI_DRI_CTRL ),
        .Q0_LANE2_DRI_CTRL               ( FIC_3_PERIPHERALS_1_Q0_LANE2_DRI_DRI_CTRL ),
        .Q0_LANE3_DRI_CTRL               ( FIC_3_PERIPHERALS_1_Q0_LANE3_DRI_DRI_CTRL ) 
        );

//--------INV
INV INV_0(
        // Inputs
        .A ( FIC_3_PERIPHERALS_1_fabric_sd_emmc_demux_select_out ),
        // Outputs
        .Y ( SD_SEL_net_0 ) 
        );

//--------PF_DDR4_C0
PF_DDR4_C0 PF_DDR4_C0_0(
        // Inputs
        .PLL_REF_CLK  ( CLOCKS_AND_RESETS_FIC_0_CLK ),
        .SYS_RESET_N  ( USB_ULPI_RESET_net_0 ),
        .axi0_awid    ( DDR4_INITIATOR_0_AXI4mslave0_AWID_0 ),
        .axi0_awaddr  ( DDR4_INITIATOR_0_AXI4mslave0_AWADDR ),
        .axi0_awlen   ( DDR4_INITIATOR_0_AXI4mslave0_AWLEN ),
        .axi0_awsize  ( DDR4_INITIATOR_0_AXI4mslave0_AWSIZE ),
        .axi0_awburst ( DDR4_INITIATOR_0_AXI4mslave0_AWBURST ),
        .axi0_awlock  ( DDR4_INITIATOR_0_AXI4mslave0_AWLOCK ),
        .axi0_awcache ( DDR4_INITIATOR_0_AXI4mslave0_AWCACHE ),
        .axi0_awprot  ( DDR4_INITIATOR_0_AXI4mslave0_AWPROT ),
        .axi0_awvalid ( DDR4_INITIATOR_0_AXI4mslave0_AWVALID ),
        .axi0_wdata   ( DDR4_INITIATOR_0_AXI4mslave0_WDATA ),
        .axi0_wstrb   ( DDR4_INITIATOR_0_AXI4mslave0_WSTRB ),
        .axi0_wlast   ( DDR4_INITIATOR_0_AXI4mslave0_WLAST ),
        .axi0_wvalid  ( DDR4_INITIATOR_0_AXI4mslave0_WVALID ),
        .axi0_bready  ( DDR4_INITIATOR_0_AXI4mslave0_BREADY ),
        .axi0_arid    ( DDR4_INITIATOR_0_AXI4mslave0_ARID_0 ),
        .axi0_araddr  ( DDR4_INITIATOR_0_AXI4mslave0_ARADDR ),
        .axi0_arlen   ( DDR4_INITIATOR_0_AXI4mslave0_ARLEN ),
        .axi0_arsize  ( DDR4_INITIATOR_0_AXI4mslave0_ARSIZE ),
        .axi0_arburst ( DDR4_INITIATOR_0_AXI4mslave0_ARBURST ),
        .axi0_arlock  ( DDR4_INITIATOR_0_AXI4mslave0_ARLOCK ),
        .axi0_arcache ( DDR4_INITIATOR_0_AXI4mslave0_ARCACHE ),
        .axi0_arprot  ( DDR4_INITIATOR_0_AXI4mslave0_ARPROT ),
        .axi0_arvalid ( DDR4_INITIATOR_0_AXI4mslave0_ARVALID ),
        .axi0_rready  ( DDR4_INITIATOR_0_AXI4mslave0_RREADY ),
        // Outputs
        .DM_N         ( DM_N_net_0 ),
        .CKE          ( CKE_net_0 ),
        .CS_N         ( CS_N_net_0 ),
        .ODT          ( ODT_net_0 ),
        .RAS_N        ( RAS_N_0_net_0 ),
        .CAS_N        ( CAS_N_0_net_0 ),
        .WE_N         ( WE_N_0_net_0 ),
        .ACT_N        ( ACT_N_0_net_0 ),
        .BG           ( BG_0_net_0 ),
        .BA           ( BA_0_net_0 ),
        .RESET_N      ( RESET_N_0_net_0 ),
        .A            ( A_0_net_0 ),
        .CK0          ( CK0_0_net_0 ),
        .CK0_N        ( CK0_N_0_net_0 ),
        .SHIELD0      ( SHIELD0_net_0 ),
        .SHIELD1      ( SHIELD1_net_0 ),
        .SHIELD2      ( SHIELD2_net_0 ),
        .SHIELD3      ( SHIELD3_net_0 ),
        .SYS_CLK      ( PF_DDR4_C0_0_SYS_CLK ),
        .PLL_LOCK     (  ),
        .axi0_awready ( DDR4_INITIATOR_0_AXI4mslave0_AWREADY ),
        .axi0_wready  ( DDR4_INITIATOR_0_AXI4mslave0_WREADY ),
        .axi0_bid     ( DDR4_INITIATOR_0_AXI4mslave0_BID ),
        .axi0_bresp   ( DDR4_INITIATOR_0_AXI4mslave0_BRESP ),
        .axi0_bvalid  ( DDR4_INITIATOR_0_AXI4mslave0_BVALID ),
        .axi0_arready ( DDR4_INITIATOR_0_AXI4mslave0_ARREADY ),
        .axi0_rid     ( DDR4_INITIATOR_0_AXI4mslave0_RID ),
        .axi0_rdata   ( DDR4_INITIATOR_0_AXI4mslave0_RDATA ),
        .axi0_rresp   ( DDR4_INITIATOR_0_AXI4mslave0_RRESP ),
        .axi0_rlast   ( DDR4_INITIATOR_0_AXI4mslave0_RLAST ),
        .axi0_rvalid  ( DDR4_INITIATOR_0_AXI4mslave0_RVALID ),
        .CTRLR_READY  (  ),
        // Inouts
        .DQ           ( DQ_0 ),
        .DQS          ( DQS_0 ),
        .DQS_N        ( DQS_N_0 ) 
        );


endmodule
