# Microchip Technology Inc.
# Date: 2025-Jul-29 11:30:06
# This file was generated based on the following SDC source files:
#   /home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/work/MSS_TySOM_M_VIDEO/MSS_TySOM_M_VIDEO.sdc
#   /home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/work/PF_CCC_C0/PF_CCC_C0_0/PF_CCC_C0_PF_CCC_C0_0_PF_CCC.sdc
#   /edatools/microsemi/Libero_SoC_v2024.2/Libero/data/aPA5M/cores/constraints/EXT/osc_rc160mhz.sdc
# *** Any modifications to this file will be lost if derived constraints is re-run. ***
#

create_clock -name {osc_rc160mhz} -period 5.86854 [ get_pins { PF_OSC_C0_0/PF_OSC_C0_0/I_OSC_160/CLK } ]
create_generated_clock -name {PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/OUT0} -multiply_by 297 -divide_by 320 -source [ get_pins { PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/REF_CLK_0 } ] -phase 0 [ get_pins { PF_CCC_C0_0/PF_CCC_C0_0/pll_inst_0/OUT0 } ]
