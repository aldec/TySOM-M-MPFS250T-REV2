set_device -family {PolarFireSoC} -die {MPFS250T_ES} -speed {-1} -range {EXT}
read_verilog -mode system_verilog {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/work/CORERESET_PF_C0/CORERESET_PF_C0_0/core/corereset_pf.v}
read_verilog -mode system_verilog {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/work/CORERESET_PF_C0/CORERESET_PF_C0.v}
read_verilog -mode system_verilog {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/Microchip/SolutionCore/Display_Controller/4.8.0/Encrypted/Display_Controller.v}
read_verilog -mode system_verilog {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/work/Display_Controller_New/Display_Controller_New.v}
read_verilog -mode system_verilog {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/work/MSS_TySOM_M_VIDEO/MSS_TySOM_M_VIDEO.v}
read_verilog -mode system_verilog {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/work/PFSOC_INIT_MONITOR_C0/PFSOC_INIT_MONITOR_C0_0/PFSOC_INIT_MONITOR_C0_PFSOC_INIT_MONITOR_C0_0_PFSOC_INIT_MONITOR.v}
read_verilog -mode system_verilog {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/work/PFSOC_INIT_MONITOR_C0/PFSOC_INIT_MONITOR_C0.v}
read_verilog -mode system_verilog {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/work/PF_CCC_C0/PF_CCC_C0_0/PF_CCC_C0_PF_CCC_C0_0_PF_CCC.v}
read_verilog -mode system_verilog {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/work/PF_CCC_C0/PF_CCC_C0.v}
read_verilog -mode system_verilog {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/work/PF_OSC_C0/PF_OSC_C0_0/PF_OSC_C0_PF_OSC_C0_0_PF_OSC.v}
read_verilog -mode system_verilog {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/work/PF_OSC_C0/PF_OSC_C0.v}
read_verilog -mode system_verilog {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/Microchip/SolutionCore/Test_Pattern_Generator/3.5.2/RTL/Test_Pattern_Generator.v}
read_verilog -mode system_verilog {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/work/Test_Pattern_Generator_C0/Test_Pattern_Generator_C0.v}
read_verilog -mode system_verilog {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/work/System/System.v}
set_top_level {System}
read_sdc -component {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/work/PF_CCC_C0/PF_CCC_C0_0/PF_CCC_C0_PF_CCC_C0_0_PF_CCC.sdc}
read_sdc -component {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/component/work/MSS_TySOM_M_VIDEO/MSS_TySOM_M_VIDEO.sdc}
derive_constraints
write_sdc {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/constraint/System_derived_constraints.sdc}
write_ndc {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/constraint/System_derived_constraints.ndc}
write_pdc {/home/makro/Desktop/tysom_m_base/BSP/baremetal/v2024.9/LED-HDMI-UART-SWITCHES/Libero/TySOM_M_MPFS250T/constraint/fp/System_derived_constraints.pdc}
