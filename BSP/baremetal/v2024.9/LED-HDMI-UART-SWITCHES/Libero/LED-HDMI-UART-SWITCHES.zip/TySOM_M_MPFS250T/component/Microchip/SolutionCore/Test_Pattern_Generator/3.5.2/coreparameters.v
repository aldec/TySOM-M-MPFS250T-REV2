//--------------------------------------------------------------------
// Created by Microsemi SmartDesign Tue Jul 29 11:29:54 2025
// Parameters for Test_Pattern_Generator
//--------------------------------------------------------------------


parameter FAMILY = 27;
parameter g_PIXEL_WIDTH = 8;
parameter g_PIXELS_PER_CLK = 1;
parameter H_RESOLUTION = 1920;
parameter HDL_license = "U";
parameter testbench = "User";
parameter TGIGEN_DISPLAY_SYMBOL = 1;
parameter V_RESOLUTION = 1080;
