
/*************************************************************************************************************************************
--
-- File Name       : Test_Pattern_Generator_tb.v 
-- Description     : This module is testbench for  pattern generator core

-- Targeted device : Microchip FPGAs                    
-- Author          : India Solutions Team

-- COPYRIGHT 2023 BY MICROCHIP 
-- THE INFORMATION CONTAINED IN THIS DOCUMENT IS SUBJECT TO LICENSING RESTRICTIONS 
-- FROM MICROSEMI CORP.  IF YOU ARE NOT IN POSSESSION OF WRITTEN AUTHORIZATION FROM 
-- MICROSEMI FOR USE OF THIS FILE, THEN THE FILE SHOULD BE IMMEDIATELY DESTROYED AND 
-- NO BACK-UP OF THE FILE SHOULD BE MADE. 
--
--*************************************************************************************************************************************/
`timescale 1ns/1ps

module Test_Pattern_Generator_tb;

parameter CLKPERIOD  = 6.7;// 149.254MHZ

//internal Parameters
parameter H_RESOLUTION   = 1920;
parameter V_RESOLUTION   = 1080;
parameter g_PIXELS_PER_CLK = 1;
parameter g_PIXEL_WIDTH = 8;


reg               SYSCLK;
reg               NSYSRESET;
reg               DATA_EN_I_tb;   
reg               FRAME_END_I_tb;  
reg    [2:0]      PATTERN_SEL_I_tb;
reg    [1:0]      BAYER_PATTERN_I_tb;
wire              DATA_VALID_O_tb; 
wire              FRAME_END_O_tb; 
wire              LINE_END_O_tb;   
wire   [g_PIXELS_PER_CLK*g_PIXEL_WIDTH-1:0]      RED_O_tb;        
wire   [g_PIXELS_PER_CLK*g_PIXEL_WIDTH-1:0]      GREEN_O_tb;      
wire   [g_PIXELS_PER_CLK*g_PIXEL_WIDTH-1:0]      BLUE_O_tb;       
wire   [g_PIXELS_PER_CLK*g_PIXEL_WIDTH-1:0]      BAYER_O_tb; 
reg    [15:0]     h_counter;
reg    [15:0]     v_counter;
reg    [15:0]     wait_counter; 
reg    [15:0]     frame_counter;    


initial
begin
    SYSCLK = 1'b0;
    NSYSRESET = 1'b0;
end

//////////////////////////////////////////////////////////////////////
// Reset Pulse
//////////////////////////////////////////////////////////////////////
initial
begin
    #(CLKPERIOD * 10 )
        NSYSRESET = 1'b1;
end


//////////////////////////////////////////////////////////////////////
// Clock Driver
//////////////////////////////////////////////////////////////////////
always @(SYSCLK)
    #(CLKPERIOD / 2.0) SYSCLK <= !SYSCLK;

//////////////////////////////////////////////////////////////////////
// Stimulus generation
//////////////////////////////////////////////////////////////////////
always@(posedge SYSCLK or negedge NSYSRESET)
begin
  if(!NSYSRESET)
  begin
    wait_counter     <= 16'd0;
	h_counter        <= 16'd0;
	v_counter        <= 16'd0;
	DATA_EN_I_tb     <= 1'd0;
	FRAME_END_I_tb   <= 1'd0;
	frame_counter    <= 16'd0;
	PATTERN_SEL_I_tb <= 3'd1;
    BAYER_PATTERN_I_tb <=2'd0;
  end
  else
  begin
    wait_counter     <= (h_counter == H_RESOLUTION) ? 16'd0 : (wait_counter == 16'd511) ? wait_counter : (h_counter == 16'd0) ? wait_counter + 16'd1 : wait_counter;
	h_counter        <= (h_counter == H_RESOLUTION) ? 16'd0 : (wait_counter == 16'd511) ? h_counter + 16'd1 : h_counter;
	v_counter        <= (v_counter == V_RESOLUTION) ? 16'd0 : (h_counter == H_RESOLUTION) ? v_counter + 16'd1 : v_counter;
	DATA_EN_I_tb     <= (h_counter != 16'd0) ? 1'd1 : 1'd0;
	FRAME_END_I_tb   <= (v_counter == V_RESOLUTION) ? 1'd1 : 1'd0;
	frame_counter    <= (FRAME_END_I_tb) ? frame_counter + 16'd1 : frame_counter;
	PATTERN_SEL_I_tb <= (frame_counter[0] && FRAME_END_I_tb) ? PATTERN_SEL_I_tb + 3'd1 : PATTERN_SEL_I_tb;
    
  end
end

//initial
//begin
  //wait(FRAME_END_O_tb)
  //#1000;
  //$stop;
//end

//////////////////////////////////////////////////////////////////////
// Instantiate Unit Under Test:  Test_Pattern_Generator
//////////////////////////////////////////////////////////////////////
Test_Pattern_Generator  
#(    
    .H_RESOLUTION    ( H_RESOLUTION     ),
	.V_RESOLUTION    ( V_RESOLUTION     ),
	.g_PIXELS_PER_CLK(g_PIXELS_PER_CLK),
    .g_PIXEL_WIDTH(g_PIXEL_WIDTH)
    
) Test_Pattern_Generator_0 (
    // Inputs
    .SYS_CLK_I       ( SYSCLK           ),
    .RESET_N_I       ( NSYSRESET        ),
    .DATA_EN_I       ( DATA_EN_I_tb     ),
    .FRAME_END_I     ( FRAME_END_I_tb   ),
    .PATTERN_SEL_I   ( PATTERN_SEL_I_tb ),
    .BAYER_PATTERN_I (BAYER_PATTERN_I_tb),
				     
	// Outputs       
    .DATA_VALID_O    ( DATA_VALID_O_tb  ),
    .FRAME_END_O     ( FRAME_END_O_tb   ),
    .LINE_END_O      ( LINE_END_O_tb    ),
    .RED_O           ( RED_O_tb         ),
    .GREEN_O         ( GREEN_O_tb       ),
    .BLUE_O          ( BLUE_O_tb        ),
    .BAYER_O         ( BAYER_O_tb       )


);

endmodule

