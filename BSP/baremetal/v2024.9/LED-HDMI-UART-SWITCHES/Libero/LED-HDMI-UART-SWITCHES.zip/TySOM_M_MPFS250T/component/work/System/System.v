//////////////////////////////////////////////////////////////////////
// Created by SmartDesign Tue Jul 29 11:30:04 2025
// Version: 2024.2 2024.2.0.13
//////////////////////////////////////////////////////////////////////

`timescale 1ns / 100ps

// System
module System(
    // Inputs
    CAN_0_RXBUS_F2M,
    GPIO_1_20_IN,
    MMUART_0_RXD,
    MMUART_1_RXD_F2M,
    MMUART_2_RXD_F2M,
    MMUART_3_RXD_F2M,
    REFCLK,
    REFCLK_N,
    SPI_1_DI,
    SW_0,
    SW_1,
    SW_2,
    SW_3,
    USB_CLK,
    USB_DIR,
    USB_NXT,
    // Outputs
    A,
    ACT_N,
    BA,
    BG,
    CAN_0_STANDBY,
    CAN_0_TXBUS_M2F,
    CAS_N,
    CK0,
    CK0_N,
    CKE0,
    CS0_N,
    HDMI_CLK,
    HDMI_DE,
    HDMI_HSYNC,
    HDMI_I2S0,
    HDMI_I2S1,
    HDMI_I2S2,
    HDMI_I2S3,
    HDMI_LRCLK,
    HDMI_MCLK,
    HDMI_PD_AD,
    HDMI_SCLK,
    HDMI_SPDIF,
    HDMI_VSYNC,
    LED0,
    LED1,
    LED2,
    LED3,
    MMUART_0_TXD,
    MMUART_1_TXD_M2F,
    MMUART_2_TXD_M2F,
    MMUART_3_TXD_M2F,
    ODT0,
    RAS_N,
    RESET_N,
    SD_SEL,
    SPI_1_DO,
    USB_STP,
    USB_ULPI_RESET,
    VSC_8662_CMODE7,
    VSC_8662_RESETN,
    VSC_8662_SRESET,
    WE_N,
    data_b,
    data_g,
    data_r,
    // Inouts
    DQ,
    DQS,
    DQS_N,
    HDMI_SCL,
    HDMI_SDA,
    I2C_1_SCL,
    I2C_1_SDA,
    SPI_1_CLK,
    SPI_1_SS0,
    USB_DATA0,
    USB_DATA1,
    USB_DATA2,
    USB_DATA3,
    USB_DATA4,
    USB_DATA5,
    USB_DATA6,
    USB_DATA7
);

//--------------------------------------------------------------------
// Input
//--------------------------------------------------------------------
input         CAN_0_RXBUS_F2M;
input         GPIO_1_20_IN;
input         MMUART_0_RXD;
input         MMUART_1_RXD_F2M;
input         MMUART_2_RXD_F2M;
input         MMUART_3_RXD_F2M;
input         REFCLK;
input         REFCLK_N;
input         SPI_1_DI;
input         SW_0;
input         SW_1;
input         SW_2;
input         SW_3;
input         USB_CLK;
input         USB_DIR;
input         USB_NXT;
//--------------------------------------------------------------------
// Output
//--------------------------------------------------------------------
output [13:0] A;
output        ACT_N;
output [1:0]  BA;
output [1:0]  BG;
output        CAN_0_STANDBY;
output        CAN_0_TXBUS_M2F;
output        CAS_N;
output        CK0;
output        CK0_N;
output        CKE0;
output        CS0_N;
output        HDMI_CLK;
output        HDMI_DE;
output        HDMI_HSYNC;
output        HDMI_I2S0;
output        HDMI_I2S1;
output        HDMI_I2S2;
output        HDMI_I2S3;
output        HDMI_LRCLK;
output        HDMI_MCLK;
output        HDMI_PD_AD;
output        HDMI_SCLK;
output        HDMI_SPDIF;
output        HDMI_VSYNC;
output        LED0;
output        LED1;
output        LED2;
output        LED3;
output        MMUART_0_TXD;
output        MMUART_1_TXD_M2F;
output        MMUART_2_TXD_M2F;
output        MMUART_3_TXD_M2F;
output        ODT0;
output        RAS_N;
output        RESET_N;
output        SD_SEL;
output        SPI_1_DO;
output        USB_STP;
output        USB_ULPI_RESET;
output        VSC_8662_CMODE7;
output        VSC_8662_RESETN;
output        VSC_8662_SRESET;
output        WE_N;
output [7:0]  data_b;
output [7:0]  data_g;
output [7:0]  data_r;
//--------------------------------------------------------------------
// Inout
//--------------------------------------------------------------------
inout  [35:0] DQ;
inout  [4:0]  DQS;
inout  [4:0]  DQS_N;
inout         HDMI_SCL;
inout         HDMI_SDA;
inout         I2C_1_SCL;
inout         I2C_1_SDA;
inout         SPI_1_CLK;
inout         SPI_1_SS0;
inout         USB_DATA0;
inout         USB_DATA1;
inout         USB_DATA2;
inout         USB_DATA3;
inout         USB_DATA4;
inout         USB_DATA5;
inout         USB_DATA6;
inout         USB_DATA7;
//--------------------------------------------------------------------
// Nets
//--------------------------------------------------------------------
wire   [13:0]  A_net_0;
wire           ACT_N_net_0;
wire           Aldec_MSS_2022_2_0_GPIO_2_M2F_16;
wire           Aldec_MSS_2022_2_0_I2C_0_SCL_OE_M2F;
wire           Aldec_MSS_2022_2_0_I2C_0_SDA_OE_M2F;
wire           Aldec_MSS_2022_2_0_MMUART_4_TXD_M2F;
wire   [1:0]   BA_net_0;
wire   [1:0]   BG_net_0;
wire           BIBUF_0_Y;
wire           BIBUF_1_Y;
wire           CAN_0_RXBUS_F2M;
wire           CAN_0_TXBUS_M2F_net_0;
wire           CAS_N_net_0;
wire           CK0_net_0;
wire           CK0_N_net_0;
wire           CKE0_net_0;
wire           CORERESET_PF_C0_0_PLL_POWERDOWN_B;
wire           CS0_N_net_0;
wire   [7:0]   data_b_net_0;
wire   [15:8]  data_g_net_0;
wire   [23:16] data_r_net_0;
wire           Display_Controller_C0_0_DATA_TRIGGER_O;
wire           Display_Controller_C0_0_FRAME_END_O;
wire   [35:0]  DQ;
wire   [4:0]   DQS;
wire   [4:0]   DQS_N;
wire           GPIO_1_20_IN;
wire           HDMI_CLK_net_0;
wire           HDMI_DE_net_0;
wire           HDMI_HSYNC_net_0;
wire           HDMI_SCL;
wire           HDMI_SDA;
wire           HDMI_VSYNC_net_0;
wire           I2C_1_SCL;
wire           I2C_1_SDA;
wire           LED0_net_0;
wire           LED2_net_0;
wire           LED3_net_0;
wire           MMUART_0_RXD;
wire           MMUART_0_TXD_net_0;
wire           MMUART_1_RXD_F2M;
wire           MMUART_1_TXD_M2F_net_0;
wire           MMUART_2_RXD_F2M;
wire           MMUART_2_TXD_M2F_net_0;
wire           MMUART_3_RXD_F2M;
wire           MMUART_3_TXD_M2F_net_0;
wire           ODT0_net_0;
wire           PF_CCC_C0_0_PLL_LOCK_0;
wire           PF_OSC_C0_0_RCOSC_160MHZ_GL;
wire           PFSOC_INIT_MONITOR_C0_0_BANK_0_VDDI_STATUS;
wire           PFSOC_INIT_MONITOR_C0_0_DEVICE_INIT_DONE;
wire           PFSOC_INIT_MONITOR_C0_0_FABRIC_POR_N;
wire           RAS_N_net_0;
wire           REFCLK;
wire           REFCLK_N;
wire           RESET_N_net_0;
wire           SPI_1_CLK;
wire           SPI_1_DI;
wire           SPI_1_DO_net_0;
wire           SPI_1_SS0;
wire           SW_0;
wire           SW_1;
wire           SW_2;
wire           SW_3;
wire   [7:0]   Test_Pattern_Generator_C0_0_BLUE_O;
wire           Test_Pattern_Generator_C0_0_DATA_VALID_O;
wire   [7:0]   Test_Pattern_Generator_C0_0_GREEN_O;
wire   [7:0]   Test_Pattern_Generator_C0_0_RED_O;
wire           USB_CLK;
wire           USB_DATA0;
wire           USB_DATA1;
wire           USB_DATA2;
wire           USB_DATA3;
wire           USB_DATA4;
wire           USB_DATA5;
wire           USB_DATA6;
wire           USB_DATA7;
wire           USB_DIR;
wire           USB_NXT;
wire           USB_STP_net_0;
wire           USB_ULPI_RESET_net_0;
wire           WE_N_net_0;
wire           ACT_N_net_1;
wire           CAN_0_TXBUS_M2F_net_1;
wire           CAS_N_net_1;
wire           CK0_N_net_1;
wire           CK0_net_1;
wire           CKE0_net_1;
wire           CS0_N_net_1;
wire           HDMI_CLK_net_1;
wire           HDMI_DE_net_1;
wire           HDMI_HSYNC_net_1;
wire           HDMI_VSYNC_net_1;
wire           LED0_net_1;
wire           HDMI_DE_net_2;
wire           LED2_net_1;
wire           LED3_net_1;
wire           MMUART_0_TXD_net_1;
wire           MMUART_1_TXD_M2F_net_1;
wire           MMUART_2_TXD_M2F_net_1;
wire           MMUART_3_TXD_M2F_net_1;
wire           ODT0_net_1;
wire           RAS_N_net_1;
wire           RESET_N_net_1;
wire           SPI_1_DO_net_1;
wire           USB_STP_net_1;
wire           USB_ULPI_RESET_net_2;
wire           WE_N_net_1;
wire   [13:0]  A_net_1;
wire   [1:0]   BA_net_1;
wire   [1:0]   BG_net_1;
wire   [7:0]   data_b_net_1;
wire   [7:0]   data_g_net_1;
wire   [7:0]   data_r_net_1;
wire   [23:0]  DATA_I_net_0;
wire   [23:0]  DATA_O_net_0;
wire   [2:0]   PATTERN_SEL_I_net_0;
//--------------------------------------------------------------------
// TiedOff Nets
//--------------------------------------------------------------------
wire           GND_net;
wire           VCC_net;
wire   [1:0]   BAYER_PATTERN_I_const_net_0;
wire   [7:0]   FIC_0_AXI4_M_BID_const_net_0;
wire   [1:0]   FIC_0_AXI4_M_BRESP_const_net_0;
wire   [7:0]   FIC_0_AXI4_M_RID_const_net_0;
wire   [63:0]  FIC_0_AXI4_M_RDATA_const_net_0;
wire   [1:0]   FIC_0_AXI4_M_RRESP_const_net_0;
wire   [3:0]   FIC_0_AXI4_S_AWID_const_net_0;
wire   [37:0]  FIC_0_AXI4_S_AWADDR_const_net_0;
wire   [7:0]   FIC_0_AXI4_S_AWLEN_const_net_0;
wire   [2:0]   FIC_0_AXI4_S_AWSIZE_const_net_0;
wire   [1:0]   FIC_0_AXI4_S_AWBURST_const_net_0;
wire   [3:0]   FIC_0_AXI4_S_AWQOS_const_net_0;
wire   [3:0]   FIC_0_AXI4_S_AWCACHE_const_net_0;
wire   [2:0]   FIC_0_AXI4_S_AWPROT_const_net_0;
wire   [63:0]  FIC_0_AXI4_S_WDATA_const_net_0;
wire   [7:0]   FIC_0_AXI4_S_WSTRB_const_net_0;
wire   [3:0]   FIC_0_AXI4_S_ARID_const_net_0;
wire   [37:0]  FIC_0_AXI4_S_ARADDR_const_net_0;
wire   [7:0]   FIC_0_AXI4_S_ARLEN_const_net_0;
wire   [2:0]   FIC_0_AXI4_S_ARSIZE_const_net_0;
wire   [1:0]   FIC_0_AXI4_S_ARBURST_const_net_0;
wire   [3:0]   FIC_0_AXI4_S_ARQOS_const_net_0;
wire   [3:0]   FIC_0_AXI4_S_ARCACHE_const_net_0;
wire   [2:0]   FIC_0_AXI4_S_ARPROT_const_net_0;
//--------------------------------------------------------------------
// Inverted Nets
//--------------------------------------------------------------------
wire           USB_ULPI_RESET_net_1;
wire           USB_ULPI_RESET_OUT_PRE_INV0_0;
//--------------------------------------------------------------------
// Constant assignments
//--------------------------------------------------------------------
assign GND_net                          = 1'b0;
assign VCC_net                          = 1'b1;
assign BAYER_PATTERN_I_const_net_0      = 2'h0;
assign FIC_0_AXI4_M_BID_const_net_0     = 8'h00;
assign FIC_0_AXI4_M_BRESP_const_net_0   = 2'h0;
assign FIC_0_AXI4_M_RID_const_net_0     = 8'h00;
assign FIC_0_AXI4_M_RDATA_const_net_0   = 64'h0000000000000000;
assign FIC_0_AXI4_M_RRESP_const_net_0   = 2'h0;
assign FIC_0_AXI4_S_AWID_const_net_0    = 4'h0;
assign FIC_0_AXI4_S_AWADDR_const_net_0  = 38'h0000000000;
assign FIC_0_AXI4_S_AWLEN_const_net_0   = 8'h00;
assign FIC_0_AXI4_S_AWSIZE_const_net_0  = 3'h0;
assign FIC_0_AXI4_S_AWBURST_const_net_0 = 2'h3;
assign FIC_0_AXI4_S_AWQOS_const_net_0   = 4'h0;
assign FIC_0_AXI4_S_AWCACHE_const_net_0 = 4'h0;
assign FIC_0_AXI4_S_AWPROT_const_net_0  = 3'h0;
assign FIC_0_AXI4_S_WDATA_const_net_0   = 64'h0000000000000000;
assign FIC_0_AXI4_S_WSTRB_const_net_0   = 8'hFF;
assign FIC_0_AXI4_S_ARID_const_net_0    = 4'h0;
assign FIC_0_AXI4_S_ARADDR_const_net_0  = 38'h0000000000;
assign FIC_0_AXI4_S_ARLEN_const_net_0   = 8'h00;
assign FIC_0_AXI4_S_ARSIZE_const_net_0  = 3'h0;
assign FIC_0_AXI4_S_ARBURST_const_net_0 = 2'h3;
assign FIC_0_AXI4_S_ARQOS_const_net_0   = 4'h0;
assign FIC_0_AXI4_S_ARCACHE_const_net_0 = 4'h0;
assign FIC_0_AXI4_S_ARPROT_const_net_0  = 3'h0;
//--------------------------------------------------------------------
// Inversions
//--------------------------------------------------------------------
assign USB_ULPI_RESET_net_1 = ~ USB_ULPI_RESET_OUT_PRE_INV0_0;
//--------------------------------------------------------------------
// TieOff assignments
//--------------------------------------------------------------------
assign CAN_0_STANDBY                 = 1'b0;
assign HDMI_I2S0                     = 1'b0;
assign HDMI_I2S1                     = 1'b0;
assign HDMI_I2S2                     = 1'b0;
assign HDMI_I2S3                     = 1'b0;
assign HDMI_LRCLK                    = 1'b0;
assign HDMI_MCLK                     = 1'b0;
assign HDMI_PD_AD                    = 1'b0;
assign HDMI_SCLK                     = 1'b0;
assign HDMI_SPDIF                    = 1'b0;
assign SD_SEL                        = 1'b0;
assign VSC_8662_CMODE7               = 1'b0;
assign VSC_8662_SRESET               = 1'b1;
//--------------------------------------------------------------------
// Top level output port assignments
//--------------------------------------------------------------------
assign ACT_N_net_1                   = ACT_N_net_0;
assign ACT_N                         = ACT_N_net_1;
assign CAN_0_TXBUS_M2F_net_1         = CAN_0_TXBUS_M2F_net_0;
assign CAN_0_TXBUS_M2F               = CAN_0_TXBUS_M2F_net_1;
assign CAS_N_net_1                   = CAS_N_net_0;
assign CAS_N                         = CAS_N_net_1;
assign CK0_N_net_1                   = CK0_N_net_0;
assign CK0_N                         = CK0_N_net_1;
assign CK0_net_1                     = CK0_net_0;
assign CK0                           = CK0_net_1;
assign CKE0_net_1                    = CKE0_net_0;
assign CKE0                          = CKE0_net_1;
assign CS0_N_net_1                   = CS0_N_net_0;
assign CS0_N                         = CS0_N_net_1;
assign HDMI_CLK_net_1                = HDMI_CLK_net_0;
assign HDMI_CLK                      = HDMI_CLK_net_1;
assign HDMI_DE_net_1                 = HDMI_DE_net_0;
assign HDMI_DE                       = HDMI_DE_net_1;
assign HDMI_HSYNC_net_1              = HDMI_HSYNC_net_0;
assign HDMI_HSYNC                    = HDMI_HSYNC_net_1;
assign HDMI_VSYNC_net_1              = HDMI_VSYNC_net_0;
assign HDMI_VSYNC                    = HDMI_VSYNC_net_1;
assign LED0_net_1                    = LED0_net_0;
assign LED0                          = LED0_net_1;
assign HDMI_DE_net_2                 = HDMI_DE_net_0;
assign LED1                          = HDMI_DE_net_2;
assign LED2_net_1                    = LED2_net_0;
assign LED2                          = LED2_net_1;
assign LED3_net_1                    = LED3_net_0;
assign LED3                          = LED3_net_1;
assign MMUART_0_TXD_net_1            = MMUART_0_TXD_net_0;
assign MMUART_0_TXD                  = MMUART_0_TXD_net_1;
assign MMUART_1_TXD_M2F_net_1        = MMUART_1_TXD_M2F_net_0;
assign MMUART_1_TXD_M2F              = MMUART_1_TXD_M2F_net_1;
assign MMUART_2_TXD_M2F_net_1        = MMUART_2_TXD_M2F_net_0;
assign MMUART_2_TXD_M2F              = MMUART_2_TXD_M2F_net_1;
assign MMUART_3_TXD_M2F_net_1        = MMUART_3_TXD_M2F_net_0;
assign MMUART_3_TXD_M2F              = MMUART_3_TXD_M2F_net_1;
assign ODT0_net_1                    = ODT0_net_0;
assign ODT0                          = ODT0_net_1;
assign RAS_N_net_1                   = RAS_N_net_0;
assign RAS_N                         = RAS_N_net_1;
assign RESET_N_net_1                 = RESET_N_net_0;
assign RESET_N                       = RESET_N_net_1;
assign SPI_1_DO_net_1                = SPI_1_DO_net_0;
assign SPI_1_DO                      = SPI_1_DO_net_1;
assign USB_STP_net_1                 = USB_STP_net_0;
assign USB_STP                       = USB_STP_net_1;
assign USB_ULPI_RESET_OUT_PRE_INV0_0 = USB_ULPI_RESET_net_0;
assign USB_ULPI_RESET                = USB_ULPI_RESET_net_1;
assign USB_ULPI_RESET_net_2          = USB_ULPI_RESET_net_0;
assign VSC_8662_RESETN               = USB_ULPI_RESET_net_2;
assign WE_N_net_1                    = WE_N_net_0;
assign WE_N                          = WE_N_net_1;
assign A_net_1                       = A_net_0;
assign A[13:0]                       = A_net_1;
assign BA_net_1                      = BA_net_0;
assign BA[1:0]                       = BA_net_1;
assign BG_net_1                      = BG_net_0;
assign BG[1:0]                       = BG_net_1;
assign data_b_net_1                  = data_b_net_0;
assign data_b[7:0]                   = data_b_net_1;
assign data_g_net_1                  = data_g_net_0;
assign data_g[7:0]                   = data_g_net_1;
assign data_r_net_1                  = data_r_net_0;
assign data_r[7:0]                   = data_r_net_1;
//--------------------------------------------------------------------
// Slices assignments
//--------------------------------------------------------------------
assign data_b_net_0 = DATA_O_net_0[7:0];
assign data_g_net_0 = DATA_O_net_0[15:8];
assign data_r_net_0 = DATA_O_net_0[23:16];
//--------------------------------------------------------------------
// Concatenation assignments
//--------------------------------------------------------------------
assign DATA_I_net_0        = { Test_Pattern_Generator_C0_0_RED_O , Test_Pattern_Generator_C0_0_GREEN_O , Test_Pattern_Generator_C0_0_BLUE_O };
assign PATTERN_SEL_I_net_0 = { LED3_net_0 , LED2_net_0 , Aldec_MSS_2022_2_0_GPIO_2_M2F_16 };
//--------------------------------------------------------------------
// Component instances
//--------------------------------------------------------------------
//--------MSS_TySOM_M_VIDEO
MSS_TySOM_M_VIDEO Aldec_MSS_2022_2_0(
        // Inputs
        .FIC_0_ACLK           ( HDMI_CLK_net_0 ),
        .FIC_0_AXI4_M_AWREADY ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_M_WREADY  ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_M_BID     ( FIC_0_AXI4_M_BID_const_net_0 ), // tied to 8'h00 from definition
        .FIC_0_AXI4_M_BRESP   ( FIC_0_AXI4_M_BRESP_const_net_0 ), // tied to 2'h0 from definition
        .FIC_0_AXI4_M_BVALID  ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_M_ARREADY ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_M_RID     ( FIC_0_AXI4_M_RID_const_net_0 ), // tied to 8'h00 from definition
        .FIC_0_AXI4_M_RDATA   ( FIC_0_AXI4_M_RDATA_const_net_0 ), // tied to 64'h0000000000000000 from definition
        .FIC_0_AXI4_M_RRESP   ( FIC_0_AXI4_M_RRESP_const_net_0 ), // tied to 2'h0 from definition
        .FIC_0_AXI4_M_RLAST   ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_M_RVALID  ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_S_AWID    ( FIC_0_AXI4_S_AWID_const_net_0 ), // tied to 4'h0 from definition
        .FIC_0_AXI4_S_AWADDR  ( FIC_0_AXI4_S_AWADDR_const_net_0 ), // tied to 38'h0000000000 from definition
        .FIC_0_AXI4_S_AWLEN   ( FIC_0_AXI4_S_AWLEN_const_net_0 ), // tied to 8'h00 from definition
        .FIC_0_AXI4_S_AWSIZE  ( FIC_0_AXI4_S_AWSIZE_const_net_0 ), // tied to 3'h0 from definition
        .FIC_0_AXI4_S_AWBURST ( FIC_0_AXI4_S_AWBURST_const_net_0 ), // tied to 2'h3 from definition
        .FIC_0_AXI4_S_AWQOS   ( FIC_0_AXI4_S_AWQOS_const_net_0 ), // tied to 4'h0 from definition
        .FIC_0_AXI4_S_AWLOCK  ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_S_AWCACHE ( FIC_0_AXI4_S_AWCACHE_const_net_0 ), // tied to 4'h0 from definition
        .FIC_0_AXI4_S_AWPROT  ( FIC_0_AXI4_S_AWPROT_const_net_0 ), // tied to 3'h0 from definition
        .FIC_0_AXI4_S_AWVALID ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_S_WDATA   ( FIC_0_AXI4_S_WDATA_const_net_0 ), // tied to 64'h0000000000000000 from definition
        .FIC_0_AXI4_S_WSTRB   ( FIC_0_AXI4_S_WSTRB_const_net_0 ), // tied to 8'hFF from definition
        .FIC_0_AXI4_S_WLAST   ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_S_WVALID  ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_S_BREADY  ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_S_ARID    ( FIC_0_AXI4_S_ARID_const_net_0 ), // tied to 4'h0 from definition
        .FIC_0_AXI4_S_ARADDR  ( FIC_0_AXI4_S_ARADDR_const_net_0 ), // tied to 38'h0000000000 from definition
        .FIC_0_AXI4_S_ARLEN   ( FIC_0_AXI4_S_ARLEN_const_net_0 ), // tied to 8'h00 from definition
        .FIC_0_AXI4_S_ARSIZE  ( FIC_0_AXI4_S_ARSIZE_const_net_0 ), // tied to 3'h0 from definition
        .FIC_0_AXI4_S_ARBURST ( FIC_0_AXI4_S_ARBURST_const_net_0 ), // tied to 2'h3 from definition
        .FIC_0_AXI4_S_ARQOS   ( FIC_0_AXI4_S_ARQOS_const_net_0 ), // tied to 4'h0 from definition
        .FIC_0_AXI4_S_ARLOCK  ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_S_ARCACHE ( FIC_0_AXI4_S_ARCACHE_const_net_0 ), // tied to 4'h0 from definition
        .FIC_0_AXI4_S_ARPROT  ( FIC_0_AXI4_S_ARPROT_const_net_0 ), // tied to 3'h0 from definition
        .FIC_0_AXI4_S_ARVALID ( GND_net ), // tied to 1'b0 from definition
        .FIC_0_AXI4_S_RREADY  ( GND_net ), // tied to 1'b0 from definition
        .MMUART_1_RXD_F2M     ( MMUART_1_RXD_F2M ),
        .MMUART_2_RXD_F2M     ( MMUART_2_RXD_F2M ),
        .MMUART_3_RXD_F2M     ( MMUART_3_RXD_F2M ),
        .MMUART_4_RXD_F2M     ( Aldec_MSS_2022_2_0_MMUART_4_TXD_M2F ),
        .CAN_0_RXBUS_F2M      ( CAN_0_RXBUS_F2M ),
        .I2C_0_SCL_F2M        ( BIBUF_0_Y ),
        .I2C_0_SDA_F2M        ( BIBUF_1_Y ),
        .GPIO_2_F2M_23        ( SW_3 ),
        .GPIO_2_F2M_22        ( SW_2 ),
        .GPIO_2_F2M_21        ( SW_1 ),
        .GPIO_2_F2M_20        ( SW_0 ),
        .MSS_RESET_N_F2M      ( USB_ULPI_RESET_net_0 ),
        .MMUART_0_RXD         ( MMUART_0_RXD ),
        .GPIO_1_20_IN         ( GPIO_1_20_IN ),
        .USB_CLK              ( USB_CLK ),
        .USB_DIR              ( USB_DIR ),
        .USB_NXT              ( USB_NXT ),
        .SPI_1_DI             ( SPI_1_DI ),
        .REFCLK               ( REFCLK ),
        .REFCLK_N             ( REFCLK_N ),
        // Outputs
        .FIC_0_DLL_LOCK_M2F   (  ),
        .FIC_0_AXI4_M_AWID    (  ),
        .FIC_0_AXI4_M_AWADDR  (  ),
        .FIC_0_AXI4_M_AWLEN   (  ),
        .FIC_0_AXI4_M_AWSIZE  (  ),
        .FIC_0_AXI4_M_AWBURST (  ),
        .FIC_0_AXI4_M_AWLOCK  (  ),
        .FIC_0_AXI4_M_AWQOS   (  ),
        .FIC_0_AXI4_M_AWCACHE (  ),
        .FIC_0_AXI4_M_AWPROT  (  ),
        .FIC_0_AXI4_M_AWVALID (  ),
        .FIC_0_AXI4_M_WDATA   (  ),
        .FIC_0_AXI4_M_WSTRB   (  ),
        .FIC_0_AXI4_M_WLAST   (  ),
        .FIC_0_AXI4_M_WVALID  (  ),
        .FIC_0_AXI4_M_BREADY  (  ),
        .FIC_0_AXI4_M_ARID    (  ),
        .FIC_0_AXI4_M_ARADDR  (  ),
        .FIC_0_AXI4_M_ARLEN   (  ),
        .FIC_0_AXI4_M_ARSIZE  (  ),
        .FIC_0_AXI4_M_ARBURST (  ),
        .FIC_0_AXI4_M_ARLOCK  (  ),
        .FIC_0_AXI4_M_ARQOS   (  ),
        .FIC_0_AXI4_M_ARCACHE (  ),
        .FIC_0_AXI4_M_ARPROT  (  ),
        .FIC_0_AXI4_M_ARVALID (  ),
        .FIC_0_AXI4_M_RREADY  (  ),
        .FIC_0_AXI4_S_AWREADY (  ),
        .FIC_0_AXI4_S_WREADY  (  ),
        .FIC_0_AXI4_S_BID     (  ),
        .FIC_0_AXI4_S_BRESP   (  ),
        .FIC_0_AXI4_S_BVALID  (  ),
        .FIC_0_AXI4_S_ARREADY (  ),
        .FIC_0_AXI4_S_RID     (  ),
        .FIC_0_AXI4_S_RDATA   (  ),
        .FIC_0_AXI4_S_RRESP   (  ),
        .FIC_0_AXI4_S_RLAST   (  ),
        .FIC_0_AXI4_S_RVALID  (  ),
        .MMUART_1_TXD_M2F     ( MMUART_1_TXD_M2F_net_0 ),
        .MMUART_1_TXD_OE_M2F  (  ),
        .MMUART_2_TXD_M2F     ( MMUART_2_TXD_M2F_net_0 ),
        .MMUART_3_TXD_M2F     ( MMUART_3_TXD_M2F_net_0 ),
        .MMUART_4_TXD_M2F     ( Aldec_MSS_2022_2_0_MMUART_4_TXD_M2F ),
        .CAN_0_TX_EBL_M2F     (  ),
        .CAN_0_TXBUS_M2F      ( CAN_0_TXBUS_M2F_net_0 ),
        .I2C_0_SCL_OE_M2F     ( Aldec_MSS_2022_2_0_I2C_0_SCL_OE_M2F ),
        .I2C_0_SDA_OE_M2F     ( Aldec_MSS_2022_2_0_I2C_0_SDA_OE_M2F ),
        .GPIO_2_M2F_18        ( LED3_net_0 ),
        .GPIO_2_M2F_17        ( LED2_net_0 ),
        .GPIO_2_M2F_16        ( Aldec_MSS_2022_2_0_GPIO_2_M2F_16 ),
        .PLL_CPU_LOCK_M2F     (  ),
        .PLL_DDR_LOCK_M2F     (  ),
        .MSS_RESET_N_M2F      (  ),
        .MMUART_0_TXD         ( MMUART_0_TXD_net_0 ),
        .GPIO_1_23_OUT        ( LED0_net_0 ),
        .USB_STP              ( USB_STP_net_0 ),
        .SPI_1_DO             ( SPI_1_DO_net_0 ),
        .BA                   ( BA_net_0 ),
        .A                    ( A_net_0 ),
        .RESET_N              ( RESET_N_net_0 ),
        .CKE0                 ( CKE0_net_0 ),
        .CS0_N                ( CS0_N_net_0 ),
        .ODT0                 ( ODT0_net_0 ),
        .CK0                  ( CK0_net_0 ),
        .CK0_N                ( CK0_N_net_0 ),
        .RAS_N                ( RAS_N_net_0 ),
        .WE_N                 ( WE_N_net_0 ),
        .CAS_N                ( CAS_N_net_0 ),
        .ACT_N                ( ACT_N_net_0 ),
        .BG                   ( BG_net_0 ),
        // Inouts
        .I2C_1_SCL            ( I2C_1_SCL ),
        .I2C_1_SDA            ( I2C_1_SDA ),
        .USB_DATA0            ( USB_DATA0 ),
        .USB_DATA1            ( USB_DATA1 ),
        .USB_DATA2            ( USB_DATA2 ),
        .USB_DATA3            ( USB_DATA3 ),
        .USB_DATA4            ( USB_DATA4 ),
        .USB_DATA5            ( USB_DATA5 ),
        .USB_DATA6            ( USB_DATA6 ),
        .USB_DATA7            ( USB_DATA7 ),
        .SPI_1_SS0            ( SPI_1_SS0 ),
        .SPI_1_CLK            ( SPI_1_CLK ),
        .DQ                   ( DQ ),
        .DQS                  ( DQS ),
        .DQS_N                ( DQS_N ) 
        );

//--------BIBUF
BIBUF BIBUF_0(
        // Inputs
        .D   ( GND_net ),
        .E   ( Aldec_MSS_2022_2_0_I2C_0_SCL_OE_M2F ),
        // Outputs
        .Y   ( BIBUF_0_Y ),
        // Inouts
        .PAD ( HDMI_SCL ) 
        );

//--------BIBUF
BIBUF BIBUF_1(
        // Inputs
        .D   ( GND_net ),
        .E   ( Aldec_MSS_2022_2_0_I2C_0_SDA_OE_M2F ),
        // Outputs
        .Y   ( BIBUF_1_Y ),
        // Inouts
        .PAD ( HDMI_SDA ) 
        );

//--------CORERESET_PF_C0
CORERESET_PF_C0 CORERESET_PF_C0_0(
        // Inputs
        .CLK                ( HDMI_CLK_net_0 ),
        .EXT_RST_N          ( VCC_net ),
        .BANK_x_VDDI_STATUS ( PFSOC_INIT_MONITOR_C0_0_BANK_0_VDDI_STATUS ),
        .BANK_y_VDDI_STATUS ( PFSOC_INIT_MONITOR_C0_0_BANK_0_VDDI_STATUS ),
        .PLL_LOCK           ( PF_CCC_C0_0_PLL_LOCK_0 ),
        .SS_BUSY            ( GND_net ),
        .INIT_DONE          ( PFSOC_INIT_MONITOR_C0_0_DEVICE_INIT_DONE ),
        .FF_US_RESTORE      ( GND_net ),
        .FPGA_POR_N         ( PFSOC_INIT_MONITOR_C0_0_FABRIC_POR_N ),
        // Outputs
        .PLL_POWERDOWN_B    ( CORERESET_PF_C0_0_PLL_POWERDOWN_B ),
        .FABRIC_RESET_N     ( USB_ULPI_RESET_net_0 ) 
        );

//--------Display_Controller_New
Display_Controller_New Display_Controller_C0_0(
        // Inputs
        .RESETN_I          ( USB_ULPI_RESET_net_0 ),
        .SYS_CLK_I         ( HDMI_CLK_net_0 ),
        .ENABLE_I          ( VCC_net ),
        .EXT_SYNC_SIGNAL_I ( Test_Pattern_Generator_C0_0_DATA_VALID_O ),
        .DATA_I            ( DATA_I_net_0 ),
        // Outputs
        .FRAME_END_O       ( Display_Controller_C0_0_FRAME_END_O ),
        .H_SYNC_O          ( HDMI_HSYNC_net_0 ),
        .V_SYNC_O          ( HDMI_VSYNC_net_0 ),
        .V_ACTIVE_O        (  ),
        .DATA_TRIGGER_O    ( Display_Controller_C0_0_DATA_TRIGGER_O ),
        .DATA_VALID_O      ( HDMI_DE_net_0 ),
        .H_RES_O           (  ),
        .V_RES_O           (  ),
        .DATA_O            ( DATA_O_net_0 ) 
        );

//--------PF_CCC_C0
PF_CCC_C0 PF_CCC_C0_0(
        // Inputs
        .REF_CLK_0         ( PF_OSC_C0_0_RCOSC_160MHZ_GL ),
        .PLL_POWERDOWN_N_0 ( CORERESET_PF_C0_0_PLL_POWERDOWN_B ),
        // Outputs
        .OUT0_FABCLK_0     ( HDMI_CLK_net_0 ),
        .PLL_LOCK_0        ( PF_CCC_C0_0_PLL_LOCK_0 ) 
        );

//--------PF_OSC_C0
PF_OSC_C0 PF_OSC_C0_0(
        // Outputs
        .RCOSC_160MHZ_GL ( PF_OSC_C0_0_RCOSC_160MHZ_GL ) 
        );

//--------PFSOC_INIT_MONITOR_C0
PFSOC_INIT_MONITOR_C0 PFSOC_INIT_MONITOR_C0_0(
        // Outputs
        .FABRIC_POR_N               ( PFSOC_INIT_MONITOR_C0_0_FABRIC_POR_N ),
        .PCIE_INIT_DONE             (  ),
        .USRAM_INIT_DONE            (  ),
        .SRAM_INIT_DONE             (  ),
        .DEVICE_INIT_DONE           ( PFSOC_INIT_MONITOR_C0_0_DEVICE_INIT_DONE ),
        .BANK_0_VDDI_STATUS         ( PFSOC_INIT_MONITOR_C0_0_BANK_0_VDDI_STATUS ),
        .XCVR_INIT_DONE             (  ),
        .USRAM_INIT_FROM_SNVM_DONE  (  ),
        .USRAM_INIT_FROM_UPROM_DONE (  ),
        .USRAM_INIT_FROM_SPI_DONE   (  ),
        .SRAM_INIT_FROM_SNVM_DONE   (  ),
        .SRAM_INIT_FROM_UPROM_DONE  (  ),
        .SRAM_INIT_FROM_SPI_DONE    (  ),
        .AUTOCALIB_DONE             (  ) 
        );

//--------Test_Pattern_Generator_C0
Test_Pattern_Generator_C0 Test_Pattern_Generator_C0_0(
        // Inputs
        .SYS_CLK_I       ( HDMI_CLK_net_0 ),
        .RESET_N_I       ( USB_ULPI_RESET_net_0 ),
        .DATA_EN_I       ( Display_Controller_C0_0_DATA_TRIGGER_O ),
        .FRAME_END_I     ( Display_Controller_C0_0_FRAME_END_O ),
        .PATTERN_SEL_I   ( PATTERN_SEL_I_net_0 ),
        .BAYER_PATTERN_I ( BAYER_PATTERN_I_const_net_0 ),
        // Outputs
        .DATA_VALID_O    ( Test_Pattern_Generator_C0_0_DATA_VALID_O ),
        .FRAME_END_O     (  ),
        .LINE_END_O      (  ),
        .RED_O           ( Test_Pattern_Generator_C0_0_RED_O ),
        .GREEN_O         ( Test_Pattern_Generator_C0_0_GREEN_O ),
        .BLUE_O          ( Test_Pattern_Generator_C0_0_BLUE_O ),
        .BAYER_O         (  ) 
        );


endmodule
