/*************************************************************************************************************************************
--
-- File Name       : Test_Pattern_Generator.v 
-- Description     : This module is pattern generator 

-- Targeted device : Microchip FPGAs                    
-- Author          : India Solutions Team

-- COPYRIGHT 2023 BY MICROCHIP 
-- THE INFORMATION CONTAINED IN THIS DOCUMENT IS SUBJECT TO LICENSING RESTRICTIONS 
-- FROM MICROSEMI CORP.  IF YOU ARE NOT IN POSSESSION OF WRITTEN AUTHORIZATION FROM 
-- MICROSEMI FOR USE OF THIS FILE, THEN THE FILE SHOULD BE IMMEDIATELY DESTROYED AND 
-- NO BACK-UP OF THE FILE SHOULD BE MADE. 
--
--*************************************************************************************************************************************/

module Test_Pattern_Generator
#( // parameter list
    // Horizontal resolution selection
    parameter H_RESOLUTION = 1920 ,
    // Vertical resolution selection
	parameter V_RESOLUTION = 1080 ,
    parameter g_PIXELS_PER_CLK = 1,
    parameter g_PIXEL_WIDTH = 8,
    
    //internal parameters
    parameter g_ZEROS_2  =  2'b00 ,
    parameter g_ZEROS_4  =  4'b0000 ,
    parameter g_ZEROS_8  =  8'b00000000 
  
)(
    // input and output Declaration 
    input                                                   SYS_CLK_I,        // system clock	
    input                                                   RESET_N_I,        // system reset	
    input                                                   DATA_EN_I,        // enable
	input                                                   FRAME_END_I, 	  // Frame end input 	
	input        [2:0]                                      PATTERN_SEL_I,	  //pattern select
	input        [1:0]                                      BAYER_PATTERN_I ,
	// outputs                                
    output wire                                             DATA_VALID_O, 	   // data enable 
    output wire                                             FRAME_END_O,	   // End of frame
    output wire                                             LINE_END_O, 	   //End of line
    output wire [g_PIXELS_PER_CLK * g_PIXEL_WIDTH -1:0]     RED_O, 	           //Red pixel
    output wire [g_PIXELS_PER_CLK * g_PIXEL_WIDTH -1:0]     GREEN_O,	       // Green Pixel
    output wire [g_PIXELS_PER_CLK * g_PIXEL_WIDTH -1:0]     BLUE_O, 	       // Blue Pixel 
    output wire [g_PIXELS_PER_CLK * g_PIXEL_WIDTH -1:0]     BAYER_O 	       // Bayer output 
);

//================================================================================================
// Nets Declarations
//================================================================================================
     
  
  wire                     w_vact_fe;        
  wire [15:0]              w_h_resolution;
  wire [16:0]              w_h_count_active; 
  wire [15:0]              w_v_count_active;
  wire [15:0]              w_h_shift;        
  wire [16:0]              w_h_bar_ref;      
  wire [15:0]              w_bar_width;      
  wire [15:0]              w_bar_width2;     
  wire [16:0]              w_bar_width3;     
  wire [15:0]              w_bar_width4;     
  wire [16:0]              w_bar_width5;     
  wire [16:0]              w_bar_width6;     
  wire [17:0]              w_bar_width7;     
  wire [3:0]               w_bar_select;     
  wire [15:0]              w_box_width;      
  wire [15:0]              w_box_width2;     
  wire [16:0]              w_box_width3;     
  wire [15:0]              w_box_width4;     
  wire [16:0]              w_box_width5;     
  wire [16:0]              w_box_width6;     
  wire [17:0]              w_box_width7;    
  wire [7:0]               w_red_p_red;
  wire [7:0]               w_green_p_red;
  wire [7:0]               w_blue_p_red; 
  wire [7:0]               w_red_p_green;
  wire [7:0]               w_green_p_green;
  wire [7:0]               w_blue_p_green;
  wire [7:0]               w_red_p_blue;
  wire [7:0]               w_green_p_blue;
  wire [7:0]               w_blue_p_blue;
  wire [7:0]               w_red_p_vertical;
  wire [7:0]               w_green_p_vertical;
  wire [7:0]               w_blue_p_vertical;
  wire [7:0]               w_red_p_horizontal;
  wire [7:0]               w_green_p_horizontal;
  wire [7:0]               w_blue_p_horizontal; 
  wire [7:0]               w_red_p_boxes;
  wire [7:0]               w_green_p_boxes;
  wire [7:0]               w_blue_p_boxes;
  wire [1:0]               w_vh; 
  wire [g_PIXEL_WIDTH-1 :0]               a1;
  wire [g_PIXEL_WIDTH-1 :0]               a2;
  wire [g_PIXEL_WIDTH-1 :0]               a3;
  wire [g_PIXEL_WIDTH-1 :0]               a4;
 
/*================================================================================================
// Registers Declarations
//================================================================================================*/
  reg                      r_data_en_dly1;   
  reg                      r_data_en_dly2;  
  reg                      r_data_en_re;     
  reg                      r_data_en_fe;     
  reg                      r_h_counting;     
  reg                      r_h_counting_dly;
  reg  [15:0]              r_h_counter;      
  reg  [15:0]              r_v_counter;      
  reg  [7:0]               r_red;
  reg  [7:0]               r_green;
  reg  [7:0]               r_blue;
  reg  [g_PIXELS_PER_CLK * g_PIXEL_WIDTH -1:0]   r_bayer;          
  reg  [7:0]               r_v_bw_count;
  reg  [7:0]               r_h_bw_count;
  reg  [2:0]               r_pattern_sel_temp;
  reg                      r_frame_end_dly;
  reg  [1:0]               bayer_pattern;


/*================================================================================================
// Generate blocks
//================================================================================================*/
generate
always@*
begin
    if(g_PIXELS_PER_CLK == 4) begin
        if(bayer_pattern == 'd0)
            if(r_v_counter[0]==1) begin 
                r_bayer <= (g_PIXEL_WIDTH == 16 )  ? { {r_red ,g_ZEROS_8} , {r_green , g_ZEROS_8 }, {r_red , g_ZEROS_8} , {r_green , g_ZEROS_8} } : (g_PIXEL_WIDTH == 12 ) ? { {r_red ,g_ZEROS_4} , {r_green , g_ZEROS_4} , {r_red , g_ZEROS_4} , {r_green , g_ZEROS_4} } : (g_PIXEL_WIDTH ==10 )  ? { {r_red ,g_ZEROS_2} , {r_green , g_ZEROS_2} , {r_red , g_ZEROS_2} , {r_green , g_ZEROS_2} } : { r_red ,r_green , r_red,r_green } ; 
            end
            else begin
                r_bayer <= (g_PIXEL_WIDTH == 16 ) ? { {r_green ,g_ZEROS_8 }, {r_blue , g_ZEROS_8} , {r_green , g_ZEROS_8} , {r_blue , g_ZEROS_8 }} : (g_PIXEL_WIDTH == 12  ) ? { {r_green ,g_ZEROS_4} , {r_blue , g_ZEROS_4} , {r_green , g_ZEROS_4} , {r_blue , g_ZEROS_4} } : (g_PIXEL_WIDTH ==10 )  ? { {r_green ,g_ZEROS_2} , {r_blue , g_ZEROS_2} , {r_green , g_ZEROS_2} , {r_blue, g_ZEROS_2} } : { r_green ,r_blue , r_green,r_blue} ;
            end
            
        else if(bayer_pattern == 'd1)
             if(r_v_counter[0]==1) begin 
               r_bayer <= (g_PIXEL_WIDTH == 16 )  ? { {r_green ,g_ZEROS_8} , {r_red , g_ZEROS_8} , {r_green , g_ZEROS_8} , {r_red , g_ZEROS_8 }} : (g_PIXEL_WIDTH == 12  ) ? { {r_green ,g_ZEROS_4} , {r_red , g_ZEROS_4} , {r_green , g_ZEROS_4} , {r_red , g_ZEROS_4} } : (g_PIXEL_WIDTH ==10 )  ? { {r_green ,g_ZEROS_2} , {r_red , g_ZEROS_2} , {r_green , g_ZEROS_2} , {r_red , g_ZEROS_2} } : { r_green ,r_red, r_green, r_red } ; 
            end
            else begin
                r_bayer <= (g_PIXEL_WIDTH == 16 )  ? { {r_blue ,g_ZEROS_8}, {r_green , g_ZEROS_8} , {r_blue , g_ZEROS_8} , {r_green , g_ZEROS_8} } : (g_PIXEL_WIDTH == 12  ) ? { {r_blue ,g_ZEROS_4} , {r_green , g_ZEROS_4} , {r_blue , g_ZEROS_4} , {r_green , g_ZEROS_4} } : (g_PIXEL_WIDTH ==10 )  ? { {r_blue ,g_ZEROS_2} , {r_green , g_ZEROS_2} , {r_blue , g_ZEROS_2} , {r_green , g_ZEROS_2} } : { r_blue ,r_green , r_blue , r_green } ; 
            end
            
        else if(bayer_pattern == 'd2)
             if(r_v_counter[0]==1) begin 
                r_bayer <= (g_PIXEL_WIDTH ==16 )  ? { {r_blue ,g_ZEROS_8} , {r_green , g_ZEROS_8 }, {r_blue , g_ZEROS_8} , {r_green , g_ZEROS_8} } : (g_PIXEL_WIDTH == 12  ) ? { {r_blue ,g_ZEROS_4} , {r_green , g_ZEROS_4} , {r_blue , g_ZEROS_4} , {r_green , g_ZEROS_4} } : (g_PIXEL_WIDTH ==10 )  ? { {r_blue ,g_ZEROS_2} , {r_green , g_ZEROS_2} , {r_blue , g_ZEROS_2} , {r_green , g_ZEROS_2} } : { r_blue ,r_green , r_blue , r_green } ; 
            end
            else begin
                 r_bayer <= (g_PIXEL_WIDTH ==16 )  ? { {r_green ,g_ZEROS_8 }, {r_red , g_ZEROS_8} , {r_green , g_ZEROS_8} , {r_red , g_ZEROS_8 }} : (g_PIXEL_WIDTH == 12  ) ? { {r_green ,g_ZEROS_4} , {r_red , g_ZEROS_4} , {r_green , g_ZEROS_4} , {r_red , g_ZEROS_4} } : (g_PIXEL_WIDTH ==10 )  ? { {r_green ,g_ZEROS_2} , {r_red , g_ZEROS_2} , {r_green , g_ZEROS_2} , {r_red , g_ZEROS_2} } : { r_green ,r_red, r_green, r_red } ; 
            end
            
        else if(bayer_pattern == 'd3)
             if(r_v_counter[0]==1) begin 
                 r_bayer <= (g_PIXEL_WIDTH ==16 )  ? { {r_green ,g_ZEROS_8} , {r_blue , g_ZEROS_8 }, {r_green , g_ZEROS_8} , {r_blue , g_ZEROS_8 }} : (g_PIXEL_WIDTH == 12  ) ? { {r_green ,g_ZEROS_4} , {r_blue , g_ZEROS_4} , {r_green , g_ZEROS_4} , {r_blue , g_ZEROS_4} } : (g_PIXEL_WIDTH ==10 )  ? { {r_green ,g_ZEROS_2} , {r_blue , g_ZEROS_2} , {r_green , g_ZEROS_2} , {r_blue, g_ZEROS_2} } : { r_green ,r_blue , r_green,r_blue} ;
            end
            else begin
                r_bayer <= (g_PIXEL_WIDTH ==16 )  ? { {r_red ,g_ZEROS_8} , {r_green , g_ZEROS_8} , {r_red , g_ZEROS_8 }, {r_green , g_ZEROS_8 }} : (g_PIXEL_WIDTH == 12  ) ? { {r_red ,g_ZEROS_4} , {r_green , g_ZEROS_4} , {r_red , g_ZEROS_4} , {r_green , g_ZEROS_4} } : (g_PIXEL_WIDTH ==10 )  ? { {r_red ,g_ZEROS_2} , {r_green , g_ZEROS_2} , {r_red , g_ZEROS_2} , {r_green , g_ZEROS_2} } : { r_red ,r_green , r_red,r_green } ; 
            end
            
        
    end 
    else if(g_PIXELS_PER_CLK == 1) begin
        if(bayer_pattern == 'd1)
            r_bayer <= (w_vh == 2'b11) ? ((g_PIXEL_WIDTH ==  16) ? {r_green , g_ZEROS_8 }:(g_PIXEL_WIDTH ==  12) ? {r_green , g_ZEROS_4 } :(g_PIXEL_WIDTH ==  10) ? {r_green , g_ZEROS_2 }: r_green ): (w_vh == 2'b10) ? ((g_PIXEL_WIDTH ==  16) ? {r_red , g_ZEROS_8 }:(g_PIXEL_WIDTH ==  12) ? {r_red , g_ZEROS_4 } :(g_PIXEL_WIDTH ==  10) ? {r_red , g_ZEROS_2 }: r_red ) : (w_vh == 2'b01) ? ((g_PIXEL_WIDTH ==  16) ? {r_blue, g_ZEROS_8 }:(g_PIXEL_WIDTH ==  12) ? {r_blue , g_ZEROS_4 } :(g_PIXEL_WIDTH ==  10) ? {r_blue , g_ZEROS_2 }: r_blue) : ((g_PIXEL_WIDTH ==  16) ? {r_green , g_ZEROS_8 }:(g_PIXEL_WIDTH ==  12) ? {r_green , g_ZEROS_4 } :(g_PIXEL_WIDTH ==  10) ? {r_green , g_ZEROS_2 }: r_green ) ;
            
        else if(bayer_pattern == 'd0)
          r_bayer <= (w_vh == 2'b11) ? ((g_PIXEL_WIDTH ==  16) ? {r_red , g_ZEROS_8 }:(g_PIXEL_WIDTH ==  12) ? {r_red , g_ZEROS_4 } :(g_PIXEL_WIDTH ==  10) ? {r_red , g_ZEROS_2 }: r_red ): (w_vh == 2'b10) ? ((g_PIXEL_WIDTH ==  16) ? {r_green , g_ZEROS_8 }:(g_PIXEL_WIDTH ==  12) ? {r_green , g_ZEROS_4 } :(g_PIXEL_WIDTH ==  10) ? {r_green, g_ZEROS_2}: r_green ) : (w_vh == 2'b01) ? ((g_PIXEL_WIDTH ==  16) ? {r_green, g_ZEROS_8 }:(g_PIXEL_WIDTH ==  12) ? {r_green , g_ZEROS_4 } :(g_PIXEL_WIDTH ==  10) ? {r_green , g_ZEROS_2}: r_green) : ((g_PIXEL_WIDTH ==  16) ? {r_blue , g_ZEROS_8 }:(g_PIXEL_WIDTH ==  12) ? {r_blue , g_ZEROS_4 } :(g_PIXEL_WIDTH ==  10) ? {r_blue , g_ZEROS_2 }: r_blue ) ;
          
        else if(bayer_pattern == 'd2)
            r_bayer <= (w_vh == 2'b11) ? ((g_PIXEL_WIDTH ==  16) ? {r_green , g_ZEROS_8 }:(g_PIXEL_WIDTH ==  12) ? {r_green , g_ZEROS_4 } :(g_PIXEL_WIDTH ==  10) ? {r_green , g_ZEROS_2 }: r_green ): (w_vh == 2'b10) ? ((g_PIXEL_WIDTH ==  16) ? {r_blue , g_ZEROS_8 }:(g_PIXEL_WIDTH ==  12) ? {r_blue , g_ZEROS_4 } :(g_PIXEL_WIDTH ==  10) ? {r_blue , g_ZEROS_2 }: r_blue ) : (w_vh == 2'b01) ? ((g_PIXEL_WIDTH ==  16) ? {r_red, g_ZEROS_8 }:(g_PIXEL_WIDTH ==  12) ? {r_red , g_ZEROS_4 } :(g_PIXEL_WIDTH ==  10) ? {r_red , g_ZEROS_2 }: r_red) : ((g_PIXEL_WIDTH ==  16) ? {r_green , g_ZEROS_8 }:(g_PIXEL_WIDTH ==  12) ? {r_green , g_ZEROS_4 } :(g_PIXEL_WIDTH ==  10) ? {r_green , g_ZEROS_2 }: r_green ) ;
        
		else if(bayer_pattern == 3)
            r_bayer <= (w_vh == 2'b11) ? ((g_PIXEL_WIDTH ==  16) ? {r_blue , g_ZEROS_8 }:(g_PIXEL_WIDTH ==  12) ? {r_blue , g_ZEROS_4 } :(g_PIXEL_WIDTH ==  10) ? {r_blue, g_ZEROS_2 }: r_blue ): (w_vh == 2'b10) ? ((g_PIXEL_WIDTH ==  16) ? {r_green , g_ZEROS_8 }:(g_PIXEL_WIDTH ==  12) ? {r_green , g_ZEROS_4 } :(g_PIXEL_WIDTH ==  10) ? {r_green , g_ZEROS_2}: r_green ) : (w_vh == 2'b01) ? ((g_PIXEL_WIDTH ==  16) ? {r_green, g_ZEROS_8 }:(g_PIXEL_WIDTH ==  12) ? {r_green , g_ZEROS_4 } :(g_PIXEL_WIDTH ==  10) ? {r_green , g_ZEROS_2 }: r_green) : ((g_PIXEL_WIDTH ==  16) ? {r_red , g_ZEROS_8 }:(g_PIXEL_WIDTH ==  12) ? {r_red , g_ZEROS_4 } :(g_PIXEL_WIDTH ==  10) ? {r_red , g_ZEROS_2 }: r_red ) ;
    end
end
endgenerate



//================================================================================================
// Top level assignments
//================================================================================================
assign  DATA_VALID_O         = r_h_counting_dly;

assign  RED_O                = (g_PIXELS_PER_CLK == 4)? ((PATTERN_SEL_I == 7 ) ? ((r_h_counting_dly) ? {a1,a2,a3,a4 } : 0): ((r_h_counting_dly) ? ((g_PIXEL_WIDTH ==16) ?  {4{r_red, g_ZEROS_8 }} : (g_PIXEL_WIDTH == 12  ) ? {4{r_red , g_ZEROS_4}} : (g_PIXEL_WIDTH == 10)?  {4{r_red , g_ZEROS_2} } : {4{r_red}}) : 0)): ((r_h_counting_dly) ? ((g_PIXEL_WIDTH == 16) ? {r_red , g_ZEROS_8 }: (g_PIXEL_WIDTH == 12) ? {r_red , g_ZEROS_4 }: (g_PIXEL_WIDTH ==  10) ? {r_red , g_ZEROS_2} : r_red) :  0);

assign  GREEN_O                = (g_PIXELS_PER_CLK == 4)? ((PATTERN_SEL_I == 7 ) ? ((r_h_counting_dly) ? {a1,a2,a3,a4 } : 0): ((r_h_counting_dly) ? ((g_PIXEL_WIDTH == 16 ) ?  {4{r_green, g_ZEROS_8} } : (g_PIXEL_WIDTH == 12  ) ? {4{r_green , g_ZEROS_4}} : (g_PIXEL_WIDTH == 10)?  {4{r_green , g_ZEROS_2} } : {4{r_green}}) :  0)): ((r_h_counting_dly) ? ((g_PIXEL_WIDTH == 16) ? {r_green, g_ZEROS_8 }: (g_PIXEL_WIDTH == 12) ? {r_green , g_ZEROS_4 }: (g_PIXEL_WIDTH ==  10) ? {r_green , g_ZEROS_2} : r_green) :  0);

assign  BLUE_O                = (g_PIXELS_PER_CLK == 4)? ((PATTERN_SEL_I == 7 ) ? ((r_h_counting_dly) ? {a1,a2,a3,a4 } : 0): ((r_h_counting_dly) ? ((g_PIXEL_WIDTH ==16) ?  {4{r_blue, g_ZEROS_8} } : (g_PIXEL_WIDTH == 12  ) ? {4{r_blue , g_ZEROS_4}} : (g_PIXEL_WIDTH == 10)?  {4{r_blue , g_ZEROS_2} } : {4{r_blue}}) : 0)): ((r_h_counting_dly) ? ((g_PIXEL_WIDTH == 16) ? {r_blue, g_ZEROS_8 }: (g_PIXEL_WIDTH == 12) ? {r_blue , g_ZEROS_4 }: (g_PIXEL_WIDTH ==  10) ? {r_blue , g_ZEROS_2} : r_blue) :  0);


assign  BAYER_O              = r_bayer;
assign  LINE_END_O           = r_data_en_fe;
assign  FRAME_END_O          = w_vact_fe;


/************************************************************************
	Internal assignments			 
*************************************************************************/
						     
assign w_vact_fe             = r_frame_end_dly;
assign w_h_resolution_1      = H_RESOLUTION[15:0];
assign w_vh                  = {r_v_counter[0],r_h_counter[0]};
						     
assign a1 = 	( g_PIXEL_WIDTH == 16 ) ?  {r_h_bw_count, g_ZEROS_8} : (g_PIXEL_WIDTH == 12  ) ? {r_h_bw_count, g_ZEROS_4} : (g_PIXEL_WIDTH == 10 ) ? {r_h_bw_count, {2{0 }}} : r_h_bw_count ;

assign a2= 		( g_PIXEL_WIDTH == 16 ) ?  	{r_h_bw_count + 'd1, g_ZEROS_8} : (g_PIXEL_WIDTH == 12  ) ? {r_h_bw_count  + 'd1 , g_ZEROS_4} : (g_PIXEL_WIDTH == 10 ) ? {r_h_bw_count  + 'd1, g_ZEROS_2 } : r_h_bw_count  + 'd1 ;

assign a3= 		( g_PIXEL_WIDTH == 16 ) ?  	{r_h_bw_count + 'd2, g_ZEROS_8} : (g_PIXEL_WIDTH == 12  ) ? {r_h_bw_count  + 'd2 , g_ZEROS_4} : (g_PIXEL_WIDTH == 10 ) ? {r_h_bw_count  + 'd2 , g_ZEROS_2 } : r_h_bw_count  + 'd2 ;

assign a4= 		( g_PIXEL_WIDTH == 16 ) ?  	{r_h_bw_count + 'd3, g_ZEROS_8} : (g_PIXEL_WIDTH == 12  ) ? {r_h_bw_count  + 'd3 , g_ZEROS_4} : (g_PIXEL_WIDTH == 10 ) ? {r_h_bw_count  + 'd3 , g_ZEROS_2 } : r_h_bw_count  + 'd3 ; 
 
assign w_h_resolution         = (g_PIXELS_PER_CLK == 4 ) ? 	H_RESOLUTION / 4 : H_RESOLUTION; 				     
assign w_bar_width           = w_h_resolution [15:0] >>> 3;
assign w_box_width           = (V_RESOLUTION[15:0]  ) >>> 3;
assign w_h_count_active      = (PATTERN_SEL_I == 3'd0) ? r_h_counter + w_h_shift : {1'd0,r_h_counter};
assign w_h_bar_ref           = (w_h_count_active[15:0] < w_h_resolution[15:0]  ) ? w_h_count_active[16:0] : (w_h_count_active[15:0] - w_h_resolution[15:0]  );
assign w_v_count_active      = r_v_counter;
assign w_bar_width2          = {w_bar_width[14:0],1'd0};
assign w_bar_width3          = {w_bar_width[14:0],1'd0} + w_bar_width;
assign w_bar_width4          = {w_bar_width[13:0],2'b00};
assign w_bar_width5          = {w_bar_width[13:0],2'b00} + w_bar_width;
assign w_bar_width6          = w_bar_width4 + w_bar_width2;
assign w_bar_width7          = w_bar_width4 + w_bar_width2 + w_bar_width;
						     
assign w_bar_select          = (w_h_bar_ref[15:0] < w_bar_width[15:0]) ? 4'h0  : (w_h_bar_ref[15:0] < w_bar_width2[15:0]) ? 4'h1 :
                               (w_h_bar_ref[15:0] < w_bar_width3[15:0]) ? 4'h2 : (w_h_bar_ref[15:0] < w_bar_width4[15:0]) ? 4'h3 :
					           (w_h_bar_ref[15:0] < w_bar_width5[15:0]) ? 4'h4 : (w_h_bar_ref[15:0] < w_bar_width6[15:0]) ? 4'h5 :
					           (w_h_bar_ref[15:0] < w_bar_width7[15:0]) ? 4'h6 : 4'h7;
						     
assign w_box_width2          = {w_box_width[14:0],1'd0};
assign w_box_width3          = {w_box_width[14:0],1'd0} + w_box_width;
assign w_box_width4          = {w_box_width[13:0],2'b00};
assign w_box_width5          = {w_box_width[13:0],2'b00} + w_box_width;
assign w_box_width6          = w_box_width4 + w_box_width2;
assign w_box_width7          = w_box_width4 + w_box_width2 + w_box_width;
						     
						     
assign w_h_shift             = (w_v_count_active < w_box_width[15:0]) ? 16'h0 : (w_v_count_active < w_box_width2[15:0]) ? w_bar_width[15:0] :
                               (w_v_count_active < w_box_width3[15:0]) ? w_bar_width2[15:0] : (w_v_count_active < w_box_width4[15:0]) ? w_bar_width3[15:0] :
				               (w_v_count_active < w_box_width5[15:0]) ? w_bar_width4[15:0] : (w_v_count_active < w_box_width6[15:0]) ? w_bar_width5[15:0] :
				               (w_v_count_active < w_box_width7[15:0]) ? w_bar_width6[15:0] : w_bar_width7[15:0];
						     
						     
						     
assign w_red_p_red           = (r_h_counting) ? 8'd255 : 8'd0;
assign w_green_p_red         = 8'd0;
assign w_blue_p_red          = 8'd0;
						     
assign w_red_p_green         = 8'd0;
assign w_green_p_green       = (r_h_counting) ? 8'd255 : 8'd0;
assign w_blue_p_green        = 8'd0;
						     
assign w_red_p_blue          = 8'd0;
assign w_green_p_blue        = 8'd0;
assign w_blue_p_blue         = (r_h_counting) ? 8'd255 : 8'd0;

assign w_red_p_vertical      = (w_bar_select == 4'd4 || w_bar_select == 4'd5 || w_bar_select == 4'd6 || w_bar_select == 4'd7) ? 8'd255 : 8'd0;
assign w_green_p_vertical    = (w_bar_select == 4'd2 || w_bar_select == 4'd3 || w_bar_select == 4'd6 || w_bar_select == 4'd7) ? 8'd255 : 8'd0;
assign w_blue_p_vertical     = (w_bar_select == 4'd1 || w_bar_select == 4'd3 || w_bar_select == 4'd5 || w_bar_select == 4'd7) ? 8'd255 : 8'd0;

assign w_red_p_horizontal    = (r_v_counter < w_box_width[15:0]) ? 8'd0 :    (r_v_counter < w_box_width2[15:0]) ? 8'd0 :
                               (r_v_counter < w_box_width3[15:0]) ? 8'd0 :   (r_v_counter < w_box_width4[15:0]) ? 8'd0 :
			                   (r_v_counter < w_box_width5[15:0]) ? 8'd255 : (r_v_counter < w_box_width6[15:0]) ? 8'd255 :
			                   (r_v_counter < w_box_width7[15:0]) ? 8'd255 : 8'd255;
assign w_green_p_horizontal  = (r_v_counter < w_box_width[15:0]) ? 8'd0 :    (r_v_counter < w_box_width2[15:0]) ? 8'd0 :
                               (r_v_counter < w_box_width3[15:0]) ? 8'd255 : (r_v_counter < w_box_width4[15:0]) ? 8'd255 :
			                   (r_v_counter < w_box_width5[15:0]) ? 8'd0 :   (r_v_counter < w_box_width6[15:0]) ? 8'd0 :
			                   (r_v_counter < w_box_width7[15:0]) ? 8'd255 : 8'd255;
assign w_blue_p_horizontal   = (r_v_counter < w_box_width[15:0]) ? 8'd0 :  (r_v_counter < w_box_width2[15:0])  ? 8'd255  :
                               (r_v_counter < w_box_width3[15:0]) ? 8'd0 : (r_v_counter < w_box_width4[15:0])  ? 8'd255 :
			                   (r_v_counter < w_box_width5[15:0]) ? 8'd0 : (r_v_counter < w_box_width6[15:0])  ? 8'd255 :
			                   (r_v_counter < w_box_width7[15:0]) ? 8'd0 : 8'd255;

assign w_red_p_boxes         = (w_bar_select == 4'd4 || w_bar_select == 4'd5 || w_bar_select == 4'd6 || w_bar_select == 4'd7) ? 8'd255 : 8'd0;
assign w_green_p_boxes       = (w_bar_select == 4'd2 || w_bar_select == 4'd3 || w_bar_select == 4'd6 || w_bar_select == 4'd7) ? 8'd255 : 8'd0;
assign w_blue_p_boxes        = (w_bar_select == 4'd1 || w_bar_select == 4'd3 || w_bar_select == 4'd5 || w_bar_select == 4'd7) ? 8'd255 : 8'd0;




	
//**********************************************************************
// Synchoronous blocks
//**********************************************************************
//======================================================================
// Process to generate pattern select
//======================================================================
// 0 -- shifted 8 colors boxes
// 1 -- red
// 2 -- green
// 3 -- blue
// 4 -- vertical 8 colors
// 5 -- horizontal 8 colors
// 6 -- horizontal BW
// 7 -- vertical BW



  always@(posedge SYS_CLK_I or negedge RESET_N_I)
  begin
  if(!RESET_N_I)
  begin
    r_pattern_sel_temp <= 3'd0;
	r_red              <= 8'd0;
	r_green            <= 8'd0;
	r_blue             <= 8'd0;
  end
  else begin
        r_pattern_sel_temp <= (r_v_counter==0) ? PATTERN_SEL_I : r_pattern_sel_temp;
        case(r_pattern_sel_temp)
          3'd0 : // shifted 8 color boxes
          begin
            r_red    <= w_red_p_boxes;
            r_green  <= w_green_p_boxes;
            r_blue   <= w_blue_p_boxes;
          end
          3'd1 : // only red
          begin
            r_red    <= w_red_p_red;
            r_green  <= w_green_p_red;
            r_blue   <= w_blue_p_red;
          end
          3'd2 : // only green
          begin
            r_red    <= w_red_p_green;
            r_green  <= w_green_p_green;
            r_blue   <= w_blue_p_green;
          end
          3'd3 : // only blue
          begin
            r_red    <= w_red_p_blue;
            r_green  <= w_green_p_blue;
            r_blue   <= w_blue_p_blue;
          end
          3'd4 : // vertical color
          begin
            r_red    <= w_red_p_vertical;
            r_green  <= w_green_p_vertical;
            r_blue   <= w_blue_p_vertical;
          end
          3'd5 : // horizontal color
          begin
            r_red    <= w_red_p_horizontal;
            r_green  <= w_green_p_horizontal;
            r_blue   <= w_blue_p_horizontal;
          end
          3'd6 :  // vertical BW 
          begin
            r_red    <= r_v_bw_count;
            r_green  <= r_v_bw_count;
            r_blue   <= r_v_bw_count;
          end
          3'd7 : // horizontal BW
          begin
            r_red    <= r_h_bw_count;
            r_green  <= r_h_bw_count;
            r_blue   <= r_h_bw_count;
          end
          default :
          begin
            r_red    <= 'd0;
            r_green  <= 'd0;
            r_blue   <= 'd0;
          end
        endcase
    end 
end

//======================================================================
// Process to generate v and h BW count 
//======================================================================

  always@(posedge SYS_CLK_I or negedge RESET_N_I)
  begin
    if(!RESET_N_I)
	begin
	  r_v_bw_count <= 8'd0;
	  r_h_bw_count <= 8'd0;
	  r_frame_end_dly <= 1'd0;
	  bayer_pattern <=2'd0;
	end
	else
	begin
	  r_h_bw_count <= (r_h_counter == w_h_resolution) ? 8'd0 :(g_PIXELS_PER_CLK == 4) ? ((r_h_counting) ? r_h_bw_count + 8'd4 : 8'd0) : ((r_h_bw_count == 8'd255) ? 8'd0 : (r_h_counting) ? r_h_bw_count + 8'd1 : 8'd0);
	  r_v_bw_count <= (w_vact_fe) ? 8'd0 :  (r_data_en_re) ? r_v_bw_count + 8'd1 : r_v_bw_count;
	  r_frame_end_dly <= FRAME_END_I;
	  bayer_pattern <= BAYER_PATTERN_I;
	end
  end
  
//======================================================================
// Process to generate  horizontal counters 
//======================================================================

  always@(posedge SYS_CLK_I or negedge RESET_N_I)
  begin
    if (!RESET_N_I)
	begin
      r_h_counter    <= 16'd0;
      r_data_en_dly1 <= 1'd0;
      r_data_en_dly2 <= 1'd0;
      r_data_en_re   <= 1'd0;
      r_h_counting   <= 1'd0;
	  r_data_en_fe   <= 1'd0;
      r_h_counting_dly <= 1'd0;
	end
    else
	begin
      r_data_en_dly1 <= DATA_EN_I;
      r_data_en_dly2 <= r_data_en_dly1;
      r_data_en_re   <= r_data_en_dly1 & ~r_data_en_dly2;
      r_data_en_fe   <= ~r_data_en_dly1 & r_data_en_dly2;
      r_h_counting   <= (r_data_en_re) ? 1'd1 : (r_h_counter == w_h_resolution - 16'd1) ? 1'd0 : r_h_counting;	  
      r_h_counter    <= (r_h_counting) ? r_h_counter + 16'd1 : 16'd0;
      r_h_counting_dly <= r_h_counting;
    end
  end
  
//======================================================================
// Process to generate vertical counter 
//======================================================================  

  always@(posedge SYS_CLK_I or negedge RESET_N_I)
  begin
    if(!RESET_N_I)
      r_v_counter <= 16'd0;
	else
	begin 
        if (r_frame_end_dly ==1) begin
            r_v_counter <=0; 
        end 
        else if(r_data_en_re == 1'd1) begin 
            r_v_counter <= (r_v_counter <= (V_RESOLUTION - 1'd1) ) ? r_v_counter + 16'd1 : 16'd0;
        end
        else
	    r_v_counter <= r_v_counter;
    end
  end


endmodule